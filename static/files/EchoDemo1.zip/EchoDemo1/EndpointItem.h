
#ifndef ENDPOINT_ITEM_H
#define ENDPOINT_ITEM_H

#include <ListItem.h>

class EndpointItem : public BStringItem
{
public:

	EndpointItem(BMidiEndpoint* endp);
	virtual ~EndpointItem();

	void ChangedName();

	BMidiEndpoint* endp;
};

#endif // ENDPOINT_ITEM_H
