
#ifndef ECHO_CONSUMER_H
#define ECHO_CONSUMER_H

#include <MidiConsumer.h>

/**
 * This is our filter's input. To handle incoming MIDI events, 
 * you have to subclass BMidiLocalConsumer and override the 
 * corresponding hook functions. 
 *
 * We only catch "note on" and "note off" events. If this was a 
 * real filter, we would pass on any other events to our output 
 * unchanged, but because this is just a simple demo application, 
 * we throw them away instead.
 */
class EchoConsumer : public BMidiLocalConsumer
{
public:

	EchoConsumer(const char* name, BMidiLocalProducer* output);

	virtual void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual void NoteOff(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	/** How many echo notes we will play. */
	int32 notes;

	/** The time between the echo notes (milliseconds). */
	int32 delay;

private:

	typedef BMidiLocalConsumer super;

	/** 
	 * The filter's output endpoint. We need this to send
	 * out the MIDI events after we have "filtered" them.
	 */
	BMidiLocalProducer* output;
};

#endif // ECHO_CONSUMER_H
