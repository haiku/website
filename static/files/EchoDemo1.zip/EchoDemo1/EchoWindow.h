
#ifndef ECHO_WINDOW_H
#define ECHO_WINDOW_H

#include <Window.h>

enum
{
	MSG_SELECT_PRODUCER = 1000,
	MSG_SELECT_CONSUMER,
	MSG_CHANGE_NOTES,
	MSG_CHANGE_DELAY,
};

class EchoConsumer;

class EchoWindow : public BWindow
{
public:

	EchoWindow();
	virtual ~EchoWindow();

	virtual void MessageReceived(BMessage* msg);

private:

	typedef BWindow super;

	void CreateEndpoints();
	void CreateViews();

	int32 WhichIndex(BListView* list, int32 id);
	BListView* WhichList(BMessage* msg);

	void OnMidiEvent(BMessage* msg);
	void OnMidiRegistered(BMessage* msg);
	void OnMidiUnregistered(BMessage* msg);
	void OnMidiChangedName(BMessage* msg);
	void OnMidiConnected(BMessage* msg);
	void OnMidiDisconnected(BMessage* msg);

	void OnSelectProducer(BMessage* msg);
	void OnSelectConsumer(BMessage* msg);
	void OnChangeNotes(BMessage* msg);
	void OnChangeDelay(BMessage* msg);

	BListView* producers;
	BListView* consumers;
	BSlider* notes;
	BSlider* delay;

	/** The filter's input endpoint. */
	EchoConsumer* consumer;

	/** The filter's output endpoint. */
	BMidiLocalProducer* producer;
};

#endif // ECHO_WINDOW_H
