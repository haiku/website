
#include <Message.h>
#include <ListView.h>
#include <ScrollView.h>
#include <Slider.h>
#include <StringView.h>
 
#include <MidiEndpoint.h>
#include <MidiConsumer.h>
#include <MidiProducer.h>
#include <MidiRoster.h>

#include "EchoConsumer.h"
#include "EchoWindow.h"
#include "EndpointItem.h"

//------------------------------------------------------------------------------

EchoWindow::EchoWindow()
	: BWindow(
			BRect(100, 100, 450, 330), "EchoDemo", B_TITLED_WINDOW, 
			B_NOT_RESIZABLE | B_NOT_ZOOMABLE | B_QUIT_ON_WINDOW_CLOSE)
{
	CreateEndpoints();
	CreateViews();
	Show();

	// Tell the Midi Roster that we want to be notified whenever
	// something changes. This allows us to update the lists of
	// producers and consumers in real time. As soon as we start
	// watching, the roster sends us "registered" notifications 
	// for all available endpoints, so the lists will be filled 
	// up automatically, saving us some work.

	BMessenger msngr(this);
	BMidiRoster::StartWatching(&msngr);
}

//------------------------------------------------------------------------------

EchoWindow::~EchoWindow()
{
	// You should never try to "delete" your MIDI endpoints.
	// Instead, we use Release() to tell the Midi Roster that 
	// we are done using them. But first we call Unregister()
	// to let other apps know that these endpoints are no 
	// longer available. (This isn't strictly necessary; dead 
	// endpoints will disappear from the roster anyway.)

	consumer->Unregister();
	producer->Unregister();

	consumer->Release();
	producer->Release();

	// The BListView destructor does not destroy the 
	// items themselves, so we have to do that here.

	for (int32 t = producers->CountItems() - 1; t >= 0; --t)
	{
		delete producers->RemoveItem(t);
	}

	for (int32 t = consumers->CountItems() - 1; t >= 0; --t)
	{
		delete consumers->RemoveItem(t);
	}
}

//------------------------------------------------------------------------------

void EchoWindow::MessageReceived(BMessage* msg)
{
	switch (msg->what)
	{
		case B_MIDI_EVENT:        OnMidiEvent(msg);      break;
		case MSG_SELECT_PRODUCER: OnSelectProducer(msg); break;
		case MSG_SELECT_CONSUMER: OnSelectConsumer(msg); break;
		case MSG_CHANGE_NOTES:    OnChangeNotes(msg);    break;
		case MSG_CHANGE_DELAY:    OnChangeDelay(msg);    break;

		default: super::MessageReceived(msg); break;
	}
}

//------------------------------------------------------------------------------

void EchoWindow::CreateEndpoints()
{
	// Here we create our own endpoints. Notice that we use
	// a subclass for the consumer, but for the producer we
	// simply use BMidiLocalProducer. There is almost never
	// a reason to derive from BMidiLocalProducer, but you
	// must always create a BMidiLocalConsumer subclass in
	// order to make your consumer to something useful. 

	producer = new BMidiLocalProducer("Echo Output");
	consumer = new EchoConsumer("Echo Input", producer);

	// After creating the endpoints, we call Register() to 
	// "publish" them. This makes our endpoints visible to 
	// other applications. You are not required to do this,
	// so you can have endpoints that no one else knows about.
	// In this case, however, we do want the endpoints to be
	// visible, so users can use PatchBay or a similar app
	// to connect other endpoints to our filter.

	producer->Register();
	consumer->Register();
}

//------------------------------------------------------------------------------

void EchoWindow::CreateViews()
{
	AddChild(new BStringView(
		BRect(10, 0, 150, 18), NULL, "Producers:"));

	producers = new BListView(
		BRect(10, 20, 150, 150), "Producers", 
		B_MULTIPLE_SELECTION_LIST, B_FOLLOW_ALL_SIDES);

	producers->SetSelectionMessage(new BMessage(MSG_SELECT_PRODUCER));

	AddChild(new BScrollView(
		"ScrollProducers", producers, B_FOLLOW_LEFT | B_FOLLOW_TOP, 
		0, false, true));

	AddChild(new BStringView(
		BRect(180, 0, 320, 18), NULL, "Consumers:"));

	consumers = new BListView(
		BRect(180, 20, 320, 150), "Consumers", 
		B_MULTIPLE_SELECTION_LIST, B_FOLLOW_ALL_SIDES);

	consumers->SetSelectionMessage(new BMessage(MSG_SELECT_CONSUMER));

	AddChild(new BScrollView(
		"ScrollConsumers", consumers, B_FOLLOW_RIGHT | B_FOLLOW_TOP, 
		0, false, true));

	notes = new BSlider(
		BRect(10, 160, 160, 220), "Notes", "Number of echo notes",
		NULL, 0, 4);

	notes->SetHashMarks(B_HASH_MARKS_BOTTOM);
	notes->SetHashMarkCount(5);
	notes->SetLimitLabels("0", "4");
	notes->SetValue(consumer->notes);
	notes->SetModificationMessage(new BMessage(MSG_CHANGE_NOTES));

	AddChild(notes);

	delay = new BSlider(
		BRect(180, 160, 340, 220), "Delay", "Time between notes (ms)",
		NULL, 0, 1000);

	delay->SetHashMarks(B_HASH_MARKS_BOTTOM);
	delay->SetHashMarkCount(10);
	delay->SetLimitLabels("0", "1000");
	delay->SetValue(consumer->delay);
	delay->SetModificationMessage(new BMessage(MSG_CHANGE_DELAY));

	AddChild(delay);
}

//------------------------------------------------------------------------------

int32 EchoWindow::WhichIndex(BListView* list, int32 id)
{
	// The midi_server uses IDs to refer to endpoints, but our 
	// list items (the EndpointItem class) store a pointer to 
	// a BMidiEndpoint object instead. Here we loop through all 
	// the items from either the producers or consumers list, 
	// and look for the BMidiEndpoint object with a matching ID.

	for (int32 t = 0; t < list->CountItems(); ++t)
	{
		EndpointItem* item = (EndpointItem*) list->ItemAt(t);

		if (item->endp->ID() == id)
		{
			return t;
		}
	}

	return -1;
}

//------------------------------------------------------------------------------

BListView* EchoWindow::WhichList(BMessage* msg)
{
	// Several of the B_MIDI_EVENT notification messages have 
	// a "be:type" field that tells us whether the endpoint in 
	// question is a producer or consumer. Here we examine that 
	// field and return a pointer to the corresponding BListView.

	BString type;

	if (msg->FindString("be:type", &type) == B_OK)
	{ 
		if (type == "producer")
		{
			return producers;
		}
		else
		{
			return consumers;
		}
	}

	return NULL;
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiEvent(BMessage* msg)
{
	// In our constructor, we called StartWatching() to tell 
	// the Midi Roster that we want to receive notifications
	// about changes in the roster. Now whenever something 
	// interesting happens, we receive a B_MIDI_EVENT message. 
	// This message has a field named "be:op" that specifies 
	// what kind of event happened.

	int32 op;
	if (msg->FindInt32("be:op", &op) == B_OK) 
	{ 
		switch (op)
		{
			case B_MIDI_REGISTERED:   OnMidiRegistered(msg);   break;
			case B_MIDI_UNREGISTERED: OnMidiUnregistered(msg); break;
			case B_MIDI_CHANGED_NAME: OnMidiChangedName(msg);  break;
			case B_MIDI_CONNECTED:    OnMidiConnected(msg);    break;
			case B_MIDI_DISCONNECTED: OnMidiDisconnected(msg); break;
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiRegistered(BMessage* msg)
{
	// The midi_server sends us the "registered" notification
	// message when another application "publishes" one of its
	// MIDI endpoints. When an endpoint is published, all other 
	// apps (including ours) can make use of that endpoint. We 
	// also receive a whole bunch of "registered" notifications 
	// for all available endpoints as soon as we call BMidiRoster's
	// StartWatching() method, which we do in our constructor.

	BListView* list = WhichList(msg);
	if (list != NULL)
	{
		int32 id;
		if (msg->FindInt32("be:id", &id) == B_OK) 
		{
			// Ask the Midi Roster to give us a BMidiEndpoint
			// object for the new endpoint. We create a new
			// list item for the endpoint and add it to either
			// the producers or consumers BListView.

			BMidiEndpoint* endp = BMidiRoster::FindEndpoint(id);
			if (endp != NULL)
			{
				list->AddItem(new EndpointItem(endp));

				// We are done using the endpoint, so release
				// it. See the comments in EndpointItem.cpp 
				// for an explanation why this is necessary.

				endp->Release();
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiUnregistered(BMessage* msg)
{
	// The "unregistered" notification is the opposite of the
	// "registered" notification. We receive it when another
	// application removes one of its MIDI endpoints from the 
	// roster; the endpoint isn't necessarily deleted, but at 
	// least it is no longer "visible" to other applications, 
	// including ours. So we find the corresponding list item 
	// for that endpoint, and remove it from its BListView. If
	// the endpoint was connected, unregistering does not break
	// its connections; they simply aren't visible anymore.

	BListView* list = WhichList(msg);
	if (list != NULL)
	{
		int32 id;
		if (msg->FindInt32("be:id", &id) == B_OK) 
		{
			int32 index = WhichIndex(list, id);
			if (index != -1)
			{
				delete list->RemoveItem(index);
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiChangedName(BMessage* msg)
{
	// Like its name implies, the "changed name" notification
	// is sent when an application changes the name of a MIDI
	// endpoint. First we look up which of our list items 
	// corresponds to that endpoint. If we have such an item, 
	// we tell it to change its text. Finally, we tell the 
	// BListView to repaint that item.

	BListView* list = WhichList(msg);
	if (list != NULL)
	{
		int32 id;
		if (msg->FindInt32("be:id", &id) == B_OK) 
		{
			int32 index = WhichIndex(list, id);
			if (index != -1)
			{
				((EndpointItem*) list->ItemAt(index))->ChangedName();
				list->InvalidateItem(index);
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiConnected(BMessage* msg)
{
	// The "connected" notification is sent when any two
	// endpoints get connected by _another_ application. 
	// (If our app makes the connection, we are not notified.)
	// If the new connection involves either our consumer
	// or producer, we must select the corresponding item 
	// from the BListView. (Note that this makes the BListView 
	// trigger a selection message, which in turn calls the 
	// OnSelectConsumer() and OnSelectProducer() hooks. 
	// That is no problem, since those methods will not try 
	// to make a new connection if one already exists.)

	int32 prod;
	if (msg->FindInt32("be:producer", &prod) == B_OK) 
	{
		int32 cons;
		if (msg->FindInt32("be:consumer", &cons) == B_OK)
		{
			if (prod == producer->ID())
			{
				int32 index = WhichIndex(consumers, cons);
				if (index != -1)
				{
					consumers->Select(index, true);
				}
			}
			else if (cons == consumer->ID())
			{
				int32 index = WhichIndex(producers, prod);
				if (index != -1)
				{
					producers->Select(index, true);
				}
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnMidiDisconnected(BMessage* msg)
{
	// The opposite of OnMidiConnected(), this method 
	// is invoked when _another_ application breaks the 
	// connection between any two endpoints. (If our own
	// app breaks the connection, we are not notified.)
	// We de-select the corresponding list item.

	int32 prod;
	if (msg->FindInt32("be:producer", &prod) == B_OK) 
	{
		int32 cons;
		if (msg->FindInt32("be:consumer", &cons) == B_OK)
		{
			if (prod == producer->ID())
			{
				int32 index = WhichIndex(consumers, cons);
				if (index != -1)
				{
					consumers->Deselect(index);
				}
			}
			else if (cons == consumer->ID())
			{
				int32 index = WhichIndex(producers, prod);
				if (index != -1)
				{
					producers->Deselect(index);
				}
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnSelectProducer(BMessage* msg)
{
	// We get here when the user selected or deselected an 
	// item in the BListView of producers. This list allows 
	// multiple selection, so it is rather unfortunate that
	// the selection message doesn't tell us which index was 
	// selected or de-selected. The easiest solution is to
	// loop through the list and determine whether we still 
	// have to connect or disconnect each item's endpoint. 
	// To keep things simple, this demo app does not check
	// if making or breaking the connections fails. 

	for (int32 t = 0; t < producers->CountItems(); ++t)
	{
		EndpointItem* item = (EndpointItem*) producers->ItemAt(t);
		BMidiProducer* prod = (BMidiProducer*) item->endp;

		if (producers->IsItemSelected(t))
		{
			if (!prod->IsConnected(consumer))
			{
				prod->Connect(consumer);
			}
		}
		else  // not selected
		{
			if (prod->IsConnected(consumer))
			{
				prod->Disconnect(consumer);
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnSelectConsumer(BMessage* msg)
{
	// This works just like OnSelectProducer(), except 
	// that the roles are now reversed: the list items 
	// now represent consumers, and we have to connect 
	// them to (or disconnect from) our own producer.

	for (int32 t = 0; t < consumers->CountItems(); ++t)
	{
		EndpointItem* item = (EndpointItem*) consumers->ItemAt(t);
		BMidiConsumer* cons = (BMidiConsumer*) item->endp;

		if (consumers->IsItemSelected(t))
		{
			if (!producer->IsConnected(cons))
			{
				producer->Connect(cons);
			}
		}
		else  // not selected
		{
			if (producer->IsConnected(cons))
			{
				producer->Disconnect(cons);
			}
		}
	}
}

//------------------------------------------------------------------------------

void EchoWindow::OnChangeNotes(BMessage* msg)
{
	// Note: this function is not thread safe. It is called
	// from the BLooper's thread, but the EchoConsumer uses
	// a different thread to process the MIDI events. If you 
	// are moving the slider while the consumer processes an 
	// event, both threads will try to access the "notes" 
	// variable at the same time, and its value may become 
	// undefined. Because this is just a simple demo app, I 
	// did not bother to synchronize this. The same applies 
	// to OnChangeDelay(), below.

	consumer->notes = notes->Value();
}

//------------------------------------------------------------------------------

void EchoWindow::OnChangeDelay(BMessage* msg)
{
	consumer->delay = delay->Value();
}

//------------------------------------------------------------------------------
