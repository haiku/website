
#include "EchoApp.h"
#include "EchoWindow.h"

//------------------------------------------------------------------------------

EchoApp::EchoApp()
	: BApplication("application/x-vnd.mahlzeit.echodemo")
{
	new EchoWindow;
}

//------------------------------------------------------------------------------

int main()
{
	EchoApp app;
	app.Run();
	return 0;
}

//------------------------------------------------------------------------------
