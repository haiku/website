
#include <MidiEndpoint.h>

#include "EndpointItem.h"

//------------------------------------------------------------------------------

EndpointItem::EndpointItem(BMidiEndpoint* endp_)
	: BStringItem("", 0, false)
{
	endp = endp_;

	// Each BMidiEndpoint object has a reference count, which 
	// indicates in how many places we are currently using that 
	// object. To increment the reference count, you call the
	// Acquire() function. When you are done with the object, 
	// you should call Release(). You cannot delete endpoint
	// objects yourself; as soon as the reference count drops 
	// to zero, the Midi Roster automatically deletes the object.

	endp->Acquire();

	ChangedName();
}

//------------------------------------------------------------------------------

EndpointItem::~EndpointItem()
{
	// The list item is destroyed, so we have no more use 
	// for the endpoint it represents. We call Release()
	// to balance the Acquire() we did in our constructor.

	endp->Release();
}

//------------------------------------------------------------------------------

void EndpointItem::ChangedName()
{
	BString text;
	text << endp->ID() << ": " << endp->Name();
	SetText(text.String());
}

//------------------------------------------------------------------------------
