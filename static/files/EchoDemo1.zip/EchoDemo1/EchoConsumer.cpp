
#include <MidiProducer.h>

#include "EchoConsumer.h"

//------------------------------------------------------------------------------

EchoConsumer::EchoConsumer(
		const char* name, BMidiLocalProducer* output_)
	: BMidiLocalConsumer(name)
{
	output = output_;
	notes  = 2;
	delay  = 200;
}

//------------------------------------------------------------------------------

void EchoConsumer::NoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	for (int32 t = 0; t < notes + 1; ++t)
	{
		output->SprayNoteOn(channel, note, velocity, time);
		time += delay * 1000;
		velocity /= 2;
	}
}

//------------------------------------------------------------------------------

void EchoConsumer::NoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	for (int32 t = 0; t < notes + 1; ++t)
	{
		output->SprayNoteOff(channel, note, velocity, time);
		time += delay * 1000;
		velocity /= 2;
	}
}

//------------------------------------------------------------------------------
