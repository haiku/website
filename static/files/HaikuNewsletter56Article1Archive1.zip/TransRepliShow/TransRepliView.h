// TransRepliView.h

#ifndef TRANS_REPLI_VIEW_H
#define TRANS_REPLI_VIEW_H

#ifndef REPLI_DRAGGER_H
#include "RepliDragger.h"
#endif


#include <Bitmap.h>
#include <Dragger.h>
#include <View.h>
#include <stdio.h>
#include <TranslationUtils.h>
#include <Path.h>
#include <Entry.h>
#include <Window.h>
#include <Alert.h>

class _EXPORT TransRepliView;

class TransRepliView : public BView
{
	
	public:
											TransRepliView(BRect frame);
											TransRepliView(BMessage *data);
											~TransRepliView();
		
		virtual void 			Draw(BRect);
		virtual void 			MessageReceived(BMessage *msg);
		virtual status_t 	Archive(BMessage *data, bool deep = true) const;
		static 						BArchivable *Instantiate(BMessage *archive);
		void							CreateDragger(void);
		
		void 							AboutRequested();

	private:
		bool 					fReplicated;
		BBitmap 			*fBitmap;
		RepliDragger	*fRepliDragger;
		BMessage			fArchive;
		
};

#endif