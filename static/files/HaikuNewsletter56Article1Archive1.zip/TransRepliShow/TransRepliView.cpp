// TransRepliView.cpp

#ifndef TRANS_REPLI_VIEW_H
#include "TransRepliView.h"
#endif



TransRepliView :: TransRepliView(BRect frame) 
				        : BView(frame, "TransRepliShowView", B_FOLLOW_NONE, B_WILL_DRAW)
{
	fReplicated = false;
	fBitmap = NULL;
	
	CreateDragger();
}


TransRepliView :: TransRepliView(BMessage *archive) 
					 			: BView(archive)
{
	fReplicated = true;
	fBitmap 		= new BBitmap(archive);

	CreateDragger();
	
	fArchive = BMessage( B_ARCHIVED_OBJECT);	
	Archive(&fArchive,true);	
	fRepliDragger -> GetArchive(&fArchive);
}


TransRepliView :: ~TransRepliView()
{
	delete fBitmap;
}


void TransRepliView::Draw(BRect updateRect)
{
	if(fBitmap) DrawBitmap(fBitmap, B_ORIGIN);
}



void TransRepliView :: MessageReceived(BMessage *msg)
{
	switch(msg->what) 
	{
		case B_SIMPLE_DATA: 
		{
			entry_ref ref;
			msg->FindRef("refs", &ref);
			BEntry entry(&ref);
			BPath path(&entry);

			delete fBitmap;
			fBitmap = BTranslationUtils::GetBitmap(path.Path());			
	
			if(fBitmap != NULL) 
			{
				BRect rect = fBitmap->Bounds();
				if(!fReplicated)
					Window()->ResizeTo(rect.right, rect.bottom);
			
				ResizeTo(rect.right, rect.bottom);
				Invalidate();
	
				fArchive = BMessage( B_ARCHIVED_OBJECT);
				Archive(&fArchive,true);	
			
				fRepliDragger -> GetArchive(&fArchive);
				fRepliDragger -> GetBitmap(fBitmap);
			}
		}
		break;

    case B_ABOUT_REQUESTED:
    { 
      AboutRequested(); 
    }
    break; 
	
	
		default:
			BView::MessageReceived(msg);
		break;
	}
}


BArchivable *TransRepliView :: Instantiate(BMessage *data)
{
	return new TransRepliView(data);
}



status_t TransRepliView :: Archive(BMessage *archive, bool deep) const
{
	BView :: Archive(archive, deep);
	archive -> AddString("add_on", "application/x-vnd.Reh-TransRepliShow");
	archive -> AddString("class", "TransRepliShow");
	if(fBitmap) fBitmap->Archive(archive);

	//archive -> PrintToStream();
	return B_OK;
}


void TransRepliView :: CreateDragger()
{
	BRect frame = Bounds();
	frame.left 	= frame.right - 7;
	frame.top 	= frame.bottom - 7;
	
	fRepliDragger = new RepliDragger(frame, this);
	AddChild(fRepliDragger);	
	fRepliDragger -> GetBitmap(fBitmap);
}



void TransRepliView  :: AboutRequested()
{
   BAlert *alert = new BAlert("", "TransRepliShow from H. Reh", "OK");
   alert->Go();
}


