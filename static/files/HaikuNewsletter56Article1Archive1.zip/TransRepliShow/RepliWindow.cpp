// RepliWindow.cpp

#ifndef REPLI_WINDOW_H
#include "RepliWindow.h"
#endif

#ifndef _APPLICATION_H
#include <Application.h>
#endif

#include <Beep.h>

RepliWindow :: RepliWindow() 
						 : BWindow(BRect(100,100,350,350), "Transparent RepliShow", 
							 B_TITLED_WINDOW, B_NOT_RESIZABLE | B_NOT_ZOOMABLE | B_ASYNCHRONOUS_CONTROLS)
{	
	TransRepliView *transRepliView = new TransRepliView(Bounds());
	AddChild(transRepliView);
}

bool RepliWindow::QuitRequested()
{
	be_app->PostMessage(B_QUIT_REQUESTED);
	return true;
}



