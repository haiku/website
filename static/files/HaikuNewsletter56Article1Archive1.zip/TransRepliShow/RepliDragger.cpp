/* 
			 RepliDragger.cpp
		 Copyright 2004,  H.Reh    
*/

#ifndef REPLI_Dragger_H
#include "RepliDragger.h"
#endif


RepliDragger :: RepliDragger(BRect frame, BView *target) 
				      : BDragger(frame, target, B_FOLLOW_RIGHT|B_FOLLOW_BOTTOM, B_WILL_DRAW)
{
	fBitmap 	= NULL;
	fArchive 	= NULL;
}


void RepliDragger ::MouseDown( BPoint where )													// mouse down
{ 
	BPoint cursor;
	uint32 buttons;
	
	SetMouseEventMask( B_POINTER_EVENTS, 0 ); 													// View can receive mouse-events
	GetMouse(&cursor,&buttons);

	if ( (fBitmap != NULL) && (fArchive != NULL) && (buttons & B_PRIMARY_MOUSE_BUTTON) )
	{
		BPoint origBitmap;
		BRect bitmapRect  = fBitmap -> Bounds();													// get boundaries of image
	  BBitmap *bitmap 	= new BBitmap(bitmapRect, B_RGB32,true);				// create bitmap for d&d 		
		memcpy(bitmap->Bits(), fBitmap->Bits(), fBitmap->BitsLength());		// copy bitmap
		
		origBitmap = BPoint(bitmapRect.Width(),bitmapRect.Height());			// position relative to bitmap
		origBitmap = origBitmap - BPoint(7-where.x, 7-where.y);
		DragMessage( fArchive, bitmap, B_OP_BLEND, origBitmap, NULL); 		// bitmap will be freed after dragging 
	}
	
	BDragger :: MouseDown(where);																				// handle BDragger mouse down events
}


void RepliDragger :: GetBitmap(BBitmap *bitmap)							
{ 
	fBitmap = bitmap;	
}

void RepliDragger :: GetArchive(BMessage *archive)							
{ 
	fArchive = archive;	
}

