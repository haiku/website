/* 
			 RepliDragger.h
		 Copyright 2004,  H.Reh    
*/

#ifndef REPLI_DRAGGER_H
#define REPLI_DRAGGER_H


#include <Bitmap.h>
#include <Dragger.h>
#include <Beep.h>
#include <Message.h>
#include <Alert.h>


class RepliDragger : public BDragger
{
	public:
										RepliDragger(BRect frame, BView *target);
	
			virtual void 	MouseDown( BPoint where ); 
			
			void GetBitmap(BBitmap *bitmap);
			void GetArchive(BMessage *archive);

	private:
			BBitmap 	*fBitmap;
			BMessage	*fArchive;
};

#endif