
#ifndef MIDI_WATCHER_H
#define MIDI_WATCHER_H

#include <Looper.h>

/**
 * @brief Midi Kit debug class
 *
 * Prints, on standard output, a text description of each Midi Roster
 * notification it receives. You use MidiWatcher to debug and monitor
 * your application; it has no other purpose. 
 *
 * Do not "delete" the object or call Quit() yourself. The MidiWatcher
 * object terminates and deletes itself when you tell it to stop watching.
 */
class MidiWatcher : public BLooper
{
public:

	/**
	 * Creates a new MidiWatcher object.
	 *
 	 * @param forward Only one BLooper at a time can be watching the
	 *        Midi Roster notifications. You can tell MidiWatcher to
	 *        forward all notifications to another BLooper.
	 *   
	 * @param dumpMessage Whether to print the actual contents of the
	 *        notification BMessage to stdout as well.
	 */
	MidiWatcher(BLooper* forward = NULL, bool dumpMessage = false);

	virtual void MessageReceived(BMessage* msg);

	void StartWatching();
	void StopWatching();

private:
	typedef BLooper super;

	virtual ~MidiWatcher() { };

	void HandleMidiEvent(BMessage* msg);
	void Description(int32 op);
	void Endpoint(int32 id);

	BLooper* forward;
	bool dumpMessage;
};

#endif // MIDI_WATCHER_H
