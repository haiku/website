
#include <stdio.h>

#include "MidiText.h"

//------------------------------------------------------------------------------

MidiText::MidiText() : BMidiLocalConsumer("debug info")
{
	startTime = 0;
}

//------------------------------------------------------------------------------

void MidiText::NoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"NOTE OFF; channel = %u, note = %u, velocity = %u\n",
		channel, note, velocity);
}

//------------------------------------------------------------------------------

void MidiText::NoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"NOTE ON; channel = %u, note = %u, velocity = %u\n",
		channel, note, velocity);
}

//------------------------------------------------------------------------------

void MidiText::KeyPressure(
	uchar channel, uchar note, uchar pressure, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"KEY PRESSURE; channel = %u, note = %u, pressure = %u\n",
		channel, note, pressure);
}

//------------------------------------------------------------------------------

void MidiText::ControlChange(
	uchar channel, uchar controlNumber, uchar controlValue, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"CONTROL CHANGE; channel = %u, control = %u, value = %u\n",
		channel, controlNumber, controlValue);
}

//------------------------------------------------------------------------------

void MidiText::ProgramChange(
	uchar channel, uchar programNumber, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"PROGRAM CHANGE; channel = %u, program = %u\n",
		channel, programNumber);
}

//------------------------------------------------------------------------------

void MidiText::ChannelPressure(uchar channel, uchar pressure, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"CHANNEL PRESSURE; channel = %u, pressure = %u\n",
		channel, pressure);
}

//------------------------------------------------------------------------------

void MidiText::PitchBend(uchar channel, uchar lsb, uchar msb, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"PITCH BEND; channel = %u, lsb = %x, msb = %x\n",
		channel, lsb, msb);
}

//------------------------------------------------------------------------------

void MidiText::SystemExclusive(void* data, size_t dataLength, bigtime_t time)
{
	WaitAndPrint(time);

	printf("SYSTEM EXCLUSIVE;\n");
	for (size_t t = 0; t < dataLength; ++t) 
	{
		printf("%x ", ((uint8*) data)[t]);
	}
	printf("\n");
}

//------------------------------------------------------------------------------

void MidiText::SystemCommon(
	uchar status, uchar data1, uchar data2, bigtime_t time)
{
	WaitAndPrint(time);
	printf(
		"SYSTEM COMMON; status = %x, data1 = %x, data2 = %x\n",
		status, data1, data2);
}

//------------------------------------------------------------------------------

void MidiText::SystemRealTime(uchar status, bigtime_t time)
{
	WaitAndPrint(time);
	printf("SYSTEM REAL TIME; status = %x\n", status);
}

//------------------------------------------------------------------------------

void MidiText::TempoChange(int32 beatsPerMinute, bigtime_t time) 
{ 
	WaitAndPrint(time);
	printf("TEMPO CHANGE; bpm = %ld\n", beatsPerMinute);
} 

//------------------------------------------------------------------------------

void MidiText::AllNotesOff(bool justChannel, bigtime_t time) 
{ 
	WaitAndPrint(time);
	printf("ALL NOTES OFF;\n");
}

//------------------------------------------------------------------------------

void MidiText::ResetTimer(bool start)
{
	startTime = start ? system_time() : 0;
}

//------------------------------------------------------------------------------

void MidiText::WaitAndPrint(bigtime_t time) 
{
	if (startTime == 0) { startTime = time;	}

	snooze_until(time, B_SYSTEM_TIMEBASE);

	printf("%lld: ", (time - startTime));	
}

//------------------------------------------------------------------------------
