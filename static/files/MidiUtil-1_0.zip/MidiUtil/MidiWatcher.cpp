
#include <MidiRoster.h>
#include <MidiProducer.h>
#include <MidiConsumer.h>
#include <stdio.h>

#include "MidiWatcher.h"

//------------------------------------------------------------------------------

MidiWatcher::MidiWatcher(BLooper* forward, bool dumpMessage)
{
	this->forward = forward;
	this->dumpMessage = dumpMessage;
}

//------------------------------------------------------------------------------

void MidiWatcher::MessageReceived(BMessage* msg)
{
	switch (msg->what)
	{
		case B_MIDI_EVENT: 
		{
			HandleMidiEvent(msg);

			if (forward != NULL)
			{
				forward->PostMessage(msg);
			}
			break;
		}

		default:
		{
			super::MessageReceived(msg); 
			break;
		}
	}
}

//------------------------------------------------------------------------------

void MidiWatcher::StartWatching() 
{
	Run();

	BMessenger msngr(this);
	BMidiRoster::StartWatching(&msngr);
}

//------------------------------------------------------------------------------

void MidiWatcher::StopWatching() 
{
	BMidiRoster::StopWatching();

	Lock();
	Quit();
}

//------------------------------------------------------------------------------

void MidiWatcher::HandleMidiEvent(BMessage* msg)
{
	if (dumpMessage)
	{
		msg->PrintToStream();
	}

	int32 op;
	if (msg->FindInt32("be:op", &op) != B_OK) 
	{ 
		printf("!!! invalid be:op\n"); return; 
	}

	Description(op);

	switch (op)
	{
		case B_MIDI_REGISTERED:
		case B_MIDI_UNREGISTERED:
		case B_MIDI_CHANGED_NAME:
		{
			int32 id;
			if (msg->FindInt32("be:id", &id) != B_OK) 
			{
				printf("id = invalid"); break;
			}

			Endpoint(id);

			printf("\n");
			break;
		}

		case B_MIDI_CONNECTED:
		case B_MIDI_DISCONNECTED:
		{
			int32 prod;
			if (msg->FindInt32("be:producer", &prod) != B_OK) 
			{
				printf("producer = invalid"); break; 
			}

			int32 cons;
			if (msg->FindInt32("be:consumer", &cons) != B_OK)
			{
				printf("consumer = invalid"); break; 
			}

			Endpoint(prod);
			printf(" %s ", op == B_MIDI_CONNECTED ? "--->" : "-X->");
			Endpoint(cons);

			printf("\n");
			break;		
		}

		case B_MIDI_CHANGED_LATENCY:
		{
			// This notification is never sent! Due to a bug in
			// the midi_server, watchers receive a CHANGED_NAME
			// notification with the latency information...
			break;
		}

		case B_MIDI_CHANGED_PROPERTIES:
		{
			int32 id;
			if (msg->FindInt32("be:id", &id) != B_OK) 
			{
				printf("id = invalid"); break;
			}

			Endpoint(id);

			BMessage props;
			if (msg->FindMessage("be:properties", &props) != B_OK)
			{
				printf("properties = invalid"); break;
			}

			printf("\n");
			props.PrintToStream();
			return;
		}
	}
}

//------------------------------------------------------------------------------

void MidiWatcher::Description(int32 op)
{
	switch (op)
	{
		case B_MIDI_REGISTERED:
			printf("B_MIDI_REGISTERED; "); break;
		
		case B_MIDI_UNREGISTERED:
			printf("B_MIDI_UNREGISTERED; "); break;

		case B_MIDI_CONNECTED:
			printf("B_MIDI_CONNECTED; "); break;

		case B_MIDI_DISCONNECTED:
			printf("B_MIDI_DISCONNECTED; "); break;

		case B_MIDI_CHANGED_NAME:
			printf("B_MIDI_CHANGED_NAME; "); break;

		case B_MIDI_CHANGED_LATENCY:
			printf("B_MIDI_CHANGED_LATENCY; "); break;

		case B_MIDI_CHANGED_PROPERTIES:
			printf("B_MIDI_CHANGED_PROPERTIES; "); break;

		default:
			printf("B_MIDI_???; op = 0x%lx", op); break;
	}
}

//------------------------------------------------------------------------------

void MidiWatcher::Endpoint(int32 id)
{
	BMidiEndpoint* endpoint = BMidiRoster::FindEndpoint(id);

	if (endpoint == NULL)
	{
		printf("id = %ld, cannot find endpoint", id);
	}
	else
	{
		printf(
			"id = %ld, type = %s, name = '%s'", id, 
			endpoint->IsProducer() ? "producer" : "consumer",
			endpoint->Name());

		endpoint->Release();
	}
}

//------------------------------------------------------------------------------
