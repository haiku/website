
/*
	What does this app do?

	1.  It publishes a SynthBridge consumer endpoint that drives the
        internal GM softsynth.
	2.	It publishes the input and output endpoints of a simple filter.

	What can you do with it?

	1.	Use PatchBay to hook up a virtual MIDI keyboard to the SynthBridge
		consumer.
	2.	Connect a virtual MIDI keyboard to the input of the filter and the
		SynthBridge to the output.
 */

#include <Application.h>
#include <Bitmap.h>
#include <MidiRoster.h>

#include "MidiIcons.h"
#include "MidiText.h"
#include "SimpleMidiFilter.h"
#include "SynthBridge.h"

//------------------------------------------------------------------------------

class LameEchoFilter : public SimpleMidiFilter
{
public:

	LameEchoFilter() : SimpleMidiFilter("Lame Echo..o..o..o Filter") { }

protected:

	virtual void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time)
	{
		SprayNoteOn(channel, note, velocity, time);
		SprayNoteOn(channel, note, velocity / 2, time + 200000);
		SprayNoteOn(channel, note, velocity / 4, time + 400000);
		SprayNoteOn(channel, note, velocity / 8, time + 600000);
	}
};

//------------------------------------------------------------------------------

class TestApp : public BApplication
{
public:
	TestApp();
	virtual ~TestApp();

private:
	LameEchoFilter filter;
	SynthBridge* synth;
	MidiText* dump;
};

//------------------------------------------------------------------------------

TestApp::TestApp()
	: BApplication("application/x-vnd.midiutil.testapp")
{
	BBitmap* largeIcon = NULL;
	BBitmap* miniIcon  = NULL;

	get_app_icons(&largeIcon, &miniIcon);

	synth = new SynthBridge;
	synth->Init(B_BIG_SYNTH);
	synth->Register();

	set_endpoint_icons(synth, largeIcon, miniIcon);
	
	delete largeIcon;
	delete miniIcon;

	filter.Register();

	dump = new MidiText();
	filter.Output()->Connect(dump);
}

//------------------------------------------------------------------------------

TestApp::~TestApp()
{
	filter.Output()->Disconnect(dump);
	filter.Unregister();

	dump->Release();

	synth->Unregister();
	synth->Release();
}

//------------------------------------------------------------------------------

int main()
{
	TestApp app;
	app.Run();
	return 0;
}

//------------------------------------------------------------------------------
