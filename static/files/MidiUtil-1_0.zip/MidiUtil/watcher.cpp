
#include <Application.h>
#include <stdio.h>
#include "MidiWatcher.h"

//------------------------------------------------------------------------------

class WatcherApp : public BApplication
{
public:
	WatcherApp();
	virtual ~WatcherApp();
	virtual void MessageReceived(BMessage* msg);

private:
	typedef BApplication super;
	MidiWatcher* watcher;
};

//------------------------------------------------------------------------------

WatcherApp::WatcherApp() 
	: BApplication("application/x-vnd.obos-midi-watcher")
{
	// If you pass "this" instead of "NULL" to the MidiWatcher constructor,
	// then all Midi Roster notifications will be forwarded to WatcherApp's
	// MessageReceived() handler as well.

	watcher = new MidiWatcher(NULL, true);
	watcher->StartWatching();
}

//------------------------------------------------------------------------------

WatcherApp::~WatcherApp()
{
	watcher->StopWatching();
}

//------------------------------------------------------------------------------

void WatcherApp::MessageReceived(BMessage* msg)
{
	printf("[APP] ");
	msg->PrintToStream();
	super::MessageReceived(msg);
}

//------------------------------------------------------------------------------

int main()
{
	WatcherApp watcher;
	watcher.Run();
	return 0;
}

//------------------------------------------------------------------------------
