
#ifndef MIDI_TEXT_H
#define MIDI_TEXT_H

#include <MidiConsumer.h>

/**
 * @brief Midi Kit debug class
 *
 * Prints, on standard output, a text description of each MIDI message it
 * receives. You use MidiText objects to debug and monitor your application;
 * it has no other purpose.
 *
 * The timestamp in MidiText's output is relative to an internal timer. You
 * can set this timer to 0 with ResetTimer(). If "start" is false, the timer
 * doesn't start ticking until the next MIDI message is received.
 */
class MidiText : public BMidiLocalConsumer
{
public:

	MidiText();

	virtual void NoteOff(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void KeyPressure(
		uchar channel, uchar note, uchar pressure, bigtime_t time);

	virtual	void ControlChange(
		uchar channel, uchar controlNumber, uchar controlValue, 
		bigtime_t time);

	virtual	void ProgramChange(
		uchar channel, uchar programNumber, bigtime_t time);

	virtual	void ChannelPressure(
		uchar channel, uchar pressure, bigtime_t time);

	virtual	void PitchBend(
		uchar channel, uchar lsb, uchar msb, bigtime_t time);

	virtual	void SystemExclusive(
		void* data, size_t dataLength, bigtime_t time);

	virtual	void SystemCommon(
		uchar status, uchar data1, uchar data2, bigtime_t time);

	virtual	void SystemRealTime(
		uchar status, bigtime_t time);

	virtual	void TempoChange(
		int32 beatsPerMinute, bigtime_t time);

	virtual void AllNotesOff(
		bool justChannel, bigtime_t time);

	void ResetTimer(bool start = false);

private:

	void WaitAndPrint(bigtime_t time);

	bigtime_t startTime;
};

#endif // MIDI_TEXT_H
