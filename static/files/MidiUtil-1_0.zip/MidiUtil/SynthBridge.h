
#ifndef SYNTH_BRIDGE_H
#define SYNTH_BRIDGE_H

#include <MidiConsumer.h>
#include <MidiSynth.h>

/**
 * @brief Lets you use the midi1 softsynth with midi2 endpoints.
 *
 * A consumer endpoint that passes any incoming events to the Midi Kit's
 * internal General MIDI synthesizer. In other words, it wraps the midi1
 * softsynth in a midi2 endpoint.
 *
 * After you create a SynthBridge endpoint, and before you connect it to
 * anything, you must first initialize the softsynth. You either use the
 * convenience method Init() for this, or you access the BMidiSynth object 
 * directly using the MidiSynth() method. 
 */
class SynthBridge : public BMidiLocalConsumer
{
public:

	SynthBridge();

	bool Init(synth_mode mode);

	BMidiSynth* MidiSynth();

	virtual	void NoteOff(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void KeyPressure(
		uchar channel, uchar note, uchar pressure, bigtime_t time);

	virtual	void ControlChange(
		uchar channel, uchar controlNumber, uchar controlValue, 
		bigtime_t time);

	virtual	void ProgramChange(
		uchar channel, uchar programNumber, bigtime_t time);

	virtual	void ChannelPressure(
		uchar channel, uchar pressure, bigtime_t time);

	virtual	void PitchBend(
		uchar channel, uchar lsb, uchar msb, bigtime_t time);

	virtual void AllNotesOff(
		bool justChannel, bigtime_t time);

protected:

	virtual ~SynthBridge() { }

private:

	BMidiSynth midiSynth;
};

#endif // SYNTH_BRIDGE_H
