// Warrior_Read_1.cpp
// Reads data from Port P0,P1
// Copyright H.Reh 2004


#include <USBKit.h>
#include <stdio.h>
#include <Beep.h>

int main(int argc, char *argv[])
{
	if(argc!=2) 
	{
		printf("Usage: Warrior24 <usbdevice>\n");
		return 1;
	}
	
	USBDevice dev(argv[1]);

	if( dev.InitCheck() || dev.SetConfiguration(dev.ConfigurationAt(0)) ) 
	{
		printf("Can't open and configure: %s\n",argv[1]);
		return 1;
	}
	ssize_t size = 0;

	uchar report[2];
	uchar reply[2];



	report[0] = ~(0x08);		// switch on the red LED -> Port 0, Bit 3, on-> force pin to GND
	report[1] = 0xFF;				// Port 1 all pins high

	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report
	
  if ( size != sizeof(report) ) printf("Write-Error");
	beep();
	snooze(100000);	
		
	const USBEndpoint *ept = dev.ActiveConfiguration()->InterfaceAt(0)->EndpointAt(0);	
	size = ept -> InterruptTransfer(reply,sizeof(reply));
	size = ept -> InterruptTransfer(reply,sizeof(reply));
	if (size == sizeof(reply))
		printf("Port 0, Port 1:  0x%02X 0x%02X\n ", reply[0], reply[1]); 
	else
   	printf("Wrong size read = %d\n",(int)size);


	report[0] = 0xFF;				// Port 1 all pins high, switch off the red LED
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report

	printf("The red LED is off: size written = %d\n",(int)size);
	printf("End of program \n");



	return 0;
}
