// Warrior24_Read_Direct_1.cpp
// Read data from port P0,P1

#include <USBKit.h>
#include <stdio.h>
#include <Beep.h>
#include <iostream.h>




bool IO16_Read_Direct(USBDevice *dev, uchar *data)
{	
	const 	USBEndpoint *ept = dev->ActiveConfiguration()->InterfaceAt(1)->EndpointAt(0);	// Endpoint IF1		
	if (ept == NULL) return (false);

	uchar reply[8];	
	uchar report[8] = {0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	dev->ControlTransfer(USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,
											 USB_REQUEST_SET_CONFIGURATION, 0, 1, 8, report);	

	if ( (ept ->InterruptTransfer(reply,8) ) == 8)
	{
		data[0] = reply[1];
		data[1] = reply[2];
	}

	// wegen odd/even problem
	dev->ControlTransfer(USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,
											 USB_REQUEST_SET_CONFIGURATION, 0, 1, 8, report);	
	printf(" Port0 - Port1:  0x%02X 0x%02X \n", reply[1],reply[2]);
	if ( (ept ->InterruptTransfer(reply,8) ) == 8) 
	{
		printf(" Port0 - Port1:  0x%02X 0x%02X \n", reply[1],reply[2]);
		return (true);
	}
	else return (false);
}



int main(int argc, char *argv[])
{
	if(argc!=2) 
	{
		printf("Usage: Warrior24 <usbdevice>\n");
		return 1;
	}
	
	USBDevice dev(argv[1]);

	if(dev.InitCheck() || dev.SetConfiguration(dev.ConfigurationAt(0)))
	{
		printf("Cannot open and configure: %s\n",argv[1]);
		return 1;
	}
	ssize_t size = 0;


	uchar report[2];
	report[0] = ~(0x08);		// switch on the red LED -> Port 0, Bit 3, on-> force pin to GND
	report[1] = 0xFF;				// Port 1 all pins high

	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report
	
  if ( size != sizeof(report) ) printf("Write-Error");
	snooze(100000);	
			
	
	uchar report2[8] = {0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															1,																						// index : Interface 1 (IF01)
															sizeof(report2),															// length: 8 bytes->IF1
															report2);																			// report2
	printf("size = %d\n",(int)size);

	
	uchar reply[8];	
	const USBEndpoint *ept = dev.ActiveConfiguration()->InterfaceAt(1)->EndpointAt(0);	
	if ( (ept ->InterruptTransfer(reply,8) ) == 8) 
	{
		printf(" ReportID, Port0...Port3, ...:  0x%02X  0x%02X  0x%02X  0x%02X  0x%02X  0x%02X  0x%02X 0x%02X \n", 
																			reply[0],reply[1],reply[2],reply[3],reply[4],reply[5],reply[6],reply[7]);
	}

	// avoid odd/even problem of USB bus manager
	dev.ControlTransfer(USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,
											USB_REQUEST_SET_CONFIGURATION, 0, 1, sizeof(report2), report2);	
	ept ->InterruptTransfer(reply,8);


	report[0] = 0xFF;		// Port 0 all pins high, LED is off
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report

	return 0;
}
