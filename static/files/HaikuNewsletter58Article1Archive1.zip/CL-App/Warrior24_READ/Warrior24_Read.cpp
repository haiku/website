// Warrior_Read.cpp
// Read data from port P0,P1
// Copyright H.Reh 2004


#include <USBKit.h>
#include <stdio.h>


bool ReadAllPorts(USBDevice *dev, uchar *data)
// All ports are read
//Standard mode -> IF0 (Interface 0)
{	
	snooze(10000);
	uchar reply[2];	

	const USBEndpoint *ept = dev->ActiveConfiguration()->InterfaceAt(0)->EndpointAt(0);	

	if ( (ept ->InterruptTransfer(reply,sizeof(reply)) ) == sizeof(reply))
	{
		for (int i=0; i<2; i++) data[i] = reply[i];
		return (true);
	}
	else return (false);
}



int main(int argc, char *argv[])
{
	if(argc!=2) 
	{
		printf("Usage: Warrior24 <usbdevice>\n");
		return 1;
	}
	
	USBDevice dev(argv[1]);

	if( dev.InitCheck() || dev.SetConfiguration(dev.ConfigurationAt(0)) ) 
	{
		printf("Can't open and configure: %s\n",argv[1]);
		return 1;
	}

	uchar data[2];
	
	data[0] = 0xFF;
	data[1] = 0xFF;

	ssize_t size = 0;
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request   
															0,																						// value
															0,																						// index : IF0
															sizeof(data),																	// length: 2 bytes->IF0
															data);																				// data
	
  printf("size written = %d\n",(int)size);
  if ( size != sizeof(data) ) printf("Write-Error");
	// all ports input mode


	uchar allPorts[2];

	for(;;)
	{
		if ( ReadAllPorts(&dev, allPorts) ) 
		{
			printf(" Port0 - Port1:  0x%02X 0x%02X \n", allPorts[0],allPorts[1]);		
		}
	}
	return 0;
}
