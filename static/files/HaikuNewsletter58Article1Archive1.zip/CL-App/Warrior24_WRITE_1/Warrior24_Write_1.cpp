// Warrior_Write_1.cpp
// Write data to Port 0 and Port 1
// Copyright 2004, H. Reh

#include <USBKit.h>
#include <stdio.h>
#include <Beep.h>


int main(int argc, char *argv[])
{
	if(argc!=2) 
	{
		printf("Usage: Warrior24 <usbdevice>\n");
		return 1;
	}
	
	USBDevice dev(argv[1]);
	uchar report[2];
	
	report[0] = ~(0x08);		// switch on the red LED -> Port 0, Bit 3, on-> force pin to GND
	report[1] = 0xFF;				// Port 1 all pins high

	if(dev.InitCheck() || dev.SetConfiguration(dev.ConfigurationAt(0)))			// configuration 0
	{
		printf("Cannot open and configure: %s\n",argv[1]);
		return 1;
	}
	
	ssize_t size = 0;
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report
	
	printf("The red LED is  on: size written = %d\n",(int)size);
	beep();
	snooze(3000000);


	report[0] = 0xFF;		// Port 0 all pins high, LED is off
	size = dev.ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
															USB_REQUEST_SET_CONFIGURATION,								// request value  
															0,																						// value
															0,																						// index : Interface 0 (IF0)
															sizeof(report),																// length: 2 bytes->IF0
															report);																			// report
	
	printf("The red LED is off: size written = %d\n",(int)size);
	printf("End of program \n");
	
	return 0;
}
