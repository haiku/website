/*****************************************************************************/
// TheUSBRoster
// Written by Hartmut Reh
//
// TheUSBRoster.cpp
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/

 
#include "TheUSBRoster.h"
#include "TheMessages.h"
#include <Message.h>
#include <Looper.h>
#include <Beep.h>
#include <string.h>


TheUSBRoster :: TheUSBRoster(BWindow *window)
{
	fTheWindow 	= window;
}


TheUSBRoster :: ~TheUSBRoster()
{
	Stop();
}


status_t TheUSBRoster :: DeviceAdded(USBDevice *dev)
{
	if( (dev->VendorID() 									== fVendorID) 				&& 
			(dev->ProductID() 								== fProductID)  			&&
			(!strncmp (dev->SerialNumberString(),fSerialNumber,8) ) &&
			(!strcmp  (dev->ProductString(),PRODUCT_STRING) ) 			)
		{
				devs.AddItem(fIOWarrior24 = new IOWarrior24(dev) );
				BMessage message = BMessage(DEVICE_ADDED_MSG);
				if (fTheWindow) fTheWindow->PostMessage(&message);
				return B_OK;
			}
			else
				return B_ERROR;
}


void TheUSBRoster :: DeviceRemoved(USBDevice *dev)
{
	IOWarrior24 *warrior;
	
	for(int i=0;( warrior= (IOWarrior24 *)devs.ItemAt(i) ) ;i++)
	{
		if(warrior->GetDevice() == dev)
		{
			devs.RemoveItem(i);
			delete warrior;
			warrior = NULL;
			BMessage message = BMessage(DEVICE_REMOVED_MSG);
			if (fTheWindow) fTheWindow->PostMessage(&message);
		}
	}	
}	


void	TheUSBRoster :: DeviceData(int32 vendorID,int32 productID,const char* serialNumber)
{
	fVendorID		= vendorID;
	fProductID	=	productID;
	strcpy(fSerialNumber,serialNumber);
}


