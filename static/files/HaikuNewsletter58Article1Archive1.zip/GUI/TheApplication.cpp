/*****************************************************************************/
// TheApplication
// Written by Hartmut Reh
//
// TheApplication.cpp
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/


#include "TheApplication.h"
#include "TheMessages.h"


TheApplication :: TheApplication()
		  		  		: IEApplication("application/x-vnd.reh-IOW24_IO16")
{
	fMainWindow = new MainWindow();
	SetPulseRate(750000);
	fPulse = false;
}

void TheApplication::MessageReceived(BMessage* message)
{	
	switch(message->what)
	{
		case SEND_DATA_MSG:	
			{
				int16 data;
				if ( message->FindInt16("Read_IO16",	&data) == B_OK )
				{
					fMainWindow->WriteDisplay((uint16)data);
				}
			}
			break;
		
		default:
				BApplication::MessageReceived(message);
			break;
	}
	
}

void TheApplication :: AboutRequested()
{
	BAlert	*alert = new BAlert("", "IOW24_IO16  written by H.Reh  2004" "\n" "\n"
																	"The GUI was created with InterfaceElements (Attila Mezei)" "\n"
																	"Please read the *Be Sample Code License* "	"\n"															
																	"Please read the *OBOS Sample Code License* "	"\n"															
																	,"OK");
	alert -> Go(NULL);
}



void TheApplication :: Pulse()
{
	if (fMainWindow -> ThreadRunning() )
	{
		if (fPulse)
			fMainWindow -> WriteModeBoxLabel("  Standard Mode: 16bit- I/O");
		else
			fMainWindow -> WriteModeBoxLabel("  Standard Mode: 16bit- I/O ... waiting for data ...");
		fPulse = !fPulse;
	}
	else
	{
		if (fPulse)
			fMainWindow -> WriteModeBoxLabel("  Standard Mode: 16bit- I/O");
		fPulse = false;
	}
}




int main()
{	
	TheApplication	theApplication;
	theApplication.Run();

	return(0);
}
