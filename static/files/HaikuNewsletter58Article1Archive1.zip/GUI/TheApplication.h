/*****************************************************************************/
// TheApplication
// Written by Hartmut Reh
//
// TheApplication.h
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/




#if !defined(THE_APPLICATION_H)
#define THE_APPLICATION_H


#include "IEApplication.h"
#include "MainWindow.h"

IEResourceHandler *resourcehandler;

class TheApplication : public IEApplication 
{
	public:
											TheApplication();
				virtual void	MessageReceived(BMessage* message);
				virtual void	AboutRequested();
				virtual void	Pulse(void);
				
	
	private:
				MainWindow	*fMainWindow;
				bool				fPulse;	
				bool				fToggleOld;				
};

#endif 
