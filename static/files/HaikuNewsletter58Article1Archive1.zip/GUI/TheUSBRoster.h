/*****************************************************************************/
// TheUSBRoster
// Written by Hartmut Reh
//
// TheUSBRoster.h
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/

#ifndef _THE_USB_ROSTER_H
#define _THE_USB_ROSTER_H

#include <Window.h>
#include <USBKit.h>
#include "IOWarrior24.h"

#define	PRODUCT_STRING	"IO-Warrior24"


class TheUSBRoster : public USBRoster
{
	public:
												TheUSBRoster(BWindow *window);
												~TheUSBRoster();
				
			virtual status_t 	DeviceAdded(USBDevice *dev);
			virtual void 			DeviceRemoved(USBDevice *dev);
			
			void							DeviceData(int32 vendorID,int32 productID,const char* serialNumber);
    	IOWarrior24				*fIOWarrior24;

	private:
		BLooper	*fTheWindow;	// For sending messages
		
		BList		devs;
		int32		fVendorID;
		int32		fProductID;
		char		fSerialNumber[10];
};
#endif