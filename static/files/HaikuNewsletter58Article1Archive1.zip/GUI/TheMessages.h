// TheMessages.h

#define DEVICE_ADDED_MSG					'dfaM'
#define DEVICE_REMOVED_MSG				'dfrM'

#define DEVICE_LED_CONTROL_MSG		'dleM'
#define SENT_TO_APP								'staM'

#define	SEND_DATA_MSG							'sdaM'
#define DEVICE_PORT0_CONTROL_MSG	'dp0M'
#define DEVICE_PORT1_CONTROL_MSG	'dp1M'

#define	SEARCH_USB_DEVICE					'sudM'
