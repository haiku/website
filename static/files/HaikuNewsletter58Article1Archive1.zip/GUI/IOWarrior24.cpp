/*****************************************************************************/
// IOWarrior24
// Written by Hartmut Reh
//
// IOWarrior24.cpp
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/

#include "IOWarrior24.h"
#include "TheMessages.h"
#include <Message.h>
#include <Application.h>


IOWarrior24 *threadIOWarrior;

void IOWarrior24 :: WarriorThread(bool readMode)
{
	resume_thread(fThreadID = spawn_thread(threadEntry,"IOWarrior24Thread",B_NORMAL_PRIORITY, NULL) );
	fBusy 		= true;
	fExit_now = false;
	fReadImmediate = readMode;
}


long threadEntry(void *arg)
{
	threadIOWarrior -> StartReadData();
	return B_NO_ERROR;
}




IOWarrior24 :: IOWarrior24(USBDevice *dev)
{
	threadIOWarrior = this;
	fBusy 					= false;
	fExit_now 			= false;	
	fDevice 				= dev;
	
	if (!fDevice-> SetConfiguration(fDevice -> ConfigurationAt(0)) )				
	{
		fEptIF0 = fDevice->ActiveConfiguration()->InterfaceAt(0)->EndpointAt(0);	// Endpoint IF0	Interrupt-Transfer
		fEptIF1 = fDevice->ActiveConfiguration()->InterfaceAt(1)->EndpointAt(0);	// Endpoint IF1	Interrupt-Transfer
		if ( fEptIF0 && fEptIF1)
 			ClearPorts();
	}
}


IOWarrior24 :: 	~IOWarrior24()
{
	if (fBusy)
	{
		 status_t res;
		 fExit_now = true;
		 wait_for_thread(fThreadID, &res);
	}
 	ClearPorts();
}


USBDevice *IOWarrior24 :: GetDevice(void)					// get USB device
{
	return fDevice;
}


void IOWarrior24 :: StartReadData(void)					// thread for data reading
{		
	uchar reply[2];
	bool result;		
	do
	{		
		if (!fReadImmediate)
				result = (fEptIF0 ->InterruptTransfer(reply,sizeof(reply))  == sizeof(reply) );
		else		
			result = IO16_Read_Immediate(reply);
		
		if (result)
		{
			int16	data = 0;
			data = reply[0]+ 256*reply[1];
			BMessage	msg(SEND_DATA_MSG);
			msg.MakeEmpty();
			msg.AddInt16("Read_IO16", data);		
			be_app->PostMessage(&msg);
		}
	}	while (!fExit_now);	
}


bool IOWarrior24 :: IO16_Read_Immediate(uchar *data)
{	
	uchar reply[8];	
	uchar report[8] = {0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	fDevice->ControlTransfer(USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,
											 		 USB_REQUEST_SET_CONFIGURATION, 0, 1, 8, report);	

	if ( (fEptIF1 -> InterruptTransfer(reply,8) ) == 8)
	{
		data[0] = reply[1];
		data[1] = reply[2];
	}

	// remove odd/even problem
	fDevice -> ControlTransfer(USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,
											 			 USB_REQUEST_SET_CONFIGURATION, 0, 1, 8, report);	
	if ( (fEptIF1 -> InterruptTransfer(reply,8) ) == 8) return (true);
	else return (false);
}





void IOWarrior24 :: StopReadData(void)	
{	
	if (fBusy)
	{
		 status_t res;
		 fExit_now = true;
		 wait_for_thread(fThreadID, &res);
		 fBusy = false;
	}		
}


bool IOWarrior24 :: WriteAllPorts(uint16 ports)
// Standard-Mode, data is written to port0,1
{	
	size_t size;
	size = fDevice->ControlTransfer(	USB_REQTYPE_CLASS |USB_REQTYPE_INTERFACE_OUT,	// request type
																		USB_REQUEST_SET_CONFIGURATION,								// request value  
																		0,																						// value
																		0,																						// index : IF0
																		2,																						// length: 2 bytes->IF0
																		&ports);																			// data

	if (size == 2) return (true);
	else return (false);
}


void IOWarrior24 :: ClearPorts()
{
	if (fDevice->InitCheck() == B_OK)
		WriteAllPorts(0xFFFF);					// all ports input mode
}
