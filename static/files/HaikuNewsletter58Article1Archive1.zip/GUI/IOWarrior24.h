/*****************************************************************************/
// IOWarrior24
// Written by Hartmut Reh
//
// IOWarrior24.h
//
//
// Copyright (c) 2004 OpenBeOS Project
//
/*****************************************************************************/


#include <USBKit.h>
#include <stdio.h>
#include <string.h>
#include <Beep.h>
#include <iostream.h>


long	threadEntry(void *arg);		// forward

class IOWarrior24
{
	public:
			IOWarrior24(USBDevice *dev);
			~IOWarrior24();

			USBDevice *GetDevice(void);	
			void			WarriorThread(bool readMode);		
			void 			StartReadData(void);
			void 			StopReadData(void);
			bool 			IO16_Read_Immediate(uchar *data);			
			bool 			WriteAllPorts(uint16 ports);
			void			ClearPorts();
	
	private:
			USBDevice 	*fDevice;
			thread_id		fThreadID;	
			bool				fExit_now;
			bool				fBusy;
			bool 				fReadImmediate;
		
			const USBEndpoint *fEptIF0;
			const USBEndpoint *fEptIF1;
};

