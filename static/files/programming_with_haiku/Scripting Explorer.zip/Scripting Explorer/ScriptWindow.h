/*
	ScriptWindow.h
	
	Copyright 1997 Be Incorporated, All Rights Reserved.
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef SCRIPT_WINDOW_H
#define SCRIPT_WINDOW_H

#include <Window.h>

class ScriptWindow : public BWindow 
{
public:
				ScriptWindow(BRect frame); 
};

#endif
