    Haiku System Sounds   
    Meditation time
    Copyright 2020, Dahuyn Lee <emailaddress@something.net>   
    Licensed under CC Attribution-ShareAlike 4.0 International.   
