// ThreadLocker.h

#ifndef THREAD_LOCKER_H
#define THREAD_LOCKER_H

#include <SupportDefs.h>

class BLocker;
class LockingInfo;
class Thread;

class ThreadLocker {
public:
							ThreadLocker(BLocker* metaLocker = NULL);
							~ThreadLocker();

			bool			ReadLock();
			status_t		ReadLockWithTimeout(bigtime_t timeout);
			void			ReadUnlock();
			bool			IsReadLocked(bool orWriteLock = true);

			bool			WriteLock();
			status_t		WriteLockWithTimeout(bigtime_t timeout);
			void			WriteUnlock();
			bool			IsWriteLocked();

private:
	inline	bool			_MetaLock();
	inline	void			_MetaUnlock();

			status_t		_ReadLock(uint32 flags, bigtime_t timeout);
			status_t		_WriteLock(uint32 flags, bigtime_t timeout);
			status_t		_WaitForLock(Thread* thread, LockingInfo* info,
										 uint32 flags, bigtime_t timeout);
			void			_CheckWaiting();
			void			_UnblockFirstWaiting(bool lockingSuccessful);
	inline	Thread*			_GetCurrentThread(LockingInfo** info);

			void			_ShortDump() const;

private:
			BLocker*		fMetaLocker;
			Thread*			fFirstWaiting;
			Thread*			fLastWaiting;
			int32			fReaderCount;
			Thread*			fWriter;
			int32			fWriterNestingCount;
			int32			fWriterReadNestingCount;
};

#endif	// THREAD_LOCKER_H
