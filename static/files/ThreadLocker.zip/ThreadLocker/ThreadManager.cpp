// ThreadManager.cpp

#include <map.h>
#include <stdio.h>

#include "Thread.h"
#include "ThreadManager.h"

// ThreadMap
/*!	\brief A thread_id -> Thread* map.
*/
class ThreadManager::ThreadMap : public map<thread_id, Thread*> {
};

// Cleanup
/*!	\brief A static variable deleting the ThreadManager singleton when
		   destroyed.
*/
static class ThreadManager::Cleanup {
public:
	~Cleanup() { ThreadManager::_Cleanup(); }
} _cleanup;

// constructor
/*!	\brief Creates and initializes a ThreadManager.
*/
ThreadManager::ThreadManager()
	: fLock(),
	  fThreads(new ThreadMap())
{
	fTLSHandle = tls_allocate();
}

// destructor
/*!	\brief Frees all resources associated with the object.

	All Thread objects belonging to the manager are deleted.

*/
ThreadManager::~ThreadManager()
{
	Lock();
	// delete all Thread objects
	for (ThreadMap::iterator it = fThreads->begin();
		 it != fThreads->end();
		 ++it) {
		delete it->second;
	}
}

// GetThread
/*!	\brief Returns the Thread object for a given thread ID.
	\param threadID The thread ID.
	\param create If \c true and a Thread object with ID \a threadID does not
		   yet exist, a new one is created.
	\return The Thread object for \a threadID or \c NULL, if the ID is invalid,
			no object exists for the given ID and create is not \c true, or
			an error occurred.
*/
Thread*
ThreadManager::GetThread(thread_id threadID, bool create)
{
	Thread* thread = NULL;
	if (threadID >= 0) {
		Lock();
		// look the ID up in the map
		ThreadMap::iterator it = fThreads->find(threadID);
		if (it != fThreads->end()) {
			// found: everything is fine
			thread = it->second;
		} else if (create) {
			// not found, and we shall create a new Thread structure
			thread = new(nothrow) Thread(threadID);
			if (thread && thread->InitCheck() == B_OK) {
				try {
					(*fThreads)[threadID] = thread;
				} catch (...) {
					delete thread;
					thread = NULL;
				}
			} else if (thread) {
				delete thread;
				thread = NULL;
			}
		}
		Unlock();
	}
	return thread;
}

// GetNextThread
/*!	\brief Iteration method: Returns the next Thread object known to the
		   manager.

	\a cookie must point to a variable initialized to \c 0. Subsequent calls
	to this method return the threads managed by this objects. The manager
	must be locked while iterating through the list.

	\param Pointer to an int32 initialized to \c 0 before the first invocation.
	\return The next thread in the list, or \c NULL, if the end of the list
			has been reached or an error occurred.
*/
Thread*
ThreadManager::GetNextThread(int32* cookie) const
{
	// cookie contains the ID of the next thread to be returned. 0 is the
	// beginning of the iteration.
	Thread* thread = NULL;
	if (cookie) {
		// get an iterator to the next thread
		ThreadMap::iterator it;
		if (*cookie == 0)
			it = fThreads->begin();
		else
			it = fThreads->find(*cookie);
		// get the thread and set the cookie
		if (it != fThreads->end()) {
			thread = it->second;
			if (++it != fThreads->end())
				*cookie = it->second->GetID();
			else
				*cookie = -1;	// next invocation shall fail
		}
	}
	return thread;
}

// RemoveGoneThreads
/*!	\brief Removes and deletes the Thread objects for all threads that don't
		   live anymore.
*/
void
ThreadManager::RemoveGoneThreads()
{
	if (Lock()) {
		// remove all threads for which get_thread_info() fails
		// Note, that this loop is relatively slow -- if we assume O(log(n))
		// for map::find(), than it should be O(n*log(n)). But this way we
		// avoid problems with erasing iterators while iterating.
		int32 cookie = 0;
		while (Thread* thread = GetNextThread(&cookie)) {
			thread_info info;
			if (get_thread_info(thread->GetID(), &info) != B_OK) {
				fThreads->erase(thread->GetID());
				delete thread;
			}
		}
		Unlock();
	}
}

// _Cleanup
/*!	\brief Deletes the singleton instance.
*/
void
ThreadManager::_Cleanup()
{
	if (fDefaultManager)
		delete fDefaultManager;
}

// fDefaultManager
ThreadManager* ThreadManager::fDefaultManager = NULL;

