// LockingInfo.h

#ifndef LOCKING_INFO_H
#define LOCKING_INFO_H

#include <map>

#include <SupportDefs.h>

class ThreadLocker;

struct LockingInfo : public map<const ThreadLocker*,int32> {
	uint32	flags;

	LockingInfo() : flags(0) {}

	/*!	\brief Sets the nesting count for a locker to a given count.

		If set to \c 0, the map entry is removed.

		\param locker The locker.
		\param count The count to be set.
		\return \c true, if everything went fine, \c false, if an error
				occurred (e.g. insufficient memory).
	*/
	inline bool SetNestingCount(const ThreadLocker* locker, int32 count)
	{
		bool result = true;
		try {
			if (count <= 0) {
				iterator it = find(locker);
				if (it != end())
					erase(it);
			} else {
				(*this)[locker] = count;
			}
		} catch (...) {
			result = false;
		}
		return result;
	}

	/*!	\brief Returns the nesting count for a locker.

		In case the locker has no map entry, \c 0 is returned.

		\param locker The locker.
		\return The nesting count.
	*/
	inline int32 GetNestingCount(const ThreadLocker* locker)
	{
		int32 count = 0;
		iterator it = find(locker);
		if (it != end())
			count = it->second;
		return count;
	}

	/*!	\brief Checks whether a locker already has a count and increments it.

		If the locker does not have a map entry, a new one is created and set
		to \c 1. Otherwise the existing one is incremented.

		\param locker The locker.
		\param initSuccess Pointer to a pre-allocated bool set when the locker
			   had no map entry yet. It is set to \c true, if the
			   initialization was successful, to \c false otherwise.
		\return \c true, if the locker already had a map entry, \c false
				otherwise.
	*/
	inline bool CheckAndIncrementNestingCount(const ThreadLocker* locker,
											  bool* initSuccess)
	{
		bool result = true;
		iterator it = find(locker);
		if (it == end()) {
			*initSuccess = SetNestingCount(locker, 1);
			result = false;
		} else
			it->second++;
		return result;
	}

	/*!	\brief Checks whether a locker already has a count and decrements it.

		If the locker does not have a map entry, the method has no effect and
		it returns \c false. Otherwise the nesting count is decremented and
		\c true is returned. In the latter case the \a isZero reference
		variable is set to \c true, if the count has become \c 0, otherwise
		to \c false.

		\param locker The locker.
		\param isZero Pointer to a pre-allocated bool set when the locker
			   had a map entry. It is set to \c true, if the counter is now
			   \c 0, to \c false otherwise.
		\return \c true, if the locker had a map entry, \c false otherwise.
	*/
	inline bool CheckAndDecrementNestingCount(const ThreadLocker* locker,
											  bool* isZero)
	{
		bool result = false;
		iterator it = find(locker);
		if (it != end()) {
			if (--(it->second) == 0) {
				*isZero = true;
				erase(it);
			}
			result = true;
		}
		return result;
	}
};

#endif	// LOCKING_INFO_H
