// ThreadLocker.cpp

#include <map>
#include <new>

#include <stdio.h>
#include <string.h>

#include <Locker.h>

#include "LockingInfo.h"
#include "Thread.h"
#include "ThreadLocker.h"
#include "ThreadManager.h"

//#define DBG(x)	x
#define DBG(x)
#define OUT		printf

// locking flags stored in the Thread objects
enum {
	LOCKING_WRITE				= 0x01,
	LOCKING_WRITER_READ_LOCK	= 0x02,
	LOCKING_SUCCESSFUL			= 0x04,
};

// inline methods

// _MetaLock
/*!	\brief Locks the thread manager.
	\return \c true, if successful, \c false otherwise.
*/
inline
bool
ThreadLocker::_MetaLock()
{
	return fMetaLocker && fMetaLocker->Lock();
}

// _MetaUnlock
/*!	\brief Unlocks the thread manager.
*/
inline
void
ThreadLocker::_MetaUnlock()
{
	if (fMetaLocker)
		fMetaLocker->Unlock();
}

// _GetCurrentThread
/*!	\brief Returns the Thread object of the current thread.
	\param info Pointer to a pre-allocated LockingInfo* which shall be set
		   to the LockingInfo of the thread. May be \c NULL.
	\return \c true, if successful, \c false otherwise.
*/
inline
Thread*
ThreadLocker::_GetCurrentThread(LockingInfo** info = NULL)
{
	Thread* thread = ThreadManager::GetDefault()->GetCurrentThread();
	if (thread && info)
		*info = thread->GetLockingInfo();
	return thread;
}

// regular non-inline methods

// constructor
/*!	\brief Creates and initializes a ThreadLocker.

	The BLocker to be used to protect the object's data can be specified.
	If none is given, the locker uses the BLocker of the default
	ThreadManager.

	\param metaLock BLocker the locker shall use. May be \c NULL.
*/
ThreadLocker::ThreadLocker(BLocker* metaLocker)
	: fMetaLocker(metaLocker),
	  fFirstWaiting(NULL),
	  fLastWaiting(NULL),
	  fReaderCount(0),
	  fWriter(NULL),
	  fWriterNestingCount(0),
	  fWriterReadNestingCount(0)
{
	if (!fMetaLocker)
		fMetaLocker = ThreadManager::GetDefault()->GetLock();
}

// destructor
/*!	\brief Frees all resources associated with the object.

	Care must be taken. Destruction should happen in a single-threaded
	context. If there are threads waiting for a lock, their behavior is
	undefined. So, the procedure for deleting the locker should be to
	1. remove it from the multi-threaded environment, 2. acquire a write lock,
	and 3. delete the object. When the write lock has been granted, there
	should no longer be any other threads around trying to unlock the object.
	That's not entirely true, since read lock owners trying to obtain a write
	lock temporarily drop their read lock, so that a waiting writers can be
	serviced. The user should install a policy that avoids such a problem.

	Note, that the destructor tries to obtain a write lock itself. So, you
	must make sure that noone else holds and doesn't release a lock. Otherwise
	the constructor will block forever.
*/
ThreadLocker::~ThreadLocker()
{
	// acquire a write lock and terminate
	WriteLock();
	// Note: It doesn't make sense to e.g. unblock waiting threads. The
	// locker will be gone in a second and then the threads will access freed
	// memory with a good chance to crash. The caller is responsible for
	// avoiding that.
}

// ReadLock
/*!	\brief Acquires a read lock.

	Nested locking is allowed, also nested read and write locks.

	The lock is granted immediately, if
	- noone else has a lock,
	- the thread already has a read or write lock, or
	- the only locks held by other threads are read locks and no writers are
	  waiting for locks.
	Otherwise the thread will wait until the lock can be granted.

	Usually locking should succeed. Exceptions are e.g. when the locker is not
	properly initialized, in low-memory situations, or when the thread is
	interrupted.

	\return \c true, if the read lock has been acquired successfully, \c false
			otherwise.
*/
bool
ThreadLocker::ReadLock()
{
	return (_ReadLock(0, 0) == B_OK);
}

// ReadLockWithTimeout
/*!	\brief Acquires a read lock with timeout.

	The function works similar to ReadLock() with the exception that a timeout
	can be specified, after which the thread will abort waiting for the lock
	and fail with \c B_TIMED_OUT. A special case is a timeout of \c 0. Then,
	unless the lock can be granted immediately, the thread won't even start
	to wait, but fail with \c B_WOULD_BLOCK.

	\param timeout The maximal period of time (in microseconds) the thread
		   is allowed to wait for the lock.
	\return
	- \c B_OK: The lock has been acquired successfully.
	- \c B_TIMED_OUT: The lock could not be granted before the specified
	  timeout occurred.
	- \c B_WOULD_BLOCK: A timeout of \c 0 has been specified and the lock
	  could not be granted immediately.
*/
status_t
ThreadLocker::ReadLockWithTimeout(bigtime_t timeout)
{
	return _ReadLock(B_RELATIVE_TIMEOUT, (timeout < 0 ? 0 : timeout));
}

// ReadUnlock
/*!	\brief Releases a read lock.

	If the thread doesn't own a read lock the method has no effect (even,
	if the thread is in possesion of a write lock). If it has more than one
	read lock, only one is released -- ReadUnlock() must be called exactly
	as often as ReadLock().
*/
void
ThreadLocker::ReadUnlock()
{
DBG(OUT("ThreadLocker::ReadUnlock()\n"));
DBG(_ShortDump());
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info)) {
		bool isZero = false;
		if (fWriter == thread) {
			// writer releases a read lock
			if (fWriterReadNestingCount > 0)
				fWriterReadNestingCount--;
		} else if (info->CheckAndDecrementNestingCount(this, &isZero)
				   && _MetaLock()) {
			if (isZero && --fReaderCount == 0) {
				// last reader: unblock the next one waiting for a lock
				if (fFirstWaiting)
					_CheckWaiting();
			}
			_MetaUnlock();
		}

	}
DBG(OUT("ThreadLocker::ReadUnlock() done\n"));
DBG(_ShortDump());
}

// IsReadLocked
/*!	\brief Returns whether the calling thread owns a read lock.

	The parameter \a orWriteLock specifies whether only actual read locks
	shall be taken into account or also write locks. The latter is the
	default.

	\param orWriteLock If \c true, the functions returns whether the thread
		   owns a read or a write lock, otherwise it only checks for read
		   locks.
	\return \c true, if the thread owns a read lock, \c false otherwise.
*/
bool
ThreadLocker::IsReadLocked(bool orWriteLock)
{
	bool result = false;
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info)) {
		if (thread == fWriter)
			result = (orWriteLock || (fWriterReadNestingCount > 0));
		else
			result = info->GetNestingCount(this);
	}
	return result;
}

// WriteLock
/*!	\brief Acquires a write lock.

	Nested locking is allowed, also nested read and write locks. Note, that
	in case the thread has a read lock, but not yet a write lock, the read
	lock (more precisely all its read locks) are dropped temporarily until
	the write lock has been granted. This is necessary to avoid dead locks,
	when there are already writers waiting for a lock.

	The lock is granted immediately, if
	- noone else has a lock, or
	- the thread already has a write lock.
	Otherwise the thread will wait until the lock can be granted.

	Usually locking should succeed. Exceptions are e.g. when the locker is not
	properly initialized, in low-memory situations, or when the thread is
	interrupted.

	\return \c true, if the write lock has been acquired successfully,
			\c false otherwise.
*/
bool
ThreadLocker::WriteLock()
{
	return (_WriteLock(0, 0) == B_OK);
}

// WriteLockWithTimeout
/*!	\brief Acquires a read lock with timeout.

	The function works similar to WriteLock() with the exception that a
	timeout can be specified, after which the thread will abort waiting for
	the lock and fail with \c B_TIMED_OUT. A special case is a timeout of \c 0.
	Then, unless the lock can be granted immediately, the thread won't even
	start to wait, but fail with \c B_WOULD_BLOCK. The same happens, if the
	thread already has a read lock, but no write lock -- the timeout is
	ignored in this case. Otherwise the thread might not be able to reclaim
	it's temporarily dropped read lock, when a timeout occurs.

	\param timeout The maximal period of time (in microseconds) the thread
		   is allowed to wait for the lock.
	\return
	- \c B_OK: The lock has been acquired successfully.
	- \c B_TIMED_OUT: The lock could not be granted before the specified
	  timeout occurred.
	- \c B_WOULD_BLOCK: A timeout of \c 0 has been specified or the thread
	  did already own a read lock, and the write lock could not be granted
	  immediately.
*/
status_t
ThreadLocker::WriteLockWithTimeout(bigtime_t timeout)
{
	return _WriteLock(B_RELATIVE_TIMEOUT, (timeout < 0 ? 0 : timeout));
}

// WriteUnlock
/*!	\brief Releases a write lock.

	If the thread doesn't own a write lock the method has no effect (also
	if the thread is in possesion of a read lock). If it has more than one
	write lock, only one is released -- WriteUnlock() must be called exactly
	as often as WriteLock().
*/
void
ThreadLocker::WriteUnlock()
{
DBG(OUT("ThreadLocker::WriteUnlock()\n"));
DBG(_ShortDump());
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info)) {
		if (fWriter == thread) {
			// writer releases a write lock
			if (--fWriterNestingCount == 0) {
				if (_MetaLock()) {
					fWriter = NULL;
					fReaderCount = (fWriterReadNestingCount ? 1 : 0);
					int32 nestingCount = fWriterReadNestingCount;
					fWriterReadNestingCount = 0;
					if (fFirstWaiting)
						_CheckWaiting();
					_MetaUnlock();
					// do that outside the lock to minimize locking time
					info->SetNestingCount(this, nestingCount);
				}
			}
		}
	}
DBG(OUT("ThreadLocker::WriteUnlock() done\n"));
DBG(_ShortDump());
}

// IsWriteLocked
/*!	\brief Returns whether the calling thread owns a write lock.
	\return \c true, if the thread owns a write lock, \c false otherwise.
*/
bool
ThreadLocker::IsWriteLocked()
{
	bool result = false;
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info))
		result = (thread == fWriter);
	return result;
}

// _ReadLock
/*!	\brief Worker method for ReadLock() and ReadLockWithTimeout().
	\param flags Flags to be used for the blocking semaphore.
	\param timeout Timeout in microseconds.
	\return
	- \c B_OK: The lock has been acquired successfully.
	- \c B_TIMED_OUT: The lock could not be granted before the specified
	  timeout occurred.
	- \c B_WOULD_BLOCK: A timeout of \c 0 has been specified and the lock
	  could not be granted immediately.
*/
status_t
ThreadLocker::_ReadLock(uint32 flags, bigtime_t timeout)
{
DBG(OUT("ThreadLocker::_ReadLock(%lx, %Ld)\n", flags, timeout));
DBG(_ShortDump());
	status_t result = B_ERROR;
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info)) {
		bool initSuccess = false;
		if (fWriter == thread) {
			// writer acquires a read lock
			fWriterReadNestingCount++;
			result = B_OK;
		} else if (info->CheckAndIncrementNestingCount(this, &initSuccess)) {
			// thread already has a read lock: increment the nesting count
			result = B_OK;
		} else if (initSuccess && _MetaLock()) {
			// thread has not yet a write or read lock
			bool wait = false;
			if (fFirstWaiting || fWriter) {
				// There's already someone waiting or there is a writer.
				if ((flags & B_RELATIVE_TIMEOUT) && timeout == 0) {
					// special case: zero timeout
					result = B_WOULD_BLOCK;
				} else {
					// Add the thread to the queue of waiting threads.
					thread->SetPrevious(fLastWaiting);
					thread->SetNext(NULL);
					if (fFirstWaiting) {
						fLastWaiting->SetNext(thread);
						fLastWaiting = thread;
					} else
						fFirstWaiting = fLastWaiting = thread;
					wait = true;
					info->flags = 0;
				}
			} else {
				// No writer and noone is waiting. So, we just get the lock.
				if (info->SetNestingCount(this, 1)) {
					fReaderCount++;
					result = B_OK;
				}
			}
			_MetaUnlock();
			if (wait)
				result = _WaitForLock(thread, info, flags, timeout);
		}
		// cleanup on failure
		if (result != B_OK && initSuccess && _MetaLock()) {
			// decrement the nesting count
			bool isZero = false;
			info->CheckAndDecrementNestingCount(this, &isZero);
			_MetaUnlock();
		}
	}
DBG(OUT("ThreadLocker::_ReadLock() done: %s\n", strerror(result)));
DBG(_ShortDump());
	return result;
}

// _WriteLock
/*!	\brief Worker method for WriteLock() and WriteLockWithTimeout().
	\param flags Flags to be used for the blocking semaphore.
	\param timeout Timeout in microseconds.
	\return
	- \c B_OK: The lock has been acquired successfully.
	- \c B_TIMED_OUT: The lock could not be granted before the specified
	  timeout occurred.
	- \c B_WOULD_BLOCK: A timeout of \c 0 has been specified or the thread
	  did already own a read lock, and the write lock could not be granted
	  immediately.
*/
status_t
ThreadLocker::_WriteLock(uint32 flags, bigtime_t timeout)
{
DBG(OUT("ThreadLocker::_WriteLock(%lx, %Ld)\n", flags, timeout));
DBG(_ShortDump());
	status_t result = B_ERROR;
	LockingInfo* info;
	if (Thread* thread = _GetCurrentThread(&info)) {
DBG(OUT("  got thread: %p\n", thread));
		if (fWriter == thread) {
DBG(OUT("  thread already has write lock\n"));
			// writer acquires a write lock
			fWriterNestingCount++;
			result = B_OK;
		} else if (_MetaLock()) {
DBG(OUT("  thread has no write lock\n"));
			bool wait = false;
			int32 readNestingCount = info->GetNestingCount(this);
			int32 isReader = (readNestingCount > 0 ? 1 : 0);
			if (fWriter || (fReaderCount - isReader || fFirstWaiting)) {
DBG(OUT("  there's a writer (%p) or a reader (%ld) or waiting threads (%p)\n",
fWriter, fReaderCount, fFirstWaiting));
				bool withTimeout = (flags & B_RELATIVE_TIMEOUT);
				// There's a writer or at least one reader.
				if (withTimeout && timeout == 0) {
					// special case: zero timeout
					result = B_WOULD_BLOCK;
				} else if (withTimeout && isReader) {
					// special case: read lock owner with timeout
					result = B_WOULD_BLOCK;
				} else {
					// Add the thread to the queue of waiting threads.
					thread->SetPrevious(fLastWaiting);
					thread->SetNext(NULL);
					if (fFirstWaiting) {
						fLastWaiting->SetNext(thread);
						fLastWaiting = thread;
					} else
						fFirstWaiting = fLastWaiting = thread;
					wait = true;
					info->flags = LOCKING_WRITE;
					if (readNestingCount > 0) {
						// We do already own a read lock. Suspend it while we
						// are waiting and check waiting threads.
						fReaderCount--;
						info->flags |= LOCKING_WRITER_READ_LOCK;
						_CheckWaiting();
					}
				}
			} else {
DBG(OUT("  no writer or reader\n"));
				// No writer or reader. So, we just get the lock.
				fWriter = thread;
				fWriterNestingCount = 1;
				fWriterReadNestingCount = readNestingCount;
				// No need to set the reader nesting count, since we will
				// overwrite it, when unlocking.
				result = B_OK;
			}
			_MetaUnlock();
			if (wait)
				result = _WaitForLock(thread, info, flags, timeout);
		}
	}
DBG(OUT("ThreadLocker::_WriteLock() done: %s\n", strerror(result)));
DBG(_ShortDump());
	return result;
}

// _WaitForLock
/*!	\brief Blocks the thread when needing to wait for a lock.
	\param thread The current thread.
	\param info The LockingInfo of the current thread.
	\param flags Flags to be used for the blocking semaphore.
	\param timeout Timeout in microseconds.
	- \c B_OK: The thread was unblocked and has got the lock.
	- \c B_TIMED_OUT: The lock could not be granted before the specified
	  timeout occurred.
	- \c B_ERROR: An unexpected error occurred.
*/
status_t
ThreadLocker::_WaitForLock(Thread* thread, LockingInfo* info, uint32 flags,
						   bigtime_t timeout)
{
	status_t result = B_ERROR;
	if (thread->Block(flags, timeout)) {
		// We were unblocked. Check whether locking was successful.
		if (info->flags & LOCKING_SUCCESSFUL)
			result = B_OK;
	} else {
		// time out
		if (_MetaLock()) {
			if (info->flags & LOCKING_SUCCESSFUL) {
				// It seems we were unblocked immediately after timing out.
				// Check whether locking was successful.
				result = B_OK;
			} else {
				// We really haven't got the lock, so remove us from the
				// locking queue.
				result = B_TIMED_OUT;
				Thread* previous = thread->GetPrevious();
				Thread* next = thread->GetNext();
				// unlink the previous thread
				if (thread == fFirstWaiting)
					fFirstWaiting = next;
				else
					previous->SetNext(next);
				// unlink the next thread
				if (thread == fLastWaiting)
					fLastWaiting = previous;
				else
					next->SetPrevious(previous);
				// clear the thread's next and previous pointer
				thread->SetPrevious(NULL);
				thread->SetNext(NULL);
				// Readers requesting a write lock should never come to this,
				// point since the locking requests fails immediately, if a
				// time out is specified and the thread had to wait. But just
				// in case blocking fails for another reason
				// (e.g. B_INTERRUPTED) we clean up the writer's read locks.
				if (info->flags & LOCKING_WRITER_READ_LOCK)
					info->SetNestingCount(this, 0);
				// To be on the safe side, check queue (e.g. writer times out,
				// with readers waiting after it).
				_CheckWaiting();
			}
			_MetaUnlock();
		}	// else: Things went utterly wrong.
	}
	return result;
}

// _CheckWaiting
/*!	\brief Checks the queue of waiting threads, if one or more of then can
		   be granted a lock.

	The meta lock must be held when invoking this method.
*/
void
ThreadLocker::_CheckWaiting()
{
	while (fFirstWaiting && !fWriter) {
		if (fFirstWaiting->GetLockingInfo()->flags & LOCKING_WRITE) {
			// a writer
			if (fReaderCount > 0) {
				// there are already readers: bail out
				break;
			} else {
				// no readers yet
				fWriter = fFirstWaiting;
				fWriterNestingCount = 1;
				LockingInfo* info = fWriter->GetLockingInfo();
				fWriterReadNestingCount = info->GetNestingCount(this);
				_UnblockFirstWaiting(true);
			}
		} else {
			// a reader
			bool success = fFirstWaiting->GetLockingInfo()
				->SetNestingCount(this, 1);
			if (success)
				fReaderCount++;
			_UnblockFirstWaiting(success);
		}
	}
}

// _UnblockFirstWaiting
/*!	\brief Unblocks the first thread in the queue of waiting threads.

	The meta lock must be held when invoking this method.
*/
void
ThreadLocker::_UnblockFirstWaiting(bool lockingSuccessful)
{
	Thread* thread = fFirstWaiting;
	fFirstWaiting = fFirstWaiting->GetNext();
	if (fFirstWaiting)
		fFirstWaiting->SetPrevious(NULL);
	else
		fLastWaiting = NULL;
	thread->SetPrevious(NULL);
	thread->SetNext(NULL);
	if (lockingSuccessful)
		thread->GetLockingInfo()->flags |= LOCKING_SUCCESSFUL;
	thread->Unblock();
}

// _ShortDump
/*!	\brief Prints out a short info about the locker.

	For debugging only.
*/
void
ThreadLocker::_ShortDump() const
{
	DBG(OUT("readers: %ld (%ld), writer: (%p, %ld, %ld), waiting: %p-%p\n",
			fReaderCount,
			_GetCurrentThread()->GetLockingInfo()->GetNestingCount(this),
			fWriter, fWriterNestingCount, fWriterReadNestingCount,
			fFirstWaiting, fLastWaiting));
}

