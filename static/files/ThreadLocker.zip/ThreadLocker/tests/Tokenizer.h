// Tokenizer.h

#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <stdio.h>

#include <SupportDefs.h>

// longest token (including terminating null)
static const int32 kMaxTokenLen = 256;
static const int32 kMaxLineLen = 256;

// tokens
enum {
	TOKEN_ERROR			= -1,
	TOKEN_EOF			= '\0',
	TOKEN_TAB			= '\t',
	TOKEN_NL			= '\n',
	TOKEN_NUMBER		= '0',
	TOKEN_THREAD		= 'THRD',
	TOKEN_RL			= 'RL',
	TOKEN_RU			= 'RU',
	TOKEN_WL			= 'WL',
	TOKEN_WU			= 'WU',
	TOKEN_SNOOZE		= '-',
	TOKEN_BLOCKED		= '.',
	TOKEN_UNBLOCKED		= '*',
	TOKEN_TIMEOUT		= 't',
	TOKEN_WOULD_BLOCK	= 'b',
};

// Tokenizer
class Tokenizer {
public:
								Tokenizer(FILE* file);

			void				SetTo(FILE* file);

			int32				GetNextToken(char *buffer = NULL);
			void				PutLastToken();

			const char*			GetCurrentLine();
			void				SkipLine();

			int32				GetLineNumber() const { return fLineNumber; }

			bool				ExpectToken(int32 kind, char* buffer = NULL);

			bool				ReadNL() { return (ExpectToken(TOKEN_NL)); }
			bool				ReadTab() { return (ExpectToken(TOKEN_TAB)); }
			bool				ReadWouldBlock()
									{ return (ExpectToken(TOKEN_WOULD_BLOCK)); }
			bool				ReadThread()
									{ return (ExpectToken(TOKEN_THREAD)); }
			bool				ReadEOF() { return (ExpectToken(TOKEN_EOF)); }
			bool				ReadNumber(int64 &number);

private:
			void				_SkipWhiteSpace();
			void				_SkipSpaces();
			bool				_ReadLine();

private:
			FILE*				fFile;
			char				fCurrentLine[kMaxLineLen];
			bool				fEOL;
			bool				fEOF;
			int32				fPosition;
			int32				fLastPosition;
			int32				fLastToken;
			int32				fLineNumber;
};

#endif	// TOKENIZER_H
