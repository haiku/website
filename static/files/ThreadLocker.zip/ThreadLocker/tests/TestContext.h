// TestContext.h

#ifndef TEST_CONTEXT_H
#define TEST_CONTEXT_H

#include <SupportDefs.h>

#include "ThreadLocker.h"

class TestCase;
class TestThread;

class TestContext {
public:
								TestContext(TestCase* testCase,
											TestThread* threads,
											bigtime_t tickLength);
								~TestContext();

			TestCase*			GetTestCase() const { return fTestCase; }

			TestThread*			GetThreads() const { return fThreads; }

			ThreadLocker*		GetLocker() { return &fLocker; }

			void				SetStartTime(bigtime_t startTime)
									{ fStartTime = startTime; }
			bigtime_t			GetStartTime() const { return fStartTime; }

			bigtime_t			GetTickLength() const { return fTickLength; }

			void				WaitForTick(double tick) const;
			int32				GetCurrentTick() const;

private:
			TestCase*			fTestCase;
			TestThread*			fThreads;
			ThreadLocker		fLocker;
			bigtime_t			fStartTime;
			bigtime_t			fTickLength;
};

#endif	// TEST_CONTEXT_H
