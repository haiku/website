// TestThreadActions.cpp

#include <stdio.h>

#include "TestThreadActions.h"

// TestThreadActionVisitor

// constructor
TestThreadActionVisitor::TestThreadActionVisitor()
{
}

// destructor
TestThreadActionVisitor::~TestThreadActionVisitor()
{
}

// Visit
void
TestThreadActionVisitor::Visit(LockAction* action)
{
}

// Visit
void
TestThreadActionVisitor::Visit(UnlockAction* action)
{
}

// Visit
void
TestThreadActionVisitor::Visit(SnoozeAction* action)
{
}

// Visit
void
TestThreadActionVisitor::Visit(BlockAction* action)
{
}

// Visit
void
TestThreadActionVisitor::Visit(UnblockAction* action)
{
}

// Visit
void
TestThreadActionVisitor::Visit(TimeoutAction* action)
{
}


// all actions, Accept()

// Accept
void
LockAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}

// Accept
void
UnlockAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}

// Accept
void
SnoozeAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}

// Accept
void
BlockAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}

// Accept
void
UnblockAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}

// Accept
void
TimeoutAction::Accept(TestThreadActionVisitor* visitor)
{
	visitor->Visit(this);
}


// ActionErrorInitializer

class ActionErrorInitializer : public TestThreadActionVisitor {
public:
								ActionErrorInitializer();
	virtual						~ActionErrorInitializer();

private:
	virtual	void				Visit(LockAction* action);
	virtual	void				Visit(UnlockAction* action);
	virtual	void				Visit(SnoozeAction* action);
	virtual	void				Visit(BlockAction* action);
	virtual	void				Visit(UnblockAction* action);
	virtual	void				Visit(TimeoutAction* action);

private:
			LockAction*			fPendingLockAction;
};

// constructor
ActionErrorInitializer::ActionErrorInitializer()
	: TestThreadActionVisitor(),
	  fPendingLockAction(NULL)
{
}

// destructor
ActionErrorInitializer::~ActionErrorInitializer()
{
}

// Visit
void
ActionErrorInitializer::Visit(LockAction* action)
{
	fPendingLockAction = NULL;	// must have succeeded earlier
	if (action->WouldBlock())
		action->SetError(B_WOULD_BLOCK);
	else
		fPendingLockAction = action;
}

// Visit
void
ActionErrorInitializer::Visit(UnlockAction* action)
{
	fPendingLockAction = NULL;	// must have succeeded earlier
}

// Visit
void
ActionErrorInitializer::Visit(SnoozeAction* action)
{
	fPendingLockAction = NULL;	// must have succeeded earlier
}

// Visit
void
ActionErrorInitializer::Visit(BlockAction* action)
{
	// nothing to do
}

// Visit
void
ActionErrorInitializer::Visit(UnblockAction* action)
{
	// action succeeded
	fPendingLockAction = NULL;
}

// Visit
void
ActionErrorInitializer::Visit(TimeoutAction* action)
{
	if (fPendingLockAction) {
		// action timed out
		fPendingLockAction->SetError(B_TIMED_OUT);
		fPendingLockAction = NULL;
	}
}


// TestThreadActions

// constructor
TestThreadActions::TestThreadActions()
	: fActions()
{
}

// destructor
TestThreadActions::~TestThreadActions()
{
	int32 count = CountTicks();
	for (int32 i = 0; i < count; i++) {
		if (TestThreadAction* action = ActionAt(i))
			delete action;
	}
}

// SetActionAt
void
TestThreadActions::SetActionAt(int32 tick, TestThreadAction* action)
{
	if (tick >= 0) {
		// remove and delete old action
		if (TestThreadAction* oldAction
			= (TestThreadAction*)fActions.RemoveItem(tick)) {
			delete oldAction;
		}
		// pad list with NULLs, if necessary
		int32 count = CountTicks();
		for (int32 i = count; i < tick; i++)
			fActions.AddItem(NULL, i);
		// insert new action
		fActions.AddItem(action, tick);
	}
}

// ActionAt
TestThreadAction*
TestThreadActions::ActionAt(int32 tick) const
{
	return (TestThreadAction*)fActions.ItemAt(tick);
}

// CountTicks
int32
TestThreadActions::CountTicks() const
{
	return fActions.CountItems();
}

// InitActionErrors
void
TestThreadActions::InitActionErrors()
{
	ActionErrorInitializer initializer;
	int32 ticks = CountTicks();
	for (int32 i = 0; i < ticks; i++)
		ActionAt(i)->Accept(&initializer);
}

