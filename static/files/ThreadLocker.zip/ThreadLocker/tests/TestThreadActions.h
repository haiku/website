// TestThreadActions.h

#ifndef TEST_THREAD_ACTIONS_H
#define TEST_THREAD_ACTIONS_H

#include <List.h>

class LockAction;
class UnlockAction;
class SnoozeAction;
class BlockAction;
class UnblockAction;
class TimeoutAction;

// TestThreadActionVisitor
class TestThreadActionVisitor {
public:
								TestThreadActionVisitor();
	virtual						~TestThreadActionVisitor();

	virtual	void				Visit(LockAction* action);
	virtual	void				Visit(UnlockAction* action);
	virtual	void				Visit(SnoozeAction* action);
	virtual	void				Visit(BlockAction* action);
	virtual	void				Visit(UnblockAction* action);
	virtual	void				Visit(TimeoutAction* action);
};

// TestThreadAction
class TestThreadAction {
public:
								TestThreadAction() : fError(B_OK) {}
	virtual						~TestThreadAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor) = 0;

			void				SetError(status_t error) { fError = error; }
			status_t			GetError() const { return fError; }

private:
			status_t			fError;
};

// LockAction
class LockAction : public TestThreadAction {
public:
								LockAction(bool write)
									: fTimeout(0),
									  fWrite(write),
									  fUseTimeout(false),
									  fWouldBlock(false) {}

								LockAction(bool write, int32 timeout,
										   bool wouldBlock = false)
									: fTimeout(timeout),
									  fWrite(write),
									  fUseTimeout(true),
									  fWouldBlock(wouldBlock) {}

	virtual						~LockAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);

			bool				IsReader() const { return !fWrite; }
			bool				IsWriter() const { return fWrite; }

			void				SetTimeout(int32 timeout)
									{ fTimeout = timeout; fUseTimeout = true; }
			bool				UseTimeout() const { return fUseTimeout; }
			int32				GetTimeout() const { return fTimeout; }

			void				SetWouldBlock(bool wouldBlock)
									{ fWouldBlock = wouldBlock; }
			bool				WouldBlock() const { return fWouldBlock; }

private:
			int32				fTimeout;
			bool				fWrite;
			bool				fUseTimeout;
			bool				fWouldBlock;
};

// UnlockAction
class UnlockAction : public TestThreadAction {
public:
								UnlockAction(bool write) : fWrite(write) {}
	virtual						~UnlockAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);

			bool				IsReader() const { return !fWrite; }
			bool				IsWriter() const { return fWrite; }

private:
			bool				fWrite;
};

// SnoozeAction
class SnoozeAction : public TestThreadAction {
public:
								SnoozeAction() {}
	virtual						~SnoozeAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);
};

// BlockAction
class BlockAction : public TestThreadAction {
public:
								BlockAction() {}
	virtual						~BlockAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);
};

// UnblockAction
class UnblockAction : public TestThreadAction {
public:
								UnblockAction() {}
	virtual						~UnblockAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);
};

// TimeoutAction
class TimeoutAction : public TestThreadAction {
public:
								TimeoutAction() {}
	virtual						~TimeoutAction() {}

	virtual	void				Accept(TestThreadActionVisitor* visitor);
};


// TestThreadActions
class TestThreadActions {
public:
								TestThreadActions();
								~TestThreadActions();

			void				SetActionAt(int32 tick,
											TestThreadAction* action);
			TestThreadAction*	ActionAt(int32 tick) const;

			int32				CountTicks() const;

			void				InitActionErrors();

private:
			BList				fActions;
};

#endif	// TEST_THREAD_ACTIONS_H
