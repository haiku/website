// TestThread.cpp

#include <stdio.h>

#include "TestContext.h"
#include "TestSuite.h"
#include "TestThread.h"
#include "TestThreadActions.h"

// constructor
TestThread::TestThread()
	: fContext(NULL),
	  fActions(NULL),
	  fIndex(-1),
	  fThread(-1),
	  fCurrentTick(-1),
	  fActualTick(-1),
	  fNestingReadLocks(0),
	  fNestingWriteLocks(0),
	  fError(false)
{
	fThread = spawn_thread(_ThreadEntry, "thread", B_NORMAL_PRIORITY, this);
}

// destructor
TestThread::~TestThread()
{
}

// Init
status_t
TestThread::Init(TestContext* context, int32 index)
{
	fContext = context;
	fIndex = index;
	status_t error = (fContext && fIndex >= 0 ? B_OK : B_BAD_VALUE);
	if (error == B_OK) {
		fActions = fContext->GetTestCase()->GetThreadActions(index);
		if (!fActions)
			error = B_BAD_VALUE;
	}
	return (error == B_OK && fThread < 0 ? fThread : error);
}

// Start
void
TestThread::Start()
{
	resume_thread(fThread);
}

// Kill
void
TestThread::Kill()
{
	if (fThread >= 0)
		kill_thread(fThread);
}

// Visit
void
TestThread::Visit(LockAction* action)
{
	BString _functionName(action->IsReader() ? "Read" : "Write");
	_functionName += "Lock";
	if (action->UseTimeout())
		_functionName << "WithTimeout" << "(" << action->GetTimeout() << ")";
	else
		_functionName += "()";
	const char* functionName = _functionName.String();
	if (!_CheckBlocked(false, functionName))
		return;
	status_t error = B_OK;
	ThreadLocker* locker = fContext->GetLocker();
	bigtime_t timeout = action->GetTimeout() * fContext->GetTickLength();
	if (action->IsReader()) {
		// reader
		if (action->UseTimeout())
			error = locker->ReadLockWithTimeout(timeout);
		else
			error = (locker->ReadLock() ? B_OK : B_ERROR);
	} else {
		// writer
		if (action->UseTimeout())
			error = locker->WriteLockWithTimeout(timeout);
		else
			error = (locker->WriteLock() ? B_OK : B_ERROR);
	}
	// increment nesting counter
	if (error == B_OK) {
		if (action->IsReader())
			fNestingReadLocks++;
		else
			fNestingWriteLocks++;
	}
	// check error
	if (error != action->GetError()) {
		printf("[%2ld(%2ld):%ld] %s: error is %lx, but should be %lx\n",
			   fContext->GetCurrentTick(), fCurrentTick, fIndex, functionName,
			   error, action->GetError());
		fError = true;
	}
}

// Visit
void
TestThread::Visit(UnlockAction* action)
{
	BString _functionName(action->IsReader() ? "Read" : "Write");
	_functionName += "Unlock";
	const char* functionName = _functionName.String();
	if (!_CheckBlocked(false, functionName))
		return;
	ThreadLocker* locker = fContext->GetLocker();
	if (action->IsReader()) {
		// reader
		locker->ReadUnlock();
		if (fNestingReadLocks)
			fNestingReadLocks--;
	} else {
		// writer
		locker->WriteUnlock();
		if (fNestingWriteLocks)
			fNestingWriteLocks--;
	}
}

// Visit
void
TestThread::Visit(SnoozeAction* action)
{
	// not blocked => we must not lag behind
	_CheckBlocked(false, "snooze()");
}

// Visit
void
TestThread::Visit(BlockAction* action)
{
	// blocked => we must lag behind (at least one tick)
	_CheckBlocked(true, "block()");
}

// Visit
void
TestThread::Visit(UnblockAction* action)
{
	// not blocked => we must not lag behind
	_CheckBlocked(false, "block()");
}

// Visit
void
TestThread::Visit(TimeoutAction* action)
{
	// not blocked => we must not lag behind
	_CheckBlocked(false, "block()");
}

// _ThreadEntry
int32
TestThread::_ThreadEntry(void* data)
{
	return ((TestThread*)data)->_Thread();
}

// _Thread
int32
TestThread::_Thread()
{
	_CheckLockNesting();
	int32 ticks = fContext->GetTestCase()->CountTicks();
	for (int32 i = 0; !fError && i < ticks; i++) {
		fContext->WaitForTick(i);
		fCurrentTick = i;
		fActualTick = fContext->GetCurrentTick();
		if (TestThreadAction* action = fActions->ActionAt(i))
			action->Accept(this);
		if (!fError)
			_CheckLockNesting();
	}
	// terminate
	fThread = -1;
	return 0;
}

// _CheckBlocked
bool
TestThread::_CheckBlocked(bool blocked, const char* name)
{
	bool result = (blocked == (fCurrentTick != fActualTick));
	if (!result) {
		printf("[%2ld(%2ld):%ld] %s: thread %sblocked\n", fActualTick,
			   fCurrentTick, fIndex, name, (blocked ? "not " : ""));
		fError = true;
	}
	return result;
}

// _CheckLockNesting
void
TestThread::_CheckLockNesting()
{
	ThreadLocker* locker = fContext->GetLocker();
	bool writeLocked = (fNestingWriteLocks > 0);
	bool readLocked = (fNestingReadLocks > 0);
	// check read lock
	if (readLocked != locker->IsReadLocked(false)) {
		printf("[%2ld(%2ld):%ld]: thread %sread locked\n", fActualTick,
			   fCurrentTick, fIndex, (readLocked ? "not " : ""));
		fError = true;
	}
	// check read or write lock
	if ((readLocked || writeLocked) != locker->IsReadLocked(true)) {
		printf("[%2ld(%2ld):%ld]: thread %sread or write locked\n",
			   fActualTick, fCurrentTick, fIndex,
			   (readLocked || writeLocked ? "not " : ""));
		fError = true;
	}
	// check write lock
	if (writeLocked != locker->IsWriteLocked()) {
		printf("[%2ld(%2ld):%ld]: thread %swrite locked\n", fActualTick,
			   fCurrentTick, fIndex, (writeLocked ? "not " : ""));
		fError = true;
	}
}

