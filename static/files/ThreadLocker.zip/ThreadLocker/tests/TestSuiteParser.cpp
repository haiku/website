// TestSuiteParser.cpp

#include <String.h>

#include "TestSuite.h"
#include "TestSuiteParser.h"
#include "TestThreadActions.h"
#include "Tokenizer.h"

// constructor
TestSuiteParser::TestSuiteParser(FILE* file)
	: fTokenizer(file),
	  fParseError(B_OK),
	  fTestSuite(NULL),
	  fCurrentTestCase(NULL),
	  fCurrentTick(0),
	  fCurrentThread(0)
{
}

// Parse
bool
TestSuiteParser::Parse(TestSuite* testSuite)
{
	bool result = false;
	if (testSuite) {
		fTestSuite = testSuite;
		while (fTokenizer.ReadNL()) {}
		while (_NoError() && !fTokenizer.ReadEOF() && _ParseTestCase()) {
			while (fTokenizer.ReadNL()) {}
		}
		if (!fTokenizer.ReadEOF())
			_ErrorOccurred(B_ERROR, "End of file expected.");
		result = _NoError();
		if (result)
			fTestSuite->InitActionErrors();
		fTestSuite = NULL;
	}
	return result;
}

// _ParseTestCase
bool
TestSuiteParser::_ParseTestCase()
{
	// headings
	int64 dummy;
	BString name("unnamed test case");
	while (_NoError() && fTokenizer.ReadNumber(dummy)) {
		name.SetTo(fTokenizer.GetCurrentLine());
		fTokenizer.SkipLine();
	}
	// table head
	if (_NoError() && fTokenizer.ReadThread())
		fTokenizer.SkipLine();
	fCurrentTestCase = new TestCase;
	fTestSuite->AddElement(fCurrentTestCase);
	fCurrentTestCase->SetName(name.String());
	fCurrentTick = 0;
	// event lines
	while (_NoError() && !fTokenizer.ReadNL() && !fTokenizer.ReadEOF()) {
		if (_ParseEventLine())
			fCurrentTick++;
		else
			_ErrorOccurred(B_ERROR, "Event line expected.");
	}
	return _NoError();
}

// _ParseEventLine
bool
TestSuiteParser::_ParseEventLine()
{
	fCurrentThread = 0;
	while (_NoError() && _ParseThreadEvent()) {
		int32 token = fTokenizer.GetNextToken();
		if (token == TOKEN_TAB) {
			while (fTokenizer.ReadTab()) {}
			fCurrentThread++;
		} else if (token == TOKEN_NL) {
			break;
		} else
			_ErrorOccurred(B_ERROR, "Event line: TAB or NL expected.");
	}
	return _NoError();
}

// _ParseThreadEvent
bool
TestSuiteParser::_ParseThreadEvent()
{
	TestThreadAction* action = NULL;
	int32 token = fTokenizer.GetNextToken();
	switch (token) {
		case TOKEN_ERROR:
		case TOKEN_EOF:
		case TOKEN_TAB:
		case TOKEN_NL:
		case TOKEN_NUMBER:
		case TOKEN_THREAD:
		case TOKEN_WOULD_BLOCK:
			_ErrorOccurred(B_ERROR, "Thread event: Unexpected token.");
			break;
		case TOKEN_RL:
		case TOKEN_WL:
		{
			LockAction* lockAction = new LockAction(token == TOKEN_WL);
			action = lockAction;
			int64 timeout;
			if (fTokenizer.ReadNumber(timeout)) {
				lockAction->SetTimeout(timeout);
				if (fTokenizer.ReadWouldBlock())
					lockAction->SetWouldBlock(true);
			}
			break;
		}
		case TOKEN_RU:
		case TOKEN_WU:
			action = new UnlockAction(token == TOKEN_WU);
			break;
		case TOKEN_SNOOZE:
			action = new SnoozeAction();
			break;
		case TOKEN_BLOCKED:
			action = new BlockAction();
			break;
		case TOKEN_UNBLOCKED:
			action = new UnblockAction();
			break;
		case TOKEN_TIMEOUT:
			action = new TimeoutAction();
			break;
	}
	if (action) {
		fCurrentTestCase->SetThreadActionAt(fCurrentThread, fCurrentTick,
											action);
	}
	return _NoError();
}

// _ErrorOccurred
void
TestSuiteParser::_ErrorOccurred(status_t error, const char* description)
{
	if (fParseError == B_OK) {
		fParseError = error;
		if (description)
			printf("Line %ld: %s\n", fTokenizer.GetLineNumber(), description);
	}
}

