// TestSuite.cpp

#include <algobase.h>
#include <stdio.h>

#include "TestSuite.h"
#include "TestThreadActions.h"

// TestCase

// constructor
TestCase::TestCase()
	: TestElement(false),
	  fActions()
{
}

// destructor
TestCase::~TestCase()
{
	int32 count = CountThreads();
	for (int32 i = 0; i < count; i++)
		delete GetThreadActions(i);
}

// SetThreadActionAt
void
TestCase::SetThreadActionAt(int32 thread, int32 tick, TestThreadAction* action)
{
	if (thread >= 0 && tick >= 0) {
		// pad list with new threads, if necessary
		int32 count = CountThreads();
		for (int32 i = count; i <= thread; i++)
			fActions.AddItem(new TestThreadActions, i);
		// set action
		GetThreadActions(thread)->SetActionAt(tick, action);
	}
}

// GetThreadActions
TestThreadActions*
TestCase::GetThreadActions(int32 thread) const
{
	return (TestThreadActions*)fActions.ItemAt(thread);
}

// CountThreads
int32
TestCase::CountThreads() const
{
	return fActions.CountItems();
}

// CountTicks
int32
TestCase::CountTicks() const
{
	int32 count = 0;
	int32 threadCount = CountThreads();
	for (int32 i = 0; i < threadCount; i++)
		count = max(count, GetThreadActions(i)->CountTicks());
	return count;
}

// InitActionErrors
void
TestCase::InitActionErrors()
{
	int32 threadCount = CountThreads();
	for (int32 i = 0; i < threadCount; i++)
		GetThreadActions(i)->InitActionErrors();
}


// TestSuite

// constructor
TestSuite::TestSuite()
	: TestElement(true),
	  fElements()
{
}

// destructor
TestSuite::~TestSuite()
{
	for (int32 i = 0; TestElement* element = ElementAt(i); i++)
		delete element;
}

// AddElement
void
TestSuite::AddElement(TestElement* element, int32 index)
{
	if (element) {
		if (index < 0 || index >= CountElements())
			fElements.AddItem(element);
		else
			fElements.AddItem(element, index);
		element->SetParent(this);
	}
}

// ElementAt
TestElement*
TestSuite::ElementAt(int32 index) const
{
	return (TestElement*)fElements.ItemAt(index);
}

// CountElements
int32
TestSuite::CountElements() const
{
	return fElements.CountItems();
}

// InitActionErrors
void
TestSuite::InitActionErrors()
{
	for (int32 i = 0; TestElement* element = ElementAt(i); i++)
		element->InitActionErrors();
}

// Dump
void
TestSuite::Dump() const
{
	printf("TestSuite: `%s'\n", GetName());
	for (int32 i = 0; TestElement* element = ElementAt(i); i++) {
		if (element->IsSuite()) {
			dynamic_cast<TestSuite*>(element)->Dump();
		} else {
			TestCase* testCase = dynamic_cast<TestCase*>(element);
			printf("  %s: %ld thread, %ld ticks\n", testCase->GetName(),
				   testCase->CountThreads(), testCase->CountTicks());
		}
	}
}

