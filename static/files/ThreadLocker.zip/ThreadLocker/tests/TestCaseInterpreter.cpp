// TestCaseInterpreter.cpp

#include <stdio.h>

#include "TestCaseInterpreter.h"
#include "TestContext.h"
#include "TestSuite.h"
#include "TestThread.h"
#include "ThreadManager.h"

// length of a tick in microseconds
// A suitable value depends on the machine configuration and on the other
// processes running in the system. With a short tick length even a short
// peak in CPU load might affect a test such that it fails due to that.
// I tested with 3ms and the test suite ran most of the times without errors.
// But running the suite 50 times in sequence I even got a few failing tests
// with 20ms. With 100ms the sequence ran without a single failure.
//static const bigtime_t kTickLength = 3000LL;
static const bigtime_t kTickLength = 100000LL;

// constructor
TestCaseInterpreter::TestCaseInterpreter()
	: fTickLength(kTickLength),
	  fTestCount(0),
	  fFailedTests(0)
{
}

// destructor
TestCaseInterpreter::~TestCaseInterpreter()
{
}

// Interpret
void
TestCaseInterpreter::Interpret(TestSuite* suite)
{
	if (suite) {
		fTestCount = 0;
		fFailedTests = 0;
		_Interpret(suite);
		printf("\nsummary: ");
		if (fFailedTests == 0)
			printf("all %ld tests OK\n", fTestCount);
		else {
			printf("%ld out of %ld tests failed\n", fFailedTests,
				   fTestCount);
		}
	}
}

// Interpret
void
TestCaseInterpreter::Interpret(TestCase* testCase)
{
	if (testCase) {
		int32 ticks = testCase->CountTicks();
		int32 threadCount = testCase->CountThreads();
		if (threadCount > 0 && ticks > 0) {
			printf("%s\n", testCase->GetName());
			bool testFailed = false;
			// create threads
			TestThread* threads = new TestThread[threadCount];
			TestContext context(testCase, threads, fTickLength);
			// init check
			status_t error = B_OK;
			for (int32 i = 0; error == B_OK && i < threadCount; i++)
				error = threads[i].Init(&context, i);
			// start the threads
			if (error == B_OK) {
				bigtime_t startTime = system_time() + fTickLength;
				context.SetStartTime(startTime);
				for (int32 i = 0; i < threadCount; i++)
					threads[i].Start();
				// run the test
				for (int32 i = 0; !testFailed && i < ticks; i++) {
					context.WaitForTick(i + 0.5);
					for (int32 t = 0; t < threadCount; t++)
						testFailed |= threads[t].GetError();
					// propagate error
					if (testFailed) {
						for (int32 t = 0; t < threadCount; t++)
							threads[t].SetError(true);
					}
				}
				// terminate threads
				context.WaitForTick(ticks + 1);
				for (int32 i = 0; i < threadCount; i++)
					threads[i].Kill();
			}
			// cleanup
			delete[] threads;
			fTestCount++;
			if (testFailed) {
				fFailedTests++;
				printf("  TEST FAILED!\n");
			}
			ThreadManager::GetDefault()->RemoveGoneThreads();
		}
	}
}

// _Interpret
void
TestCaseInterpreter::_Interpret(TestSuite* suite)
{
	if (suite) {
		for (int32 i = 0; TestElement* element = suite->ElementAt(i); i++) {
			if (TestSuite* subSuite = dynamic_cast<TestSuite*>(element))
				_Interpret(subSuite);
			else if (TestCase* testCase = dynamic_cast<TestCase*>(element))
				Interpret(testCase);
		}
	}
}

