// TestThread.h

#ifndef TEST_THREAD_H
#define TEST_THREAD_H

#include <OS.h>

#include "TestThreadActions.h"

class TestContext;
class TestThreadActions;

class TestThread : private TestThreadActionVisitor {
public:
								TestThread();
								~TestThread();

			status_t			Init(TestContext* context, int32 index);
			void				Start();
			void				Kill();

			void				SetError(bool error) { fError = error; }
			bool				GetError() const { return fError; }

private:
	virtual	void				Visit(LockAction* action);
	virtual	void				Visit(UnlockAction* action);
	virtual	void				Visit(SnoozeAction* action);
	virtual	void				Visit(BlockAction* action);
	virtual	void				Visit(UnblockAction* action);
	virtual	void				Visit(TimeoutAction* action);

	static	int32				_ThreadEntry(void* data);
			int32				_Thread();

			bool				_CheckBlocked(bool blocked, const char* name);
			void				_CheckLockNesting();

private:
			TestContext*		fContext;
			TestThreadActions*	fActions;
			int32				fIndex;
			thread_id			fThread;
	volatile int32				fCurrentTick;
	volatile int32				fActualTick;
	volatile int32				fNestingReadLocks;
	volatile int32				fNestingWriteLocks;
	volatile bool				fError;
};

#endif	// TEST_THREAD_H

