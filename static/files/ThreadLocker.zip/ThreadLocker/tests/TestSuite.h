// TestSuite.h

#ifndef TEST_SUITE_H
#define TEST_SUITE_H

#include <List.h>
#include <String.h>

class TestThreadAction;
class TestThreadActions;

// TestElement
class TestElement {
public:
								TestElement(bool suite) : fIsSuite(suite) {}
	virtual						~TestElement() {}

			bool				IsSuite() const { return fIsSuite; }

			void				SetName(const char* name)
									{ fName.SetTo(name); }
			const char*			GetName() const { return fName.String(); }

			void				SetParent(TestElement* parent)
									{ fParent = parent; }
			TestElement*		GetParent() const { return fParent; }

	virtual	void				InitActionErrors() {}

private:
			bool				fIsSuite;
			BString				fName;
			TestElement*		fParent;
};


// TestCase
class TestCase : public TestElement {
public:
								TestCase();
								~TestCase();

			void				SetThreadActionAt(int32 thread, int32 tick,
												  TestThreadAction* action);
			TestThreadActions*	GetThreadActions(int32 thread) const;

			int32				CountThreads() const;
			int32				CountTicks() const;

	virtual	void				InitActionErrors();

private:
			BList				fActions;
};

// TestSuite
class TestSuite : public TestElement {
public:
								TestSuite();
								~TestSuite();

			void				AddElement(TestElement* element,
										   int32 index = -1);
			TestElement*		ElementAt(int32 index) const;
			int32				CountElements() const;

	virtual	void				InitActionErrors();

			void				Dump() const;

private:
			BList				fElements;
};


#endif	// TEST_SUITE_H
