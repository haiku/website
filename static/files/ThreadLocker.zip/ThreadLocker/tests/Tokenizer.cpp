// Tokenizer.cpp

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Tokenizer.h"

// constructor
Tokenizer::Tokenizer(FILE* file)
	: fFile(file),
	  fEOL(true),
	  fEOF(false),
	  fPosition(0),
	  fLastPosition(0),
	  fLastToken(TOKEN_ERROR),
	  fLineNumber(0)
{
	fCurrentLine[0] = '\0';
}

// SetTo
void
Tokenizer::SetTo(FILE* file)
{
	fFile = file;
	fCurrentLine[0] = '\0';
	fEOL = true;
	fEOF = false;
	fPosition = 0;
	fLastPosition = 0;
	fLastToken = TOKEN_ERROR;
	fLineNumber = 0;
}

// GetNextToken
int32
Tokenizer::GetNextToken(char *buffer)
{
	if (fEOF)
		return TOKEN_EOF;
	// read next line, if necessary
	if (fEOL) {
		if (!_ReadLine()) {
			fEOF = true;
			return (fLastToken = TOKEN_EOF);
		}
	}
	int32 kind = TOKEN_ERROR;
	// skip WS
	_SkipSpaces();
	fLastPosition = fPosition;
	switch (fCurrentLine[fPosition]) {
		case '\t':
		case '-':
		case '.':
		case '*':
		case 'b':
			kind = fCurrentLine[fPosition];
			fPosition++;
			break;
		case '\0':
			kind = TOKEN_NL;
			fEOL = true;
			break;
		case 't':
		{
			size_t threadLen = strlen("thread");
			if (strlen(fCurrentLine + fPosition) >= threadLen
				&& !strncmp(fCurrentLine + fPosition, "thread", threadLen)) {
				kind = TOKEN_THREAD;
				fPosition += threadLen;
			} else {
				kind = TOKEN_TIMEOUT;
				fPosition++;
			}
			break;
		}
		case 'R':
			if (fCurrentLine[fPosition + 1] == 'L') {
				kind = TOKEN_RL;
				fPosition += 2;
			} else if (fCurrentLine[fPosition + 1] == 'U') {
				kind = TOKEN_RU;
				fPosition += 2;
			} else {
				kind = TOKEN_ERROR;
			}
			break;
		case 'W':
			if (fCurrentLine[fPosition + 1] == 'L') {
				kind = TOKEN_WL;
				fPosition += 2;
			} else if (fCurrentLine[fPosition + 1] == 'U') {
				kind = TOKEN_WU;
				fPosition += 2;
			} else {
				kind = TOKEN_ERROR;
			}
			break;
		default:
		{
			if (isdigit(fCurrentLine[fPosition])) {
				int32 startPos = fPosition;
				while (isdigit(fCurrentLine[fPosition]))
					fPosition++;
				int32 len = fPosition - startPos;
				if (len < kMaxTokenLen) {
					if (buffer) {
						memcpy(buffer, fCurrentLine + startPos, len);
						buffer[len] = '\0';
					}
					kind = TOKEN_NUMBER;
				} else {
					printf("token too long at: %ld\n", startPos);
					kind = TOKEN_ERROR;
				}
			}
			break;
		}
	}
	return (fLastToken = kind);
}

// PutLastToken
void
Tokenizer::PutLastToken()
{
	fEOL = false;
	fPosition = fLastPosition;
}

// GetCurrentLine
const char*
Tokenizer::GetCurrentLine()
{
	return fCurrentLine;
}

// SkipLine
void
Tokenizer::SkipLine()
{
	_ReadLine();
}

// ExpectToken
bool
Tokenizer::ExpectToken(int32 kind, char* buffer)
{
	bool result = (GetNextToken(buffer) == kind);
	if (!result)
		PutLastToken();
	return result;
}

// ReadNumber
bool
Tokenizer::ReadNumber(int64 &number)
{
	char buffer[kMaxTokenLen];
	bool result = ExpectToken(TOKEN_NUMBER, buffer);
	if (result) {
// Not available on PPC.
//		number = atoll(buffer);
		char* end;
		number = strtoll(buffer, &end, 10);
	}
	return result;
}

// _SkipWhiteSpace
void
Tokenizer::_SkipWhiteSpace()
{
	while (fCurrentLine[fPosition] != '\0' && isspace(fCurrentLine[fPosition]))
		fPosition++;
}

// _SkipSpaces
void
Tokenizer::_SkipSpaces()
{
	while (fCurrentLine[fPosition] == ' ')
		fPosition++;
}

// _ReadLine
bool
Tokenizer::_ReadLine()
{
	fPosition = fLastPosition = 0;
	fEOL = false;
	while (fgets(fCurrentLine, kMaxLineLen, fFile)) {
		fLineNumber++;
		int32 len = strlen(fCurrentLine);
		if (len > 0 && fCurrentLine[len - 1] == '\n') {
			len--;
			fCurrentLine[len] = '\0';
		}
		if (fCurrentLine[0] != '#')
			return true;
	}
	return false;
}
