// locking-test.cpp

#include <algobase.h>
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <List.h>
#include <OS.h>
#include <String.h>

#include "TestCaseInterpreter.h"
#include "TestThreadActions.h"
#include "TestSuite.h"
#include "TestSuiteParser.h"
#include "ThreadLocker.h"

// main
int
main()
{
	if (FILE* file = fopen("TestCases", "r")) {
		TestSuiteParser parser(file);
		TestSuite testSuite;
		if (parser.Parse(&testSuite)) {
			TestCaseInterpreter interpreter;
			interpreter.Interpret(&testSuite);
		} else
			printf("Parsing failed!\n");

		fclose(file);
	}
	return 0;
}

