// TestCaseInterpreter.h

#ifndef TEST_CASE_INTERPRETER_H
#define TEST_CASE_INTERPRETER_H

#include <SupportDefs.h>

class TestCase;
class TestSuite;

class TestCaseInterpreter {
public:
								TestCaseInterpreter();
								~TestCaseInterpreter();

			void				Interpret(TestSuite* suite);
			void				Interpret(TestCase* testCase);

private:
			void				_Interpret(TestSuite* suite);

private:
			bigtime_t			fTickLength;
			int32				fTestCount;
			int32				fFailedTests;
};

#endif	// TEST_CASE_INTERPRETER_H
