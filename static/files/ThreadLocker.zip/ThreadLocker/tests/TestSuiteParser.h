// TestSuiteParser.h

#ifndef TEST_SUITE_PARSER_H
#define TEST_SUITE_PARSER_H

#include "Tokenizer.h"

class TestCase;
class TestSuite;

class TestSuiteParser {
public:
								TestSuiteParser(FILE* file);

			bool				Parse(TestSuite* testSuite);

private:
			bool				_ParseTestCase();
			bool				_ParseEventLine();
			bool				_ParseThreadEvent();

			void				_ErrorOccurred(status_t error,
											   const char* description = NULL);
			bool				_NoError() const
									{ return (fParseError == B_OK); }

private:
			Tokenizer			fTokenizer;
			status_t			fParseError;
			TestSuite*			fTestSuite;
			TestCase*			fCurrentTestCase;
			int32				fCurrentTick;
			int32				fCurrentThread;
};


#endif	// TEST_SUITE_PARSER_H
