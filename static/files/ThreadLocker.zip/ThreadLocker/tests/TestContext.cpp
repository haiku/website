// TestContext.cpp

#include <stdio.h>

#include <OS.h>

#include "TestContext.h"

// constructor
TestContext::TestContext(TestCase* testCase, TestThread* threads,
						 bigtime_t tickLength)
	: fTestCase(testCase),
	  fThreads(threads),
	  fLocker(),
	  fStartTime(0),
	  fTickLength(tickLength)
{
}

// destructor
TestContext::~TestContext()
{
}

// WaitForTick
void
TestContext::WaitForTick(double tick) const
{
	snooze_until(fStartTime + bigtime_t(tick * fTickLength),
				 B_SYSTEM_TIMEBASE);
}

// GetCurrentTick
int32
TestContext::GetCurrentTick() const
{
	return (system_time() - fStartTime) / fTickLength;
}

