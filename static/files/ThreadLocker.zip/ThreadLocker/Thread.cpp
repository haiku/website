// Thread.cpp

#include <new>

#include "LockingInfo.h"
#include "Thread.h"

// constructor
/*!	\brief Creates and initializes a Thread object.

	To check for initialization errors InitCheck() should be called afterwards.

	\param id The ID of the thread.
*/
Thread::Thread(thread_id id)
	: fID(id),
	  fSemaphore(-1),
	  fPrevious(NULL),
	  fNext(NULL),
	  fLockingInfo(NULL),
	  fCheckSemaphore(false)
{
	fSemaphore = create_sem(0, "thread semaphore");
	fLockingInfo = new(nothrow) LockingInfo;
}

// destructor
/*!	\brief Frees all resources associated with the object.
*/
Thread::~Thread()
{
	delete_sem(fSemaphore);
	delete fLockingInfo;
}

// GetID
/*!	\brief Returns the ID of the thread.
	\return The ID of the thread.
*/
thread_id
Thread::GetID() const
{
	return fID;
}

// InitCheck
/*!	\brief Returns whether the object is properly initialized.
	\return \c B_OK, if the objects is properly intialized, another error
			code otherwise.
*/
status_t
Thread::InitCheck() const
{
	status_t error = (fSemaphore >= 0 ? B_OK : fSemaphore);
	if (error == B_OK && !fLockingInfo)
		error = B_NO_MEMORY;
	return error;
}

// Block
/*!	\brief Blocks the thread according the the specified parameters.

	Only the thread itself is allowed to invoke this method.

	\param flags Flags passed to acquire_sem_etc().
	\param timeout Timeout passed to acquire_sem_etc().
	\return \c true, if the thread was unblocked by another thread, \c false,
			if a timeout or an error occurred.
*/
bool
Thread::Block(uint32 flags, bigtime_t timeout)
{
	if (fCheckSemaphore)
		acquire_sem_etc(fSemaphore, 1, B_RELATIVE_TIMEOUT, 0);
	fCheckSemaphore = (acquire_sem_etc(fSemaphore, 1, flags, timeout) != B_OK);
	return !fCheckSemaphore;
}

// Unblock
/*!	\brief Unblocks the thread.
*/
void
Thread::Unblock()
{
	release_sem_etc(fSemaphore, 1, B_DO_NOT_RESCHEDULE);
}

