// Thread.h

#ifndef THREAD_H
#define THREAD_H

#include <OS.h>

class LockingInfo;

class Thread {
public:
								Thread(thread_id id);
								~Thread();

			thread_id			GetID() const;

			status_t			InitCheck() const;

			bool				Block(uint32 flags = 0, bigtime_t timeout = 0);
			void				Unblock();

	inline	void				SetPrevious(Thread* thread);
	inline	void				SetNext(Thread* thread);
	inline	Thread*				GetPrevious() const;
	inline	Thread*				GetNext() const;

	inline	LockingInfo*		GetLockingInfo() const;

private:
			thread_id			fID;
			sem_id				fSemaphore;
			Thread*				fPrevious;
			Thread*				fNext;
			LockingInfo*		fLockingInfo;
			bool				fCheckSemaphore;
};

// inline methods

// SetPrevious
inline
void
Thread::SetPrevious(Thread* thread)
{
	fPrevious = thread;
}

// SetNext
inline
void
Thread::SetNext(Thread* thread)
{
	fNext = thread;
}

// GetPrevious
inline
Thread*
Thread::GetPrevious() const
{
	return fPrevious;
}

// GetNext
inline
Thread*
Thread::GetNext() const
{
	return fNext;
}

// GetLockingInfo
inline
LockingInfo*
Thread::GetLockingInfo() const
{
	return fLockingInfo;
}

#endif	// THREAD_H
