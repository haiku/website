// ThreadManager.h

#ifndef THREAD_MANAGER_H
#define THREAD_MANAGER_H

#include <Locker.h>
#include <OS.h>
#include <TLS.h>

class ThreadManager {
public:
								ThreadManager();
								~ThreadManager();

	static inline ThreadManager* GetDefault();

	inline	bool				Lock();
	inline	void				Unlock();
	inline	BLocker*			GetLock();

	inline	Thread*				GetCurrentThread();
			Thread*				GetThread(thread_id threadID,
										  bool create = false);

			Thread*				GetNextThread(int32* cookie) const;

			void				RemoveGoneThreads();

private:
			class ThreadMap;
			class Cleanup;
			friend class Cleanup;

private:
	static	void				_Cleanup();

private:
	static	ThreadManager*		fDefaultManager;
			int32				fTLSHandle;
			BLocker				fLock;
			ThreadMap*			fThreads;
};

// inline methods

// GetDefault
/*!	\brief Returns the singleton instance.
	\return The singleton instance.
*/
inline
ThreadManager*
ThreadManager::GetDefault()
{
	if (!fDefaultManager)
		fDefaultManager = new ThreadManager;
	return fDefaultManager;
}

// Lock
/*!	\brief Locks the thread manager.
	\return \c true, if locking was successful, \c false otherwise.
*/
inline
bool
ThreadManager::Lock()
{
	return fLock.Lock();
}

// Unlock
/*!	\brief Unlocks the thread manager.
*/
inline
void
ThreadManager::Unlock()
{
	fLock.Unlock();
}

// GetLock
/*!	\brief Returns the thread manager's lock.
	\return The thread manager's lock.
*/
inline
BLocker*
ThreadManager::GetLock()
{
	return &fLock;
}

// GetCurrentThread
/*!	\brief Returns the Thread object for the current thread.

	If a Thread object does not yet exist for the thread, a new one is created.

	\return The Thread object for \a threadID or \c NULL, if an error occurred.
*/
inline
Thread*
ThreadManager::GetCurrentThread()
{
	Thread* thread = (Thread*)tls_get(fTLSHandle);
	if (!thread) {
		thread = GetThread(find_thread(NULL), true);
		if (thread)
			tls_set(fTLSHandle, thread);
	}
	return thread;
}

#endif	// THREAD_MANAGER_H
