#include "GlobalData.h"

int         fd;
shared_info * si;
area_id     shared_area;
int         accelerantIsClone;
thread_id   update_thread;
