#include "GlobalData.h"
#include "generic.h"

status_t
SET_CURSOR_SHAPE( uint16 width, uint16 height, uint16 hot_x,
                  uint16 hot_y, uint8 * andMask, uint8 * xorMask )
{
    int i, shift;
    uint32 * alphaCursor;

    TRACE( "SET_CURSOR_SHAPE (%d, %d, %d, %d)\n", width, height, hot_x, hot_y );

    /* Sanity check */
    if( hot_x >= width || hot_y >= height )
    {
        return B_ERROR;
    }

    /* Build ARGB image */
    alphaCursor = calloc( 1, height * width * sizeof( uint32 ) );
    shift = 7;
    for( i = 0; i < height * width; i++ )
    {
        if( !( ( *andMask >> shift ) & 1 ) )
        {
            /* Opaque */
            alphaCursor[i] |= 0xFF000000;
            if( !( ( *xorMask >> shift ) & 1 ) )
            {
                /* White */
                alphaCursor[i] |= 0x00FFFFFF;
            }
        }
        if( --shift < 0 )
        {
            shift = 7;
            andMask++;
            xorMask++;
        }
    }

    /* Give it to VMware */
    fifo_write( SVGA_CMD_DEFINE_ALPHA_CURSOR );
    fifo_write( CURSOR_ID );
    fifo_write( hot_x );
    fifo_write( hot_y );
    fifo_write( width );
    fifo_write( height );
    for( i = 0; i < height * width; i++ )
    {
        fifo_write( alphaCursor[i] );
    }

    free( alphaCursor );

    return B_OK;
}

void
MOVE_CURSOR( uint16 x, uint16 y )
{
    uint16 pos[2];

    //TRACE( "MOVE_CURSOR (%d, %d)\n", x, y );

    pos[0] = x;
    pos[1] = y;
    ioctl( fd, VMWARE_MOVE_CURSOR, pos, sizeof( pos ) );
}

void
SHOW_CURSOR( bool is_visible )
{
    TRACE( "SHOW_CURSOR (%d)\n", is_visible );

    ioctl( fd, VMWARE_SHOW_CURSOR, &is_visible, sizeof( bool ) );
}
