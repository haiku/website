#include "string.h"
#include "unistd.h"
#include "sys/types.h"
#include "sys/stat.h"
#include "fcntl.h"
#include <sys/ioctl.h>

#include "GlobalData.h"
#include "generic.h"

static status_t init_common(int the_fd);

/* Initialization code shared between primary and cloned accelerants */
static
status_t init_common( int the_fd )
{
    status_t ret;

    /* Memorize the file descriptor */
    fd = the_fd;

    /* Contact driver and get a pointer to the registers and shared data */
    if( ( ret = ioctl( fd, VMWARE_GET_PRIVATE_DATA, &shared_area,
                       sizeof( area_id ) ) ) != B_OK )
    {
        TRACE( "VMWARE_GET_PRIVATE_DATA failed (%d\n", ret );
        return ret;
    }

    /* Clone the shared area for our use */
    if( ( shared_area = clone_area( "VMware shared", (void **) &si,
          B_ANY_ADDRESS, B_READ_AREA | B_WRITE_AREA, shared_area ) ) < 0 )
    {
        TRACE( "could not clone shared area (%d)\n", shared_area );
        return shared_area;
    }

    return B_OK;
}

static void
uninit_common()
{
    delete_area( shared_area );
}

/* We explicitely need to tell VMware what and when something should
   be refreshed from the frame buffer. Since the app_server doesn't
   tell us what it's doing, we simply force a full screen update
   every 1/50 second */
static int32 force_update( void * data )
{
    bigtime_t begin, end, wait;

    while( 1 )
    {
        begin = system_time();
        fifo_update_fullscreen();
        end = system_time();

        /* 50 Hz refresh */
        wait = 20000 - ( end - begin );
        if( wait > 0 )
        {
            snooze( wait );
        }
    }
}

status_t INIT_ACCELERANT( int the_fd )
{
    status_t ret;

    TRACE( "INIT_ACCELERANT (%d)\n", the_fd );

    accelerantIsClone = 0;

    /* Common initialization for the primary accelerant and clones */
    if( ( ret = init_common( the_fd ) ) == B_OK )
    {
        /* Init semaphores */
        INIT_BEN( si->engine_lock );

        /* Launch update thread */
        update_thread = spawn_thread( force_update, "VMware",
                                      B_REAL_TIME_DISPLAY_PRIORITY, NULL );
        resume_thread( update_thread );
    }

    TRACE( "INIT_ACCELERANT: %d\n", ret );
    return ret;
}

ssize_t
ACCELERANT_CLONE_INFO_SIZE()
{
    return MAX_SAMPLE_DEVICE_NAME_LENGTH;
}

void
GET_ACCELERANT_CLONE_INFO( void * data )
{
    /* TODO */
}

status_t
CLONE_ACCELERANT( void * data )
{
    /* TODO */
    return B_ERROR;
}

void
UNINIT_ACCELERANT()
{
    uninit_common();
    if( accelerantIsClone )
    {
        close( fd );
    }
    else
    {
        kill_thread( update_thread );
        ioctl( fd, VMWARE_FIFO_STOP, NULL, 0 );
    }
}
