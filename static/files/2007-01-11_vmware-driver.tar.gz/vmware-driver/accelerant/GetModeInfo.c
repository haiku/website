#include "GlobalData.h"
#include "generic.h"

status_t
GET_DISPLAY_MODE( display_mode * current_mode )
{
    TRACE( "GET_DISPLAY_MODE\n" );

    *current_mode = si->dm;
    return B_OK;
}

status_t
GET_FRAME_BUFFER_CONFIG( frame_buffer_config * afb )
{
    TRACE( "GET_FRAME_BUFFER_CONFIG\n" );

    afb->frame_buffer = si->fb + si->fb_offset;
    afb->frame_buffer_dma = si->fb_dma + si->fb_offset;
    afb->bytes_per_row = si->bytes_per_row;

    TRACE( "fb: %p, fb_dma: %p, row: %d bytes\n", afb->frame_buffer,
           afb->frame_buffer_dma, afb->bytes_per_row );

    return B_OK;
}

status_t
GET_PIXEL_CLOCK_LIMITS( display_mode * dm, uint32 * low, uint32 * high )
{
    TRACE( "GET_PIXEL_CLOCK_LIMITS\n" );

    /* ? */
    *low = 1;
    *high = 0xFFFFFFFF;
    return B_OK;
}

sem_id
ACCELERANT_RETRACE_SEMAPHORE()
{
    return B_ERROR;
}
