#include "GlobalData.h"

void
SCREEN_TO_SCREEN_BLIT( engine_token * et, blit_params * list, uint32 count )
{
    int i;
    blit_params * b;

    for( i = 0; i < count; i++ )
    {
        b = &list[i];
#if 0
        TRACE( "BLIT %dx%d, %dx%d->%dx%d\n", b->width + 1, b->height + 1,
               b->src_left, b->src_top, b->dest_left, b->dest_top );
#endif
        fifo_write( SVGA_CMD_RECT_COPY );
        fifo_write( b->src_left );
        fifo_write( b->src_top );
        fifo_write( b->dest_left );
        fifo_write( b->dest_top );
        fifo_write( b->width + 1 );
        fifo_write( b->height + 1 );
    }
}

void
FILL_RECTANGLE( engine_token * et, uint32 colorIndex,
                fill_rect_params * list, uint32 count )
{
    int i;
    fill_rect_params * f;

    for( i = 0; i < count; i++ )
    {
        f = &list[i];
#if 0
        TRACE( "FILL %lX, %dx%d->%dx%d\n", colorIndex,
               f->left, f->top, f->right, f->bottom );
#endif
        /* TODO */
    }
}

void
INVERT_RECTANGLE( engine_token * et, fill_rect_params * list, uint32 count )
{
    /* TODO */
}

void
FILL_SPAN( engine_token * et, uint32 colorIndex, uint16 * list, uint32 count )
{
    /* TODO */
}
