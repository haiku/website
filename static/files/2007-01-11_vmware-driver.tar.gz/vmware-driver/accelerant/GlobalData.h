#ifndef GLOBALDATA_H
#define GLOBALDATA_H

#include <support/Debug.h>
#undef TRACE
#define TRACE( a... ) _sPrintf( "VMware: " ##a )

#include "DriverInterface.h"
#include "generic.h"

/* Global variables */
extern int         fd;
extern shared_info * si;
extern area_id     shared_area;
extern int         accelerantIsClone;
extern thread_id   update_thread;

/* Fifo.c */
void fifo_init();
void fifo_sync();
void fifo_write( uint32 value );
void fifo_update_fullscreen();

#endif
