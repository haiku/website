#include "GlobalData.h"
#include "generic.h"

status_t
SET_DISPLAY_MODE( display_mode * mode_to_set )
{
    display_mode bounds, target;
    int bpp;

    TRACE( "SET_DISPLAY_MODE\n" );

    /* Ask for the specific mode */
    target = bounds = *mode_to_set;
    if( PROPOSE_DISPLAY_MODE( &target, &bounds, &bounds ) == B_ERROR )
    {
        return B_ERROR;
    }

    bpp = bpp_for_space( target.space );

    TRACE( "setting %dx%dx%d\n", target.virtual_width,
               target.virtual_height, bpp );

    si->dm = target;

    /* Disable SVGA while we switch */
    ioctl( fd, VMWARE_FIFO_STOP, NULL, 0 );

    /* Re-init fifo */
    fifo_init();

    /* Set resolution. This also updates the frame buffer config in the
     * shared area */
    ioctl( fd, VMWARE_SET_MODE, &target, sizeof( target ) );

    /* Blank the screen to avoid ugly glitches until the app_server redraws */
    memset( si->fb, 0, target.virtual_height * si->bytes_per_row );
    fifo_update_fullscreen();

    /* Re-enable SVGA */
    ioctl( fd, VMWARE_FIFO_START, NULL, 0 );

    return B_OK;
}

status_t
MOVE_DISPLAY( uint16 h_display_start, uint16 v_display_start )
{
    TRACE( "MOVE_DISPLAY (%d, %d)\n", h_display_start, v_display_start );
    return B_ERROR;
}

void
SET_INDEXED_COLORS( uint count, uint8 first, uint8 * color_data,
                    uint32 flags )
{
    TRACE( "SET_INDEXED_COLORS\n" );
}

/***********************************************************************
 * DPMS_CAPABILITIES
 ***********************************************************************
 * Reports DPMS capabilities (on, stand by, suspend, off).
 **********************************************************************/
uint32
DPMS_CAPABILITIES()
{
    /* We stay always on */
    return B_DPMS_ON;
}

/***********************************************************************
 * DPMS_MODE
 ***********************************************************************
 * Reports the current DPMS mode.
 **********************************************************************/
uint32
DPMS_MODE()
{
    return B_DPMS_ON;
}

/***********************************************************************
 * SET_DPMS_MODE
 ***********************************************************************
 * Puts the display into one of the DPMS modes.
 **********************************************************************/
status_t
SET_DPMS_MODE( uint32 flags )
{
    return B_ERROR;
}
