#include "GlobalData.h"

static void fifo_print_capabilities( int c )
{
    TRACE( "fifo capabilities:\n" );
    if( c & SVGA_FIFO_CAP_FENCE )      TRACE( "FENCE\n" );
    if( c & SVGA_FIFO_CAP_ACCELFRONT ) TRACE( "ACCELFRONT\n" );
    if( c & SVGA_FIFO_CAP_PITCHLOCK )  TRACE( "PITCHLOCK\n" );
}

void fifo_init()
{
    uint32 * fifo = si->fifo;

    memset( fifo, 0, si->fifo_size );

    si->fifo_capabilities = 0;
    si->fifo_flags = 0;
    if( si->capabilities & SVGA_CAP_EXTENDED_FIFO )
    {
        si->fifo_capabilities = fifo[SVGA_FIFO_CAPABILITIES];
        fifo_print_capabilities( si->fifo_capabilities );
        si->fifo_flags = fifo[SVGA_FIFO_FLAGS];
    }

    fifo[SVGA_FIFO_MIN]      = si->fifo_min * 4;
    fifo[SVGA_FIFO_MAX]      = si->fifo_size;
    fifo[SVGA_FIFO_NEXT_CMD] = fifo[SVGA_FIFO_MIN];
    fifo[SVGA_FIFO_STOP]     = fifo[SVGA_FIFO_MIN];

    TRACE( "init fifo: %ld -> %ld\n",
           fifo[SVGA_FIFO_MIN], fifo[SVGA_FIFO_MAX] );
}

void fifo_sync()
{
    ioctl( fd, VMWARE_FIFO_SYNC, NULL, 0 );
}

void fifo_write( uint32 value )
{
    uint32 * fifo = si->fifo;

    if( ( fifo[SVGA_FIFO_NEXT_CMD] + 4 == fifo[SVGA_FIFO_STOP] ) ||
        ( fifo[SVGA_FIFO_NEXT_CMD] == fifo[SVGA_FIFO_MAX] - 4 &&
          fifo[SVGA_FIFO_STOP] == fifo[SVGA_FIFO_MIN] ) )
    {
        /* Fifo is full */
        fifo_sync();
    }

    fifo[fifo[SVGA_FIFO_NEXT_CMD] / 4] = value;
    if( fifo[SVGA_FIFO_NEXT_CMD] == fifo[SVGA_FIFO_MAX] - 4 )
    {
        fifo[SVGA_FIFO_NEXT_CMD] = fifo[SVGA_FIFO_MIN];
    }
    else
    {
        fifo[SVGA_FIFO_NEXT_CMD] += 4;
    }
}

void fifo_update_fullscreen()
{
    fifo_write( SVGA_CMD_UPDATE );
    fifo_write( 0 );
    fifo_write( 0 );
    fifo_write( si->dm.virtual_width );
    fifo_write( si->dm.virtual_height );
}
