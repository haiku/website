#define TRACE( a... ) dprintf( "VMware: " ##a )

#include "DriverInterface.h"

typedef struct
{
    char        * names[2];
    benaphore   kernel;
    uint32      is_open;
    area_id     shared_area;
    shared_info * si;
    pci_info    pcii;
}
DeviceData;

/* Driver.c */
extern DeviceData * pd;
extern pci_module_info * pci_bus;

/* Hooks.c */
extern device_hooks graphics_device_hooks;

/******************************************************************************
 * read_reg, write_reg
 ******************************************************************************
 * Let you read/write 32 bit registers in the IO address space.
 *****************************************************************************/
static inline uint32 inl( uint16 port )
{
    uint32 ret;
    __asm__ __volatile__( "inl %w1, %0" : "=a" (ret) : "Nd" (port) );
    return ret;
}
static inline void outl( uint16 port, uint32 value )
{
    __asm__ __volatile__( "outl %1, %w0" :: "Nd" (port), "a" (value) );
}
#define read_reg( a ) _read_reg( si, (a) )
static inline uint32 _read_reg( shared_info * _si, uint32 index )
{
    outl( _si->index_port, index );
    return inl( _si->value_port );
}
#define write_reg( a, b ) _write_reg( si, (a), (b) )
static inline void _write_reg( shared_info * _si, uint32 index, uint32 value )
{
    outl( _si->index_port, index );
    outl( _si->value_port, value );
}
