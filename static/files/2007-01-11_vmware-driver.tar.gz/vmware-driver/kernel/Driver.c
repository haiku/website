#include <KernelExport.h>
#include <PCI.h>
#include <OS.h>
#include <malloc.h>
#include <string.h>
#include "Driver.h"

/* Global */
DeviceData * pd;
pci_module_info * pci_bus;

/*****************************************************************************
 * api_version
 *****************************************************************************
 * Tells the kernel what revision of the driver API we support
 ****************************************************************************/
int32 api_version = B_CUR_DRIVER_API_VERSION;

/*****************************************************************************
 * init_hardware
 *****************************************************************************
 * Returns B_OK if a device is found, B_ERROR otherwise.
 ****************************************************************************/
status_t
init_hardware()
{   
    status_t ret = B_ERROR;
    pci_info pcii;
    int i;

    TRACE( "init_hardware\n" );

    if( get_module( B_PCI_MODULE_NAME, (module_info **) &pci_bus ) != B_OK )
    {
        return B_ERROR;
    }

    for( i = 0; (*pci_bus->get_nth_pci_info)( i, &pcii ) == B_OK; i++ )
    {
        if( pcii.vendor_id == PCI_VENDOR_ID_VMWARE &&
            pcii.device_id == PCI_DEVICE_ID_VMWARE_SVGA2 )
        {   
            ret = B_OK;
            break;
        }
    }

    put_module( B_PCI_MODULE_NAME );

    TRACE( "init_hardware: %ld\n", ret );
    return ret;
}

/*****************************************************************************
 * init_driver
 *****************************************************************************
 * Allocates needed resources.
 ****************************************************************************/
status_t
init_driver()
{
    status_t ret = B_OK;
    int i;

    TRACE( "init_driver\n" );

    if( get_module( B_PCI_MODULE_NAME, (module_info **) &pci_bus ) != B_OK )
    {
        ret = B_ERROR;
        goto done;
    }

    if( !( pd = calloc( 1, sizeof( DeviceData ) ) ) )
    {
        put_module( B_PCI_MODULE_NAME );
        ret = B_ERROR;
        goto done;
    }

    /* Remember the PCI information */
    for( i = 0; (*pci_bus->get_nth_pci_info)( i, &pd->pcii ) == B_OK; i++ )
    {
        if( pd->pcii.vendor_id == PCI_VENDOR_ID_VMWARE &&
            pd->pcii.device_id == PCI_DEVICE_ID_VMWARE_SVGA2 )
        {   
            break;
        }
    }

    /* Create a benaphore for exclusive access in open_hook/free_hook */
    INIT_BEN( pd->kernel );

    /* The device name */
    pd->names[0] = strdup( "graphics/vmware" );
    pd->names[1] = NULL;

    /* Usual initializations */
    pd->is_open = 0;
    pd->shared_area = -1;
    pd->si = NULL;

done:
    TRACE( "init_driver: %ld\n", ret );
    return ret;
}

/*****************************************************************************
 * publish_devices
 *****************************************************************************
 * Returns the list of supported devices.
 ****************************************************************************/
const char **
publish_devices()
{
    TRACE( "publish_devices\n" );
    return (const char **) pd->names;
}

/*****************************************************************************
 * find_device
 *****************************************************************************
 *
 ****************************************************************************/
device_hooks *
find_device( const char * name )
{
    TRACE( "find_device (%s)\n", name );
    if( pd->names[0] && !strcmp( pd->names[0], name ) )
    {
        return &graphics_device_hooks;
    }
    return NULL;
}

/*****************************************************************************
 * uninit_driver
 *****************************************************************************
 *
 ****************************************************************************/
void uninit_driver()
{
    TRACE( "uninit_driver\n" );
    free( pd );
    pd = NULL;
    put_module( B_PCI_MODULE_NAME );
}
