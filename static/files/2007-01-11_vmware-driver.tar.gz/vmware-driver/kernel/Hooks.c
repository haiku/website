#include <KernelExport.h>
#include <PCI.h>
#include <OS.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <graphic_driver.h>

#include "Driver.h"

#define get_pci(o, s) (*pci_bus->read_pci_config)(pcii->bus, pcii->device, pcii->function, (o), (s))
#define set_pci(o, s, v) (*pci_bus->write_pci_config)(pcii->bus, pcii->device, pcii->function, (o), (s), (v))

static void
print_capabilities( uint32 c )
{
    TRACE( "capabilities:\n" );
    if( c & SVGA_CAP_RECT_FILL )        TRACE( "RECT_FILL\n" );
    if( c & SVGA_CAP_RECT_COPY )        TRACE( "RECT_COPY\n" );
    if( c & SVGA_CAP_RECT_PAT_FILL )    TRACE( "RECT_PAT_FILL\n" );
    if( c & SVGA_CAP_LEGACY_OFFSCREEN ) TRACE( "LEGACY_OFFSCREEN\n" );
    if( c & SVGA_CAP_RASTER_OP )        TRACE( "RASTER_OP\n" );
    if( c & SVGA_CAP_CURSOR )           TRACE( "CURSOR\n" );
    if( c & SVGA_CAP_CURSOR_BYPASS )    TRACE( "CURSOR_BYPASS\n" );
    if( c & SVGA_CAP_CURSOR_BYPASS_2 )  TRACE( "CURSOR_BYPASS_2\n" );
    if( c & SVGA_CAP_8BIT_EMULATION )   TRACE( "8BIT_EMULATION\n" );
    if( c & SVGA_CAP_ALPHA_CURSOR )     TRACE( "ALPHA_CURSOR\n" );
    if( c & SVGA_CAP_GLYPH )            TRACE( "GLYPH\n" );
    if( c & SVGA_CAP_GLYPH_CLIPPING )   TRACE( "GLYPH_CLIPPING\n" );
    if( c & SVGA_CAP_OFFSCREEN_1 )      TRACE( "OFFSCREEN_1\n" );
    if( c & SVGA_CAP_ALPHA_BLEND )      TRACE( "ALPHA_BLEND\n" );
    if( c & SVGA_CAP_3D )               TRACE( "3D\n" );
    if( c & SVGA_CAP_EXTENDED_FIFO )    TRACE( "EXTENDED_FIFO\n" );
}

static status_t
check_capabilities()
{
    shared_info * si = pd->si;
    uint32 id;

    /* Needed to read/write registers */
    si->index_port = pd->pcii.u.h0.base_registers[0] + SVGA_INDEX_PORT;
    si->value_port = pd->pcii.u.h0.base_registers[0] + SVGA_VALUE_PORT;
    TRACE( "index_port: %d, value_port: %d\n",
               si->index_port, si->value_port );

    /* This should be SVGA II according to the PCI device_id,
       but just in case... */
    write_reg( SVGA_REG_ID, SVGA_ID_2 );
    if( ( id = read_reg( SVGA_REG_ID ) ) != SVGA_ID_2 )
    {
        TRACE( "SVGA_REG_ID is %ld, not %d\n", id, SVGA_REG_ID );
        return B_ERROR;
    }
    TRACE( "SVGA_REG_ID OK\n" );

    /* Grab some info */
    si->max_width = read_reg( SVGA_REG_MAX_WIDTH );
    si->max_height = read_reg( SVGA_REG_MAX_HEIGHT );
    TRACE( "max resolution: %ldx%ld\n", si->max_width, si->max_height );
    si->fb_dma = (void *) read_reg( SVGA_REG_FB_START );
    si->fb_size = read_reg( SVGA_REG_VRAM_SIZE );
    TRACE( "frame buffer: %p, size %ld\n", si->fb_dma, si->fb_size );
    si->fifo_dma = (void *) read_reg( SVGA_REG_MEM_START );
    si->fifo_size = read_reg( SVGA_REG_MEM_SIZE ) & ~3;
    TRACE( "fifo: %p, size %ld\n", si->fifo_dma, si->fifo_size );
    si->capabilities = read_reg( SVGA_REG_CAPABILITIES );
    print_capabilities( si->capabilities );
    si->fifo_min = ( si->capabilities & SVGA_CAP_EXTENDED_FIFO ) ?
        read_reg( SVGA_REG_MEM_REGS ) : 4;

    return B_OK;
}

static status_t map_device()
{
    shared_info * si = pd->si;
    int write_combined = 1;

    /* Map the frame buffer */
    si->fb_area = map_physical_memory( "VMware frame buffer",
        si->fb_dma, si->fb_size, B_ANY_KERNEL_BLOCK_ADDRESS | B_MTR_WC,
        B_READ_AREA | B_WRITE_AREA, (void **) &si->fb );
    if( si->fb_area < 0 )
    {
        /* Try again without write combining */
        write_combined = 0;
        si->fb_area = map_physical_memory( "VMware frame buffer",
            si->fb_dma, si->fb_size, B_ANY_KERNEL_BLOCK_ADDRESS,
            B_READ_AREA | B_WRITE_AREA, (void **) &si->fb );
    }
    if( si->fb_area < 0 )
    {
        TRACE( "failed to map frame buffer\n" );
        return si->fb_area;
    }
    TRACE( "frame buffer mapped: %p->%p, area %ld, size %ld, write "
            "combined: %d\n", si->fb_dma, si->fb, si->fb_area,
            si->fb_size, write_combined );

    /* Map the fifo */
    si->fifo_area = map_physical_memory( "VMware fifo",
        si->fifo_dma, si->fifo_size, B_ANY_KERNEL_BLOCK_ADDRESS,
        B_READ_AREA | B_WRITE_AREA,  (void **) &si->fifo );
    if( si->fifo_area < 0 )
    {
        TRACE( "failed to map fifo\n" );
        delete_area( si->fb_area );
        return si->fifo_area;
    }
    TRACE( "fifo mapped: %p->%p, area %ld, size %ld\n", si->fifo_dma,
           si->fifo, si->fifo_area, si->fifo_size );

    return B_OK;
}

static void unmap_device()
{
    shared_info * si = pd->si;
    pci_info * pcii = &pd->pcii;
    uint32 tmpUlong;

    /* Disable memory mapped IO */
    tmpUlong = get_pci( PCI_command, 2 );
    tmpUlong &= ~PCI_command_memory;
    set_pci( PCI_command, 2, tmpUlong );

    /* Delete the areas */
    if( si->fifo_area >= 0 ) delete_area( si->fifo_area );
    if( si->fb_area >= 0 ) delete_area( si->fb_area );
    si->fifo_area = si->fb_area = -1;
    si->fb = si->fifo = NULL;
}

static status_t create_shared()
{
    pd->shared_area = create_area( "VMware shared", (void **) &pd->si,
        B_ANY_KERNEL_ADDRESS, ROUND_TO_PAGE_SIZE( sizeof( shared_info ) ),
        B_FULL_LOCK, 0 );
    if( pd->shared_area < B_OK )
    {
        TRACE( "failed to create shared area\n" );
        return pd->shared_area;
    }
    TRACE( "shared area created\n" );

    memset( pd->si, 0, sizeof( shared_info ) );
    return B_OK;
}

static void free_shared()
{
    delete_area( pd->shared_area );
    pd->shared_area = -1;
    pd->si = NULL;
}

static status_t
open_hook( const char * name, uint32 flags, void ** cookie )
{
    status_t ret = B_OK;
    pci_info * pcii = &pd->pcii;
    uint32 tmpUlong;

    TRACE( "open_hook (%s, %ld)\n", name, flags );
    ACQUIRE_BEN( pd->kernel );

    if( pd->is_open )
    {
        goto mark_as_open;
    }

    /* Enable memory mapped IO and VGA I/O */
    tmpUlong = get_pci( PCI_command, 2 );
    tmpUlong |= PCI_command_memory;
    tmpUlong |= PCI_command_io;
    set_pci( PCI_command, 2, tmpUlong );

    if( ( ret = create_shared() ) != B_OK )
    {
        goto done;
    }
    if( ( ret = check_capabilities() ) != B_OK )
    {
        goto free_shared;
    }
    if( ( ret = map_device() ) != B_OK )
    {
        goto free_shared;
    }

mark_as_open:
    pd->is_open++;
    *cookie = pd;
    goto done;

free_shared:
    free_shared();

done:
    RELEASE_BEN( pd->kernel );
    TRACE( "open_hook: %ld\n", ret );
    return ret;
}

/*****************************************************************************
 * read_hook, write_hook, close_hook
 *****************************************************************************
 * Do nothing.
 ****************************************************************************/
static status_t
read_hook( void * dev, off_t pos, void * buf, size_t * len )
{
    *len = 0;
    return B_NOT_ALLOWED;
}
static status_t
write_hook( void * dev, off_t pos, const void * buf, size_t * len )
{
    *len = 0;
    return B_NOT_ALLOWED;
}
static status_t
close_hook( void * dev )
{
    return B_OK;
}

/*****************************************************************************
 * free_hook
 *****************************************************************************
 * Closes down the device
 ****************************************************************************/
static status_t
free_hook( void * dev )
{
    TRACE( "free_hook\n");
    ACQUIRE_BEN( pd->kernel );

    if( pd->is_open < 2 )
    {
        unmap_device();
        free_shared();
    }
    pd->is_open--;

    RELEASE_BEN( pd->kernel );
    TRACE( "free_hook ends\n" );
    return B_OK;
}

/*****************************************************************************
 * control_hook
 *****************************************************************************
 * Responds the the ioctl from the accelerant
 ****************************************************************************/
static status_t
control_hook( void * dev, uint32 msg, void * buf, size_t len )
{
    shared_info * si = pd->si;

    switch( msg )
    {
        case B_GET_ACCELERANT_SIGNATURE:
            strcpy( (char *) buf, "vmware.accelerant");
            return B_OK;

        case VMWARE_GET_PRIVATE_DATA:
            *((area_id *) buf) = pd->shared_area;
            return B_OK;

        case VMWARE_FIFO_START:
            write_reg( SVGA_REG_ENABLE, 1 );
            write_reg( SVGA_REG_CONFIG_DONE, 1 );
            return B_OK;

        case VMWARE_FIFO_STOP:
            write_reg( SVGA_REG_CONFIG_DONE, 0 );
            write_reg( SVGA_REG_ENABLE, 0 );
            return B_OK;

        case VMWARE_FIFO_SYNC:
            write_reg( SVGA_REG_SYNC, 1 );
            while( read_reg( SVGA_REG_BUSY ) );
            return B_OK;

        case VMWARE_SET_MODE:
        {
            display_mode * dm = buf;
            write_reg( SVGA_REG_WIDTH, dm->virtual_width );
            write_reg( SVGA_REG_HEIGHT, dm->virtual_height );
            write_reg( SVGA_REG_BITS_PER_PIXEL, bpp_for_space( dm->space ) );
            si->fb_offset = read_reg( SVGA_REG_FB_OFFSET );
            si->bytes_per_row = read_reg( SVGA_REG_BYTES_PER_LINE );
            return B_OK;
        }

        case VMWARE_MOVE_CURSOR:
        {
            uint16 * pos = buf;
            write_reg( SVGA_REG_CURSOR_ID, CURSOR_ID );
            write_reg( SVGA_REG_CURSOR_X, pos[0] );
            write_reg( SVGA_REG_CURSOR_Y, pos[1] );
            return B_OK;
        }

        case VMWARE_SHOW_CURSOR:
        {
            bool show = *( (bool *) buf );
            write_reg( SVGA_REG_CURSOR_ON, show ?
                       SVGA_CURSOR_ON_HIDE : SVGA_CURSOR_ON_SHOW );
            return B_OK;
        }
    }

    TRACE( "ioctl: %ld, %p, %ld\n", msg, buf, len );
    return B_DEV_INVALID_IOCTL;
}

device_hooks graphics_device_hooks =
{
    open_hook,
    close_hook,
    free_hook,
    control_hook,
    read_hook,
    write_hook,
    NULL,
    NULL,
    NULL,
    NULL
};
