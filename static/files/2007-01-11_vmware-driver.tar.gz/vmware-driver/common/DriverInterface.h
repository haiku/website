#ifndef DRIVERINTERFACE_H
#define DRIVERINTERFACE_H

#include <Accelerant.h>
#include <Drivers.h>
#include <PCI.h>
#include <OS.h>

/* Vmware defines */
#include "vm_device_version.h"
#include "svga_reg.h"

#define MAX_SAMPLE_DEVICE_NAME_LENGTH 32
#define CURSOR_ID                     1

/***********************************************************************
 * Benaphores
 **********************************************************************/
typedef struct
{
    sem_id  sem;
    int32   ben;
}
benaphore;
#define INIT_BEN(x)     x.sem = create_sem( 0, "VMware "#x ); x.ben = 0;
#define ACQUIRE_BEN(x)  if((atomic_add(&(x.ben), 1)) >= 1) acquire_sem(x.sem);
#define RELEASE_BEN(x)  if((atomic_add(&(x.ben), -1)) > 1) release_sem(x.sem);
#define DELETE_BEN(x)   delete_sem(x.sem);

/***********************************************************************
 * Utils
 **********************************************************************/
#define ROUND_TO_PAGE_SIZE(x) (((x)+(B_PAGE_SIZE)-1)&~((B_PAGE_SIZE)-1))

static int
bpp_for_space( int space )
{
    switch( space )
    {
        case B_RGB32:
            return 32;
        case B_RGB24:
            return 24;
        case B_RGB16:
            return 16;
        case B_RGB15:
            return 15;
        case B_CMAP8:
            return 8;
    }
    return 0;
}

/***********************************************************************
 * Request codes for ioctl()
 **********************************************************************/
enum
{
    VMWARE_GET_PRIVATE_DATA = B_DEVICE_OP_CODES_END + 1,
    VMWARE_FIFO_START,
    VMWARE_FIFO_STOP,
    VMWARE_FIFO_SYNC,
    VMWARE_SET_MODE,
    VMWARE_MOVE_CURSOR,
    VMWARE_SHOW_CURSOR,
};

/***********************************************************************
 * Structure shared between the kernel driver and the accelerant
 **********************************************************************/
typedef struct
{
    /* Device info and capabilities */
    uint16  vendor_id;
    uint16  device_id;
    uint8   revision;
    uint32  max_width;
    uint32  max_height;
    void    * fb_dma;
    uint32  fb_size;
    void    * fifo_dma;
    uint32  fifo_size;
    uint32  fifo_min;
    uint32  capabilities;
    uint32  fifo_capabilities;
    uint32  fifo_flags;

    /* For registers access */
    uint16  index_port;
    uint16  value_port;

    /* Mapped areas */
    area_id fb_area;
    void    * fb;
    area_id fifo_area;
    void    * fifo;

    /* This changes when we switch to another mode */
    uint32  fb_offset;
    uint32  bytes_per_row;

    /* Current display mode */
    display_mode dm;

    benaphore engine_lock;
}
shared_info;

#endif
