/*! \file example.h
    \brief Example C++ header file with Doxygen comments
    
    If there were anything else particularly interesting to
    say about the file, I would say it here. :)
*/

#ifndef EXAMPLE_H
#define EXAMPLE_H

#include <SupportDefs.h>

#include <string>

//----------------------------------------------------------------------------
// Cardboard box classes
//----------------------------------------------------------------------------

class CardboardBox {
public:
	CardboardBox(uint32 width, uint32 height, uint32 depth);
protected:
	uint32 fWidth;
	uint32 fHeight;
	uint32 fDepth;
};

//----------------------------------------------------------------------------
// Popcorn classes
//----------------------------------------------------------------------------

/// A class that simulates a container of popcorn.
/** This class is simply an abstract interface; please use
    a specific subclass if you want popcorn.
*/
class PopcornContainer {
public:
	PopcornContainer(bool withButter);	
	virtual void Consume() = 0;  //!< Initiates consumption of the popcorn.
	                             /*!< This operation may take a while to complete,
	                                  depending upon the type of container used. */
protected:
	bool fWithButter;  ///< Whether or not the popcorn should have extra butter
};

//! A class that simulates a bag of popcorn. (header brief comment)
/*! The BagOfPopcorn class should not be confused with the
    BucketOfPopcorn class. (header detailed comment)
*/
class BagOfPopcorn : public PopcornContainer {
public:
	BagOfPopcorn(bool withButter);
	virtual void Consume();
};

/// A class that simulates a bucket of popcorn. 
/** The BucketOfPopcorn class should not be confused with the (inferior,
    but slightly less expensive) BagOfPopcorn class.
*/
class BucketOfPopcorn : public PopcornContainer, CardboardBox {
public:
	BucketOfPopcorn(uint32 width, uint32 height, uint32 depth, bool withButter);
	virtual void Consume();
	void EmptyOverHeadOfSmartass();
};

//----------------------------------------------------------------------------
// Poetry classes
//----------------------------------------------------------------------------

enum Language {
	AmericanEnglish,
	BritishEnglish,
	CanadianEnglish,
	French,
	German,
	Japanese,
	Portugese,
	Spanish,
};

typedef int32 Tempo;	

class Poem {
public:
	Poem(const char *poem);
	status_t Recite(Language language, Tempo tempo);
private:
	friend class Beatnik;
	std::string fPoem;	//!< The text of the poem to be recited
};

#endif // EXAMPLE_H
