/*! \file example.cpp
    \brief Example C++ source file with Doxygen comments
    
    This stupid thing actually compiles on BeOS R5. Try:    
    <pre>gcc example.cpp /boot/develop/lib/x86/libstdc++.r4.so -lbe</pre>
*/

#include "example.h"

#include <stdio.h>

/*! \brief Handy little macro used to turn debugging output on and off

	If \c DBG(x) is defined as:
	<pre>#define DBG(x) (x)</pre>
	debugging output is turned on; if defined as:
	<pre>#define DBG(x)</pre>
	debugging output is turned off; if defined as
	anything else, you're asking for trouble.
*/
#define DBG(x) (x)
//#define DBG(x)

//----------------------------------------------------------------------------
// main()
//----------------------------------------------------------------------------

//! Where the magic would happen if there were any (there's not).
int main() {
	printf("This program does nothing useful whatsoever.\n");
	printf("Thank you for your interest!\n");
	return 0;
}

//----------------------------------------------------------------------------
// CardboardBox 
//----------------------------------------------------------------------------

/*! \class CardboardBox
    \brief A class that simulates a cardboard box.
    
    - Things cardboard boxes are good for
      -# Being worn as a helmet
      -# Being thrown at strangers
      -# Being used as a fort
      -# Being used to store popcorn while it is consumed
    - Things cardboard boxes are not good for
      -# Being used as pillows
      -# Being used to transport water
*/

//! Creates a shiny new cardboard box with the given dimensions.
/*! \param width The desired width of the box, in centimeters.
	\param height The desired height of the box, in centimeters.
	\param depth The desired depth of the box, in centimeters.
*/
CardboardBox::CardboardBox(uint32 width, uint32 height, uint32 depth)
	: fWidth(width)
	, fHeight(height)
	, fDepth(depth)
{
	DBG(printf("Creating a shiny new cardboard box\n"));
}

//----------------------------------------------------------------------------
// PopcornContainer
//----------------------------------------------------------------------------

PopcornContainer::PopcornContainer(bool withButter)
	: fWithButter(withButter)
{
}

//----------------------------------------------------------------------------
// BagOfPopcorn
//----------------------------------------------------------------------------

/*! \class BagOfPopcorn
    \brief A class that simulates a bag of popcorn. (source brief comment)
    
    The BagOfPopcorn class should not be confused with the
    BucketOfPopcorn class. (source detailed comment)
*/

BagOfPopcorn::BagOfPopcorn(bool withButter)
	: PopcornContainer(withButter)
{
}

void
BagOfPopcorn::Consume() {
}

//----------------------------------------------------------------------------
// BucketOfPopcorn
//----------------------------------------------------------------------------

BucketOfPopcorn::BucketOfPopcorn(uint32 width, uint32 height,
                                 uint32 depth, bool withButter)
	: PopcornContainer(withButter)
	, CardboardBox(width, height, depth)
{
}

void
BucketOfPopcorn::Consume() {
}

/*! \todo Implement smartass defense tactics. */
void
BucketOfPopcorn::EmptyOverHeadOfSmartass()
{
}

//----------------------------------------------------------------------------
// Poetry classes
//----------------------------------------------------------------------------

/*! \enum Language
    \brief Currently supported languages, only one of which I actually
    speak with any sort of success.
*/

/*! \class Poem
    \brief Poems are really anything you want them to be.
    
    Honestly, you could write a novel and call it a poem. People would be
    like, "That's not a poem, you chump, that's a novel", and you could
    be like, "It's art, you fool, it's whatever I want it to be" and there's
    really nothing they could do except not buy your art, which would suck,
    but hey, that's the cost of being right sometimes.
*/

/*! \brief Creates a new poem.
*/
Poem::Poem(const char *poem)
	: fPoem(poem)
{
}

/*! \brief Recites the poem in the given language at the given tempo.

    \param language The language in which the poem should be recited.
    \param tempo The speed at which the poem should recited.
    \return
    - \c B_OK: success
    - \c B_BAD_POEM: returned if your poem sucks (note that the poem
                     will not have been recited)
    - other error code: failure

	\todo Implement poetry recitation.
*/
status_t
Poem::Recite(Language language, Tempo tempo)
{
	return B_ERROR;
}

