// RepliView.h

#ifndef REPLI_VIEW_H
#define REPLI_VIEW_H


#include <Bitmap.h>
#include <Dragger.h>
#include <View.h>
#include <stdio.h>
#include <TranslationUtils.h>
#include <Path.h>
#include <Entry.h>
#include <Window.h>
#include <Alert.h>

class _EXPORT RepliView;

class RepliView : public BView
{
	public:
											RepliView(BRect frame);
											RepliView(BMessage *data);
											~RepliView();
		virtual void 			Draw(BRect);
		virtual void 			MessageReceived(BMessage *msg);
		static 						BArchivable *Instantiate(BMessage *archive);
		virtual status_t 	Archive(BMessage *data, bool deep = true) const;
	  void 							RepliAboutRequested();

	private:
		BBitmap 	*fBitmap;
		bool 			fReplicated;
};

#endif