/*
	RepliApp.h
*/

#ifndef REPLI_APP_H
#define REPLI_APP_H

#ifndef _APPLICATION_H
#include <Application.h>
#endif

class RepliApp : public BApplication 
{
	public:
			RepliApp();						
};

#endif
