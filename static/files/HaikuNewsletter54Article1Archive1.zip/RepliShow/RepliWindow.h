// RepliWindow.h

#ifndef REPLI_WINDOW_H
#define REPLI_WINDOW_H

#include <Window.h>
#include "RepliView.h"


class RepliWindow : public BWindow
{
	public:
				     		 RepliWindow();
		virtual bool QuitRequested();
};

#endif