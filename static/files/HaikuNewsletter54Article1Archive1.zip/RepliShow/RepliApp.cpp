// RepliApp.cpp

#ifndef REPLI_APP_H
#include "RepliApp.h"
#endif

#ifndef REPLI_WINDOW_H
#include "RepliWindow.h"
#endif


RepliApp :: RepliApp()
					: BApplication("application/x-vnd.BeNews-RepliShow")
{
	RepliWindow *repliWindow = new RepliWindow();
	repliWindow -> Show();
}


int main()
{
	RepliApp	theApplication;	
	theApplication.Run();
	return (0);
}

