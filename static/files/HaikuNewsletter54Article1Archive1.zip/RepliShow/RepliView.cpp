// RepliView.cpp

#ifndef REPLI_VIEW_H
#include "RepliView.h"
#endif

#include <Beep.h>

RepliView :: RepliView(BRect frame) 
				   : BView(frame, "RepliShowView", B_FOLLOW_NONE, B_WILL_DRAW)
{
	fBitmap 		= NULL;
	fReplicated = false;
	
	frame.left 	= frame.right - 7;
	frame.top 	= frame.bottom - 7;
	BDragger *dragger = new BDragger(frame, this, B_FOLLOW_RIGHT | B_FOLLOW_BOTTOM);
	AddChild(dragger);	
}


RepliView :: RepliView(BMessage *archive) 
					 : BView(archive)
{
	fReplicated = true;
	fBitmap 		= new BBitmap(archive);
}


RepliView :: ~RepliView()
{
	delete fBitmap;
}

void RepliView::Draw(BRect)
{
	if(fBitmap) DrawBitmap(fBitmap, B_ORIGIN);
}


void RepliView :: MessageReceived(BMessage *msg)
{
	switch(msg->what) 
	{
		case B_SIMPLE_DATA: 
		{
			entry_ref ref;
			msg->FindRef("refs", &ref);
			BEntry entry(&ref);
			BPath path(&entry);

			delete fBitmap;
			fBitmap = BTranslationUtils::GetBitmap(path.Path());
			
			if(fBitmap != NULL) 
			{
				BRect rect = fBitmap->Bounds();
				if(!fReplicated)
					Window()->ResizeTo(rect.right, rect.bottom);
			
				ResizeTo(rect.right, rect.bottom);
				Invalidate();
			}
		}
		break;

    case B_ABOUT_REQUESTED:
    { 
      RepliAboutRequested(); 
    }
    break; 
	
		default:
			BView::MessageReceived(msg);
		break;
	}
}


BArchivable *RepliView :: Instantiate(BMessage *data)
{
	return new RepliView(data);
}



status_t RepliView :: Archive(BMessage *archive, bool deep) const
{
	BView :: Archive(archive, deep);

	archive -> AddString("add_on", "application/x-vnd.BeNews-RepliShow");
	archive -> AddString("class", "RepliShow");

	if(fBitmap) 
	{
		fBitmap->Lock();
		fBitmap->Archive(archive);
		fBitmap->Unlock();
	}			
	//archive -> PrintToStream();

	return B_OK;
}


void RepliView  :: RepliAboutRequested()
{
   BAlert *alert = new BAlert("", "RepliShow from Seth Flaxman", "OK");
   alert->Go();
}

