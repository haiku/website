#include <OS.h> 


typedef int    op;
typedef uint32 u4;

typedef void (*interrupt_handler)(void);


#define vec_size(v) (sizeof(v) / sizeof(v[0]))



// thread states

enum thread_states
	{
	BIRTH_STATE,          // just created, not yet in the queue
	READY_STATE,          // sitting in the queue (not running)
	RUNNING_STATE,        // currently executing
	DEATH_STATE           // execution is finished, marked for removal from queue
	};



// thread priorites

enum thread_priorities
	{
	IDLE_PRIO,            // the lowest of the low (pond scum of the thread world)
	LOW_PRIO,             // lowly, but honorable
	NORMAL_PRIO,          // just your average thread
	HIGH_PRIO             // must be a VIT (Very Important Thread)
	};



// thread stats

typedef struct
	{
	int create_time;      // system time when thread was created
	int ready_start_time; // system time when the last "ready" state was entered
	int ready_wait_time;  // cumulative time (in ticks) spent waiting in the "ready" state
	int num_cpu_bursts;   // cumulative count of CPU bursts that have been run
	}
thread_stat;



// the thread structure

typedef struct
	{
	char *name;           // thread name (allocated dynamically)
	int   id;             // a unique id
	
	int   state;          // thread state (BIRTH, READY, RUNNING, DEATH)
	int   priority;       // thread priority (IDLE, LOW, NORMAL, HIGH)
	int   prio_adjust;    // priority adjustment
	
	op   *code;           // base address of the thread's machine code
	int   ip;             // instruction pointer (index into the machine code)
	
	op    stack[10];      // thread local stack
	int   sp;             // stack pointer
	
	thread_stat st;       // thread stats (see above)
	}
tvm_thread;




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// globals

extern int SchedulePolicy;     // mnemonic integer value used to specify the scheduler policy
extern int TimerQuantum;       // determines the frequency of the timer interrupt

#define MAX_THREADS  20
extern tvm_thread *ThreadQ[MAX_THREADS];   // the thread queue

extern int ThreadNext;        // index of the next entry in the thread queue to be examined
extern int ThreadCount;       // total number of threads in the thread queue
extern int NextThreadID;      // unique id assigned to each new thread





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// machine stuff


// the interrupts that can be generated
// (ok, some of these are just flights of fancy...)

enum interrupts
	{
	intNone = -1,
	
	intTimer,
	intKeyboard,
	intFloppy,
	intSerialPort,
	
	intFatalError,
	intInvalidOpcode,
	intDivideByZero,
	intStackOverflow,
	intStackUnderflow
	};



// the machine language opcodes
// note: these values are all negative (the interpreter relies on this)

enum opcodes
	{
	opHalt = -9999,
	opNop,
	opInc,
	opDec,
	opEmit,
	opLoop,
	opEndLoop
	};



interrupt_handler install_interrupt_handler(int, interrupt_handler);

void  boot_machine             (void);
void  disable_interrupts       (void);
void  dump_thread              (tvm_thread *);
void  enable_interrupts        (void);
void  init_scheduler           (void);
u4    machine_clock            (void);
void  machine_loop             (void);
void  machine_switch_to_thread (tvm_thread *);
void  move_to_ready_state      (tvm_thread *);
void  panic                    (char *);
const char *priority_string    (int);
void  remove_thread            (tvm_thread *);
void  schedule                 (void);
void  start_kernel             (void);
