// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
//
//  tvm.c
//
//  implements a small, demonstration scheduler for a pseudo machine
//  called 'tvm' (tiny virtual machine)
//
//      Copyright (c) Daniel Reinhold
//      written Nov, Dec 2002
//
// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "tvm.h"


static int  get_policy (char *);
static void read_args  (int, char **);
static void run_tvm    (void);
static void usage      (void);



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// globals

int SchedulePolicy;       // mnemonic integer value used to specify the scheduler policy
int TimerQuantum = 3;     // determines the frequency of the timer interrupt

tvm_thread *ThreadQ[MAX_THREADS] = {NULL};   // the thread queue

int ThreadNext = 0;       // index of the next entry in the thread queue to be examined
int ThreadCount = 0;      // total number of threads in the thread queue
int NextThreadID = 0;     // unique id assigned to each new thread




void
usage (void)
	{
	printf("usage: tvm policy_num [timer_quantum]\n"
	       "\n"
	       "One of the following values for policy_num must be used:\n"
	       "    0: Round Robin\n"
	       "    1: Priority Strict\n"
	       "    2: Priority w/Aging\n"
	       "    3: Priority w/Leveling\n"
	       "    4: Priority w/Random Promotion\n"
	       "\n"
	       "If specified, the timer_quantum must be >= 1 (the default value is 3).\n"
	       );
	exit(0);
	}


int
main (int argc, char *argv[])
	{	
	read_args(argc, argv);
	run_tvm();
	
	return 0;
	}


void
run_tvm (void)
	{
	// set up and run the 'tiny virtual machine'
	
	boot_machine();  // well, sort of
	start_kernel();  // creates a few threads
	
	// now let the machine run...
	machine_loop();
		// this just spins forever, executing the current thread's
		// machine code and responding to interrupts as they are detected
		// (currently, only the timer interrupt is caught which, in turn,
		//  calls the scheduler)
		//
		// since the idle thread (at least) will always be running,
		// users will have to kill this program themselves (with Cmd-C)
	}


void
read_args (int argc, char *argv[])
	{
	char *policy_arg;
	char *timer_arg;
	
	if (argc < 2 || argc > 3)
		usage();
	
	// set the scheduling policy
	policy_arg = argv[1];
	if (!isdigit(policy_arg[0]))
		usage();
	
	SchedulePolicy = get_policy(policy_arg);
	
	
	// reset the timer quantum (if specified)
	if (argc == 3)
		{
		timer_arg = argv[2];
		if (!isdigit(timer_arg[0]))
			usage();
		
		TimerQuantum = atoi(timer_arg);
		if (TimerQuantum < 1)
			TimerQuantum = 1;
		}
	}


int
get_policy (char *policy_arg)
	{
	switch (atoi(policy_arg))
		{
		case 0:	return 'robn';
		case 1:	return 'prio';
		case 2:	return 'aged';
		case 3:	return 'levl';
		case 4:	return 'rand';
		}
	
	usage();
	return 0;
	}

