// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
//
//  tvm_scheduler.c
//
//  the scheduler routines for 'tvm' (tiny virtual machine)
//
//      Copyright (c) Daniel Reinhold
//      written Nov, Dec 2002
//
// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tvm.h"


static tvm_thread *gnt_round_robin         (void);
static tvm_thread *gnt_priority_strict     (void);
static tvm_thread *gnt_priority_aging      (void);
static tvm_thread *gnt_priority_leveling   (void);
static tvm_thread *gnt_priority_rand_promo (void);

static void print_usage_stats       (void);
static int  random_positive_integer (void);
static void save_usage_stats        (tvm_thread *);
static void switch_to_thread        (tvm_thread *);
static void unschedule              (tvm_thread *);





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// shared

static char *PolicyName = "";      // for display in the final usage stats

static int   DecayThreshold = 10;  // used by the aging/leveling policies to determine
                                   // when a neglected thread needs a priority boost
                                   // (measured in machine clock ticks)


static tvm_thread* (*get_next_thread)(void);
                                   // the hook function to a thread selector routine
                                   // (invoked by schedule() itself)




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// scheduling


void
init_scheduler (void)
	{
	// set the 'get_next_thread()' hook based
	// on the global schedule policy
	
	switch (SchedulePolicy)
		{
		case 'robn':
			get_next_thread = gnt_round_robin;
			PolicyName = "Round Robin";
			break;
		
		case 'prio':
			get_next_thread = gnt_priority_strict;
			PolicyName = "Priority Strict";
			break;
		
		case 'aged':
			get_next_thread = gnt_priority_aging;
			PolicyName = "Priority w/Aging";
			break;
		
		case 'levl':
			get_next_thread = gnt_priority_leveling;
			PolicyName = "Priority w/Leveling";
			break;
		
		case 'rand':
			get_next_thread = gnt_priority_rand_promo;
			PolicyName = "Priority w/Random Promotion";
			break;
		}
	}


void
schedule (void)
	{
	// ~~ the thread scheduler ~~
	//
	// How To Schedule Threads in 3 Easy Steps:
	//   1) unschedule the current thread
	//   2) pick the next thread to schedule
	//   3) switch to the next thread
	//
	// hey, who knew scheduling could be so easy? :)
	
	static tvm_thread *cur = NULL;  // the currently scheduled thread
	tvm_thread *next;               // the next thread to be scheduled
	
	unschedule(cur);
	
	next = get_next_thread();
	if (next == NULL)
		panic("no running threads!!!");

	switch_to_thread(next);
	cur = next;
	}


static void
unschedule (tvm_thread *t)
	{
	// moves the currently scheduled thread into its next state.
	// along the way, statistics are gathered and any additional
	// actions (such a removing a finished thread) are performed
	
	if (!t)
		return;
	
	switch (t->state)
		{
		case RUNNING_STATE:
			// the thread's quantum has expired
			
			move_to_ready_state(t);  // back to READY_STATE
			break;
		
		case DEATH_STATE:
			// the thread has finished execution
			
			save_usage_stats(t);
			
			printf("\nremoving thread '%s'\n", t->name);
			remove_thread(t);
			if (ThreadCount == 1)
				{
				print_usage_stats();
				printf("only the idle thread is running now...\n");
				}
			break;
		}
	}


void
move_to_ready_state (tvm_thread *t)
	{
	t->state = READY_STATE;
	t->st.ready_start_time = machine_clock();
	}


static void
switch_to_thread (tvm_thread *t)
	{
	//
	
	// mark how long it's been sitting "ready" in the thread queue
	int wait = machine_clock() - t->st.ready_start_time;
	t->st.ready_wait_time += wait;
	
	// mark the thread for execution by the machine loop
	t->state = RUNNING_STATE;
	machine_switch_to_thread(t);
	
	++t->st.num_cpu_bursts;  // it will soon get another burst
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// gnt ('get_next_thread') selector routines


//
// Policy: Round Robin
//

static tvm_thread *
gnt_round_robin (void)
	{
	//
	
	int i;
	int slot = ThreadNext;
	
	for (i = 0; i < MAX_THREADS; ++i)
		{
		tvm_thread *t = ThreadQ[slot++];
		if (slot >= MAX_THREADS)
			slot = 0;
		
		if (t && t->state == READY_STATE)
			{
			ThreadNext = slot;
			return t;
			}
		}
	
	return NULL;
	}


//
// Policy: Priority Strict:
//

static tvm_thread *
gnt_priority_strict (void)
	{
	//
	
	int priority;
	
	for (priority = HIGH_PRIO; priority >= 0; --priority)
		{
		int i;
		int slot = ThreadNext;
		
		for (i = 0; i < MAX_THREADS; ++i)
			{
			tvm_thread *t = ThreadQ[slot++];
			if (slot >= MAX_THREADS)
				slot = 0;
			
			if (t && t->state == READY_STATE)			
				if (t->priority == priority)
					{
					ThreadNext = slot;
					return t;
					}
			}
		}
	
	return NULL;
	}


//
// Policy: Priority w/Aging:
//

static tvm_thread *
gnt_priority_aging (void)
	{
	//
	
	int priority;
	
	for (priority = HIGH_PRIO; priority >= 0; --priority)
		{
		int i;
		int slot = ThreadNext;
		
		for (i = 0; i < MAX_THREADS; ++i)
			{
			tvm_thread *t = ThreadQ[slot++];
			if (slot >= MAX_THREADS)
				slot = 0;
			
			if (t && t->state == READY_STATE)
				{
				int prio = t->priority + t->prio_adjust;
				if (prio == priority)
					{
					t->prio_adjust = 0;  // revert to original priority
					ThreadNext = slot;
					return t;
					}
				else if (t->priority != IDLE_PRIO)
					{
					int wait = machine_clock() - t->st.ready_start_time;
					if (wait >= DecayThreshold && prio < HIGH_PRIO)
						// decaying thread gets a priority boost
						++t->prio_adjust;
					}
				}
			}
		}
	
	return NULL;
	}


//
// Policy: Priority w/Leveling:
//

static tvm_thread *
gnt_priority_leveling (void)
	{
	//
	
	int priority;
	
	for (priority = HIGH_PRIO; priority >= 0; --priority)
		{
		int i;
		int slot = ThreadNext;
		
		for (i = 0; i < MAX_THREADS; ++i)
			{
			tvm_thread *t = ThreadQ[slot++];
			if (slot >= MAX_THREADS)
				slot = 0;
			
			if (t && t->state == READY_STATE)
				{
				int prio = t->priority + t->prio_adjust;
				if (prio == priority)
					{
					if (t->prio_adjust != 0)
						// restore original priority
						t->prio_adjust = 0;
					else if (prio > LOW_PRIO)
						// lower the priority for one go-around
						--t->prio_adjust;
					
					ThreadNext = slot;
					return t;
					}
				else if (t->priority != IDLE_PRIO)
					{
					int wait = machine_clock() - t->st.ready_start_time;
					if (wait >= DecayThreshold && prio < HIGH_PRIO)
						// decaying thread gets a priority boost
						++t->prio_adjust;
					}
				}
			}
		}
	
	return NULL;
	}


//
// Policy: Priority w/Random Promotion:
//

static tvm_thread *
gnt_priority_rand_promo (void)
	{
	//
	
	static u4 count = 0;
	
	int priority;
	int mod = (ThreadCount > 5) ? ThreadCount - 1 : 5;
	
	for (priority = HIGH_PRIO; priority >= 0; --priority)
		{
		int i;
		int slot = ThreadNext;
		
		for (i = 0; i < MAX_THREADS; ++i)
			{
			tvm_thread *t = ThreadQ[slot++];
			if (slot >= MAX_THREADS)
				slot = 0;
			
			if (t && t->state == READY_STATE)			
				{				
				int r = random_positive_integer() % mod;
				if ((t->priority == priority) || ((++count % mod) == r))
					{
					ThreadNext = slot;
					return t;
					}
				}
			}
		}
	
	return NULL;
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// usage stats


typedef struct
	{
	char *name;
	int   total;
	int   wait;
	float perc;
	int   bursts;
	}
usage_stat;

usage_stat *UsageTable[10] = {NULL};
int         TableCount = 0;



static void
save_usage_stats (tvm_thread *t)
	{
	// called when the thread has finished its run -- at that point,
	// the total run/usage stats can be computed and stored in the table
	
	usage_stat *u;
	
	if (TableCount == vec_size(UsageTable))
		// out of space in the table
		return;
		
	u = (usage_stat *) malloc(sizeof(usage_stat));
	if (u)
		{
		u->name   = strdup(t->name);
		u->total  = machine_clock() - t->st.create_time;
		u->wait   = t->st.ready_wait_time;
		u->perc   = (u->wait * 100.0) / u->total;
		u->bursts = t->st.num_cpu_bursts;
		
		UsageTable[TableCount++] = u;
		}
	else
		panic("can't allocate usage stats: out of memory");
	}


static void
print_usage_stats ()
	{
	// a quick summary of the usage stats for all finished threads
	
	int i;
	
	printf("\n              *** Thread Usage Stats ***\n");
	printf("(Policy: %s, TimerQuantum = %d)\n", PolicyName, TimerQuantum);
	printf("-------------------------------------------------------\n");	
	printf("Thread               Total  Wait   Ready/Wait    CPU\n");
	printf("Name                 Time   Time   Percentage    Bursts\n");
	printf("-------------------------------------------------------\n");
	
	for (i = 0; i < TableCount; ++i)
		{
		usage_stat *u = UsageTable[i];
		
		printf("%-20s %-6d %-5d %5.1f%% %10d\n",
		       u->name,
		       u->total,
		       u->wait,
		       u->perc,
		       u->bursts);
		
		free(u->name);
		free(u);
		}
	printf("\n");
	}



static int
random_positive_integer (void)
	{
	// works better (for me) than using rand()
	
	#define INT_BITS   (8 * sizeof(int))
	#define SIGN_MASK ~(1 << (INT_BITS-1))
	
	static int n = 0;
	
	// use clock time for seed value
	if (n == 0)
		n = real_time_clock();
	
	// hash a new value
	n = ((n << 1) ^ (n >> 23)) & SIGN_MASK;
	
	return n;
	}
