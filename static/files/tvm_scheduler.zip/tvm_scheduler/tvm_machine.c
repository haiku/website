// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
//
//  tvm_machine.c
//
//  the machine definition for 'tvm' (tiny virtual machine)
//
//      Copyright (c) Daniel Reinhold
//      written Nov, Dec 2002
//
// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

#include <stdio.h>

#include "tvm.h"


static void do_nothing_handler (void);
static void emit               (char);
static void gen_interrupt      (int);
static int  get_next_interrupt (void);
static op   fetch_next_op      (void);
static void interpret          (op);
static void machine_tick       (void);
static int  skip_loop          (op *);
static op   pop                (void);
static void push               (op);





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// shared

// Interrupt Vector Table (array of interrupt handlers)
#define MAX_INTERRUPTS  10
static interrupt_handler IVT[MAX_INTERRUPTS];


// Interrupt Event Queue (controls processing of interrupts)
#define MAX_INTQ_DEPTH  10
static int  InterruptEventQ[MAX_INTQ_DEPTH] = {0};
static int  IEQ_Head;
static int  IEQ_Tail;
static int  IEQ_Count;


// a few other controls
static bool InterruptsEnabled = true;
static u4   AbsoluteTicks = 0;


// this variable determines the current execution environment
// (tvm threads contain their own code and ip, and a stack)
static tvm_thread *CurrentThread;





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// interrupts

static void
do_nothing_handler (void)
	{
	// see... it does nothing!
	}


static void
fatal_error_handler (void)
	{
	// it's hopeless...
	printf("the machine has just crashed...have a nice day!\n");
	exit(1);
	}


interrupt_handler
install_interrupt_handler (int index, interrupt_handler new_handler)
	{
	//
	
	if (index >= 0 && index < MAX_INTERRUPTS)
		{
		interrupt_handler old_handler = IVT[index];
		IVT[index] = new_handler;
		
		return old_handler;
		}
	
	return NULL;
	}


void
enable_interrupts (void)
	{
	InterruptsEnabled = true;
	}


void
disable_interrupts (void)
	{
	InterruptsEnabled = false;
	}


static void
gen_interrupt (int inum)
	{
	// generate an interrupt
	// (by pushing the interrupt number onto the interrupt event queue)

	if (IEQ_Count == MAX_INTQ_DEPTH)
		// queue is full, interrupt will be lost...
		;
	else
		{
		int rear = IEQ_Tail + 1;
		if (rear >= MAX_INTQ_DEPTH)
			rear = 0;
		
		InterruptEventQ[rear] = inum;
		IEQ_Tail = rear;
		
		++IEQ_Count;
		}
	}


static int
get_next_interrupt (void)
	{
	// grab the next pending interrupt (from the interrupt event queue)
	
	if (IEQ_Count == 0)
		// queue is empty
		return intNone;
	else
		{
		int front = IEQ_Head;
		int inum  = InterruptEventQ[front];
		
		if (++front >= MAX_INTQ_DEPTH)
			front = 0;
		
		IEQ_Head = front;
		--IEQ_Count;
		
		return inum;
		}
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// running the machine


void
boot_machine (void)
	{
	// setup the machine data structures
	// note: no 'Power On Self Test' is required! :)
	
	int i;
	
	// init the interrupt vector table
	for (i = 0; i < MAX_INTERRUPTS; ++i)
		IVT[i] = do_nothing_handler;
	IVT[intFatalError] = fatal_error_handler;
	
	// init the interrupt event queue
	IEQ_Tail = -1;
	IEQ_Head = IEQ_Count = 0;
	}


u4
machine_clock (void)
	{
	return AbsoluteTicks;
	}


static void
machine_tick (void)
	{
	static u4 current_ticks = 0;
	
	++AbsoluteTicks;
	
	if (++current_ticks == TimerQuantum)
		{
		current_ticks = 0;
		gen_interrupt(intTimer);
		}
	}


void
machine_loop (void)
	{
	// loop forever, interpreting the current machine code ops
	// and fetching/processing any interrupts detected...
	
	for (;;)
		{
		int i = get_next_interrupt();
		machine_tick();
		
		if (i >= 0 && i < MAX_INTERRUPTS)
			// there is a pending interrupt...
			if (InterruptsEnabled)
				{
				//emit('!');
				IVT[i]();  // run its designated handler
				machine_tick();
				}
		
		// execute the current stack op
		interpret(fetch_next_op());
		machine_tick();
		}
	}


void
machine_switch_to_thread (tvm_thread *t)
	{
	// the next iteration thru the machine loop will begin
	// interpreting this thread's machine code
	
	CurrentThread = t;
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// machine language


static op
fetch_next_op (void)
	{
	op next = opNop;
	
	if (CurrentThread)
		{
		next = CurrentThread->code[CurrentThread->ip];
		if (next != opHalt)
			++CurrentThread->ip;
		}
	
	return next;
	}



static void
interpret (op val)
	{
	//
	
	tvm_thread *t = CurrentThread;
	
	if (!t)
		{
		// if there's no running thread, we're totally screwed
		gen_interrupt(intFatalError);
		return;
		}
	
	if (val >= 0)
		{
		// operand
		push(val);
		}
	else
		{
		// opcode
		int loop_count;

		switch (val)
			{
			case opNop:
				// no operation
				break;
			
			case opInc:
				// increment the top of the stack
				push(pop() + 1);
				break;
			
			case opDec:
				// decrement the top of the stack
				push(pop() - 1);
				break;
			
			case opEmit:
				// print the top stack element as a char
				emit((char)pop());
				break;
			
			case opLoop:
				// marks the beginning of a loop
				loop_count = pop();
				if (loop_count-- > 0)
					{
					int loop_ip = t->ip - 1;
					
					push(loop_ip);
					push(loop_count);
					}
				else
					// the loop has finished...
					t->ip += skip_loop(&t->code[t->ip]);
				break;
			
			case opEndLoop:
				// the end of a loop -> jump back to the beginning
				loop_count = pop();
				t->ip = pop();
				push(loop_count);
				break;
			
			case opHalt:
				// the current thread has finished its execution:
				//   set the state to DEATH and indirectly invoke the scheduler
				//   (via a timer interrupt) so that another thread can be run
				t->state = DEATH_STATE;
				gen_interrupt(intTimer);
				break;
			
			default:
				// hmmm...
				gen_interrupt(intInvalidOpcode);
				break;
			}
		}
	}


static void
push (op elem)
	{
	tvm_thread *t = CurrentThread;
	
	if (t->sp < vec_size(t->stack))
		t->stack[t->sp++] = elem;
	else
		gen_interrupt(intStackOverflow);
	}


static op
pop (void)
	{
	op  elem = 0;
	tvm_thread *t = CurrentThread;

	if (t->sp > 0)
		elem = t->stack[--t->sp];
	else
		gen_interrupt(intStackUnderflow);
	
	return elem;
	}


static int
skip_loop (op *code)
	{
	// returns the number of op elems to skip over
	// in order to reach the end of the current loop
	
	op  c;
	int skip  = 0;
	int depth = 1;
	
	// find the matching end-of-loop opcode
	while (depth && (c = *code++) != opHalt)
		{
		++skip;
		if (c == opLoop)    ++depth;
		if (c == opEndLoop) --depth;
		}
	
	if (depth > 0)
		// loop/endloop opcodes are not balanced
		gen_interrupt(intFatalError);
	
	return skip;
	}


static void
emit (char c)
	{
	putchar(c);
	fflush(stdout);
	}
