// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
//
//  tvm_kernel.c
//
//  the kernel/thread routines for 'tvm' (tiny virtual machine)
//
//      Copyright (c) Daniel Reinhold
//      written Nov, Dec 2002
//
// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tvm.h"


tvm_thread * create_thread   (op *, char *, int);
void         dump_threads    (void);
void         init_threads    (void);
void         insert_thread   (tvm_thread *);
const char * state_string    (int);
void         timer_interrupt (void);





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// kernel routines


void
panic (char *msg)
	{
	// for when the sky is falling...
	printf("\nkernel panic: %s\n", msg);
	exit(1);
	}


void
start_kernel (void)
	{	
	// hook into the machine loop
	install_interrupt_handler(intTimer, timer_interrupt);
	
	// make a few threads to play with
	init_threads();
	
	// set up the scheduler and then prime the pump
	// (i.e. get the first thread running)
	init_scheduler();
	schedule();
	}


void
init_threads (void)
	{
	// pre-set a few machine code programs
	// (note: these are declared static, because the thread's code field
	//        will point to these directly -- no copying)
	static op idle[]  = { 1, opLoop, opInc,       opEndLoop, opHalt};
	static op prog1[] = {11, opLoop, '1', opEmit, opEndLoop, opHalt}; 
	static op prog2[] = {23, opLoop, '2', opEmit, opEndLoop, opHalt}; 
	static op prog3[] = {18, opLoop, '3', opEmit, opEndLoop, opHalt};

	// create corresponding threads and put into the thread queue
	insert_thread(create_thread(idle, "idle thread", IDLE_PRIO));
	insert_thread(create_thread(prog1, "thread 1",   LOW_PRIO));
	insert_thread(create_thread(prog2, "thread 2",   HIGH_PRIO));
	insert_thread(create_thread(prog3, "thread 3",   NORMAL_PRIO));
	
	// something to look at
	dump_threads();
	}


void
timer_interrupt (void)
	{
	// at every timer interrupt, we schedule another thread
	disable_interrupts();
	schedule();
	enable_interrupts();
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// thread management


tvm_thread *
create_thread (op *code, char *name, int priority)
	{
	// create a new thread

	tvm_thread *t = (tvm_thread *) malloc(sizeof(tvm_thread));
	if (t)
		{
		t->name = strdup(name);
		t->id = NextThreadID++;
		t->state = BIRTH_STATE;
		t->priority = priority;
		t->prio_adjust = 0;
		t->code = code;
		t->ip = 0;
		t->sp = 0;
		
		t->st.create_time = machine_clock();
		t->st.ready_start_time = 0;
		t->st.ready_wait_time = 0;
		t->st.num_cpu_bursts = 0;
		}
	else
		panic("can't create thread: out of memory");
	
	return t;
	}


void
insert_thread (tvm_thread *t)
	{
	// insert the thread into the thread queue
	
	if (ThreadCount == MAX_THREADS)
		panic("out of thread slots");
	
	move_to_ready_state(t);
	ThreadQ[ThreadNext] = t;
	
	if (++ThreadNext >= MAX_THREADS)
		ThreadNext = 0;
	
	++ThreadCount;
	}


void
remove_thread (tvm_thread *rm)
	{
	int i;
	
	for (i = 0; i < MAX_THREADS; ++i)
		{
		tvm_thread *t = ThreadQ[i];
		if (t && (t->id == rm->id))
			{
			free(t->name);
			free(t);
			
			ThreadQ[i] = NULL;
			--ThreadCount;
			break;
			}
		}
	}


const char *
state_string (int state)
	{
	switch (state)
		{
		case BIRTH_STATE:   return "BIRTH";
		case READY_STATE:   return "READY";
		case RUNNING_STATE: return "RUNNING";
		case DEATH_STATE:   return "DEATH";
		}
	
	return "???";
	}


const char *
priority_string (int priority)
	{
	switch (priority)
		{
		case IDLE_PRIO:   return "IDLE";
		case LOW_PRIO:    return "LOW";
		case NORMAL_PRIO: return "NORMAL";
		case HIGH_PRIO:   return "HIGH";
		}
	
	return "???";
	}


void
dump_thread (tvm_thread *t)
	{
	if (!t)
		return;
	
	printf("{'%-20s', %d, %-7s, %-6s, %+2d, %p, %d, %p, %d {%d, %d, %d, %d}}\n",
	       t->name,
	       t->id,
	       state_string(t->state),
	       priority_string(t->priority + t->prio_adjust),
	       t->prio_adjust,
	       t->code,
	       t->ip,
	       t->stack,
	       t->sp,
	       
	       t->st.create_time,
	       t->st.ready_start_time,
	       t->st.ready_wait_time,
	       t->st.num_cpu_bursts
	       );
	}


void
dump_threads (void)
	{
	int i;
	
	printf("\nkernel threads:\n");
	
	for (i = 0; i < MAX_THREADS; ++i)
		dump_thread(ThreadQ[i]);

	printf("\n");
	}

