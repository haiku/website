
#ifndef ECHO_APP_H
#define ECHO_APP_H

#include <Application.h>

class EchoApp : public BApplication
{
public:

	EchoApp();

private:

	typedef BApplication super;
};

#endif // ECHO_APP_H
