
#include <Application.h>
#include <AppFileInfo.h>
#include <Bitmap.h>
#include <Debug.h>
#include <Message.h>
#include <MidiEndpoint.h>
#include <Mime.h>
#include <Roster.h>

#include "MidiIcons.h"

static const char*  LARGE_ICON_NAME = "be:large_icon";
static const char*   MINI_ICON_NAME = "be:mini_icon";
static const uint32 LARGE_ICON_TYPE = 'ICON';
static const uint32  MINI_ICON_TYPE = 'MICN';
static const float  LARGE_ICON_SIZE = 32;
static const float   MINI_ICON_SIZE = 16;

//------------------------------------------------------------------------------

static void add_icon(BMessage* msg, const BBitmap* icon, icon_size which)
{
	ASSERT(msg  != NULL);
	ASSERT(icon != NULL);

	uint32 iconType;
	const char* iconName;

	if (which == B_LARGE_ICON) 
	{
		iconType = LARGE_ICON_TYPE;
		iconName = LARGE_ICON_NAME;
	} 
	else
	{
		iconType = MINI_ICON_TYPE;
		iconName = MINI_ICON_NAME;
	} 

	if (!msg->HasData(iconName, iconType)) 
	{
		msg->AddData(
			iconName, iconType, icon->Bits(), icon->BitsLength());
	} 
	else 
	{
		msg->ReplaceData(
			iconName, iconType, icon->Bits(), icon->BitsLength());
	}
}

//------------------------------------------------------------------------------

static BBitmap* load_icon(const BMessage* msg, icon_size which)
{
	ASSERT(msg != NULL);

	float iconSize;
	uint32 iconType;
	const char* iconName;

	if (which == B_LARGE_ICON) 
	{
		iconSize = LARGE_ICON_SIZE;
		iconType = LARGE_ICON_TYPE;
		iconName = LARGE_ICON_NAME;
	} 
	else
	{
		iconSize = MINI_ICON_SIZE;
		iconType = MINI_ICON_TYPE;
		iconName = MINI_ICON_NAME;
	} 

	const void* data;
	ssize_t size;

	if (msg->FindData(iconName, iconType, &data, &size) != B_OK)
	{
		return NULL;
	}

	BRect rect(0, 0, iconSize - 1, iconSize - 1);
	BBitmap* bitmap = new BBitmap(rect, B_CMAP8);
	memcpy(bitmap->Bits(), data, size); 

	return bitmap;
}

//------------------------------------------------------------------------------

void set_endpoint_icons(
	BMidiEndpoint* endpoint, const BBitmap* largeIcon, const BBitmap* miniIcon)
{
	ASSERT(endpoint != NULL);

	BMessage props;
	if (endpoint->GetProperties(&props) == B_OK)
	{
		if (largeIcon != NULL)
		{
			add_icon(&props, largeIcon, B_LARGE_ICON);
		}

		if (miniIcon != NULL)
		{
			add_icon(&props, miniIcon,  B_MINI_ICON);
		}

		endpoint->SetProperties(&props);
	} 
}

//------------------------------------------------------------------------------

void get_endpoint_icons(
	const BMidiEndpoint* endpoint, BBitmap** largeIcon, BBitmap** miniIcon)
{
	ASSERT(endpoint != NULL);

	BMessage props;
	if (endpoint->GetProperties(&props) == B_OK) 
	{
		if (largeIcon != NULL)
		{
			*largeIcon = load_icon(&props, B_LARGE_ICON);
		}

		if (miniIcon != NULL)
		{
			*miniIcon  = load_icon(&props, B_MINI_ICON);
		}
	}
}

//------------------------------------------------------------------------------

void get_app_icons(BBitmap** largeIcon, BBitmap** miniIcon)
{
	ASSERT(largeIcon != NULL);
	ASSERT(miniIcon  != NULL);

	*largeIcon = new BBitmap(BRect(0, 0, 31, 31), B_CMAP8);
	*miniIcon  = new BBitmap(BRect(0, 0, 15, 15), B_CMAP8);

	app_info ai;
	if (be_app->GetAppInfo(&ai) != B_OK) { return; }

	BFile file(&(ai.ref), B_READ_ONLY);
	if (file.InitCheck() != B_OK) { return; }

	BAppFileInfo afi(&file);
	if (afi.InitCheck() != B_OK) { return; }

	afi.GetIcon(*largeIcon, B_LARGE_ICON);
	afi.GetIcon(*miniIcon,  B_MINI_ICON);
}

//------------------------------------------------------------------------------
