/**
 * @file MidiIcons.h
 *
 * Utility functions to change the icons of Midi Kit endpoints.
 */

#ifndef MIDI_ICONS_H
#define MIDI_ICONS_H

/**
 * Adds a large and/or mini icon to the properties of the specified endpoint.
 *
 * @param endpoint The BMidiEndpoint to assign the icons to. This may not
 *        be NULL.
 *
 * @param largeIcon A 32x32 BBitmap for the large icon. The BBitmap object
 *        itself is not changed; the data is simply copied into the endpoint
 *        properties. If largeIcon is NULL, no large icon will be added to
 *        the properties.
 *
 * @param miniIcon A 16x16 BBitmap for the mini icon. The BBitmap object
 *        itself is not changed; the data is simply copied into the endpoint
 *        properties. If miniIcon is NULL, no mini icon will be added to
 *        the properties.
 */
void set_endpoint_icons(
	BMidiEndpoint* endpoint, const BBitmap* largeIcon, const BBitmap* miniIcon);

/**
 * Retrieves the large and/or mini icons from the properties of the specified
 * endpoint.
 *
 * @param endpoint The BMidiEndpoint to retrieve the icons from. This may not
 *        be NULL.
 *
 * @param largeIcon If this is not NULL, the endpoint's large icon will be
 *        copied into a new BBitmap object, and its pointer will be stored
 *        in *largeIcon. You are responsible for deleting the BBitmap. If the
 *        endpoint has no large icon, *largeIcon will be set to NULL.
 *
 * @param miniIcon If this is not NULL, the endpoint's mini icon will be
 *        copied into a new BBitmap object and its pointer will be stored in
 *        *miniIcon. You are responsible for deleting the BBitmap. If the
 *        endpoint has no mini icon, *miniIcon will be set to NULL.
 */
void get_endpoint_icons(
	const BMidiEndpoint* endpoint, BBitmap** largeIcon, BBitmap** miniIcon);

/**
 * Retrieves the large and mini icons from the application's resources.
 *
 * @param largeIcon The application's large icon will be copied into a new
 *        BBitmap object, and its pointer will be stored in *largeIcon. If
 *        the large icon cannot be retrieved, you still get back a valid
 *        BBitmap object, but it will be all white. You are responsible for
 *        deleting the BBitmap. This may not be NULL.
 *
 * @param miniIcon The application's mini icon will be copied into a new
 *        BBitmap object, and its pointer will be stored in *miniIcon. If
 *        the mini icon cannot be retrieved, you still get back a valid
 *        BBitmap object, but it will be all white. You are responsible for
 *        deleting the BBitmap. This may not be NULL.
 */
void get_app_icons(BBitmap** largeIcon, BBitmap** miniIcon);

#endif // MIDI_ICONS_H
