
#ifndef SIMPLE_MIDI_FILTER_H
#define SIMPLE_MIDI_FILTER_H

#include <MidiProducer.h>
#include <MidiConsumer.h>

/**
 * @brief Base class for writing your own MIDI filters.
 *
 * A MIDI filter is a class that contains a consumer and a producer endpoint.
 * It takes the incoming events from the consumer, performs some operation on
 * them, and sends the results out again using the producer.
 *
 * SimpleMidiFilter makes it easy to create your own MIDI filters. You only
 * have to subclass SimpleMidiFilter and override NoteOff(), NoteOn(), or any
 * hook functions you need. By default these hooks send the event unchanged to
 * the producer, but you can make them do anything you want.
 */
class SimpleMidiFilter
{
public:

	virtual ~SimpleMidiFilter();

	status_t Register();
	status_t Unregister();

	BMidiLocalConsumer* Input() const;
	BMidiLocalProducer* Output() const;

protected:

	friend class SimpleMidiFilterConsumer;

	SimpleMidiFilter(const char* name = NULL);

	virtual void NoteOff(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual	void KeyPressure(
		uchar channel, uchar note, uchar pressure, bigtime_t time);

	virtual	void ControlChange(
		uchar channel, uchar controlNumber, uchar controlValue, 
		bigtime_t time);

	virtual	void ProgramChange(
		uchar channel, uchar programNumber, bigtime_t time);

	virtual	void ChannelPressure(
		uchar channel, uchar pressure, bigtime_t time);

	virtual	void PitchBend(
		uchar channel, uchar lsb, uchar msb, bigtime_t time);

	virtual	void SystemExclusive(
		void* data, size_t dataLength, bigtime_t time);

	virtual	void SystemCommon(
		uchar status, uchar data1, uchar data2, bigtime_t time);

	virtual	void SystemRealTime(
		uchar status, bigtime_t time);

	virtual	void TempoChange(
		int32 beatsPerMinute, bigtime_t time);

	void SprayData(
		void* data, size_t length, bool atomic = false, 
		bigtime_t time = 0) const;

	void SprayNoteOff(
		uchar channel, uchar note, uchar velocity,
		bigtime_t time = 0) const;

	void SprayNoteOn(
		uchar channel, uchar note, uchar velocity, 
		bigtime_t time = 0) const;

	void SprayKeyPressure(
		uchar channel, uchar note, uchar pressure, 
		bigtime_t time = 0) const;

	void SprayControlChange(
		uchar channel, uchar controlNumber, uchar 
		controlValue, bigtime_t time = 0) const;

	void SprayProgramChange(
		uchar channel, uchar programNumber, bigtime_t time = 0) const;

	void SprayChannelPressure(
		uchar channel, uchar pressure, bigtime_t time = 0) const;

	void SprayPitchBend(
		uchar channel, uchar lsb, uchar msb, bigtime_t time = 0) const;

	void SpraySystemExclusive(
		void* data, size_t dataLength, bigtime_t time = 0) const;

	void SpraySystemCommon(
		uchar status, uchar data1, uchar data2, bigtime_t time = 0) const;

	void SpraySystemRealTime(uchar status, bigtime_t time = 0) const; 

	void SprayTempoChange(
		int32 beatsPerMinute, bigtime_t time = 0) const;	

private:

	BMidiLocalConsumer* input;
	BMidiLocalProducer* output;
};

#endif // SIMPLE_MIDI_FILTER_H
