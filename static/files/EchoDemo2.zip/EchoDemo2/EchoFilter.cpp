
#include "EchoFilter.h"

//------------------------------------------------------------------------------

EchoFilter::EchoFilter(const char* name)
	: SimpleMidiFilter(name)
{
	notes = 2;
	delay = 200;
}

//------------------------------------------------------------------------------

void EchoFilter::NoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	for (int32 t = 0; t < notes + 1; ++t)
	{
		SprayNoteOn(channel, note, velocity, time);
		time += delay * 1000;
		velocity /= 2;
	}
}

//------------------------------------------------------------------------------

void EchoFilter::NoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	for (int32 t = 0; t < notes + 1; ++t)
	{
		SprayNoteOff(channel, note, velocity, time);
		time += delay * 1000;
		velocity /= 2;
	}
}

//------------------------------------------------------------------------------
