
#include "SimpleMidiFilter.h"

//------------------------------------------------------------------------------

class SimpleMidiFilterConsumer : public BMidiLocalConsumer
{
public:

	SimpleMidiFilterConsumer(
		SimpleMidiFilter* filter, const char* name);

	virtual	void NoteOff(uchar, uchar, uchar, bigtime_t);
	virtual	void NoteOn(uchar, uchar, uchar, bigtime_t);
	virtual	void KeyPressure(uchar, uchar, uchar, bigtime_t);
	virtual	void ControlChange(uchar, uchar, uchar, bigtime_t);
	virtual	void ProgramChange(uchar, uchar, bigtime_t);
	virtual	void ChannelPressure(uchar, uchar, bigtime_t);
	virtual	void PitchBend(uchar, uchar, uchar, bigtime_t);
	virtual	void SystemExclusive(void*, size_t, bigtime_t);
	virtual	void SystemCommon(uchar, uchar, uchar, bigtime_t);
	virtual	void SystemRealTime(uchar, bigtime_t);
	virtual	void TempoChange(int32, bigtime_t);

private:

	SimpleMidiFilter* filter;
};

//------------------------------------------------------------------------------

SimpleMidiFilterConsumer::SimpleMidiFilterConsumer(
	SimpleMidiFilter* filter_, const char* name)
	: BMidiLocalConsumer(name)
{
	filter = filter_;
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::NoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	filter->NoteOff(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::NoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	filter->NoteOn(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::KeyPressure(
	uchar channel, uchar note, uchar pressure, bigtime_t time)
{
	filter->KeyPressure(channel, note, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::ControlChange(
	uchar channel, uchar controlNumber, uchar controlValue, 
	bigtime_t time)
{
	filter->ControlChange(channel, controlNumber, controlValue, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::ProgramChange(
	uchar channel, uchar programNumber, bigtime_t time)
{
	filter->ProgramChange(channel, programNumber, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::ChannelPressure(
	uchar channel, uchar pressure, bigtime_t time)
{
	filter->ChannelPressure(channel, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::PitchBend(
	uchar channel, uchar lsb, uchar msb, bigtime_t time)
{
	filter->PitchBend(channel, lsb, msb, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::SystemExclusive(
	void* data, size_t dataLength, bigtime_t time)
{
	filter->SystemExclusive(data, dataLength, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::SystemCommon(
	uchar status, uchar data1, uchar data2, bigtime_t time)
{
	filter->SystemCommon(status, data1, data2, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::SystemRealTime(
	uchar status, bigtime_t time)
{
	filter->SystemRealTime(status, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilterConsumer::TempoChange(
	int32 beatsPerMinute, bigtime_t time)
{
	filter->TempoChange(beatsPerMinute, time);
}

//------------------------------------------------------------------------------

SimpleMidiFilter::SimpleMidiFilter(const char* name)
{
	output = new BMidiLocalProducer(name);
	input = new SimpleMidiFilterConsumer(this, name);
}

//------------------------------------------------------------------------------

SimpleMidiFilter::~SimpleMidiFilter()
{
	input->Release();
	output->Release();
}

//------------------------------------------------------------------------------

status_t SimpleMidiFilter::Register()
{
	status_t res;

	res = input->Register();
	if (res != B_OK) { return res; }

	res = output->Register();
	if (res != B_OK) { return res; }

	return B_OK;
}

//------------------------------------------------------------------------------

status_t SimpleMidiFilter::Unregister()
{
	status_t res;

	res = input->Unregister();
	if (res != B_OK) { return res; }

	res = output->Unregister();
	if (res != B_OK) { return res; }

	return B_OK;
}

//------------------------------------------------------------------------------

BMidiLocalConsumer* SimpleMidiFilter::Input() const
{
	return input;
}

//------------------------------------------------------------------------------

BMidiLocalProducer* SimpleMidiFilter::Output() const
{
	return output;
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::NoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	SprayNoteOff(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::NoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	SprayNoteOn(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::KeyPressure(
	uchar channel, uchar note, uchar pressure, bigtime_t time)
{
	SprayKeyPressure(channel, note, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::ControlChange(
	uchar channel, uchar controlNumber, uchar controlValue, bigtime_t time)
{
	SprayControlChange(channel, controlNumber, controlValue, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::ProgramChange(
	uchar channel, uchar programNumber, bigtime_t time)
{
	SprayProgramChange(channel, programNumber, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::ChannelPressure(
	uchar channel, uchar pressure, bigtime_t time)
{
	SprayChannelPressure(channel, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::PitchBend(
	uchar channel, uchar lsb, uchar msb, bigtime_t time)
{
	SprayPitchBend(channel, lsb, msb, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SystemExclusive(
	void* data, size_t dataLength, bigtime_t time)
{
	SpraySystemExclusive(data, dataLength, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SystemCommon(
	uchar status, uchar data1, uchar data2, bigtime_t time)
{
	SpraySystemCommon(status, data1, data2, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SystemRealTime(uchar status, bigtime_t time)
{
	SpraySystemRealTime(status, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::TempoChange(int32 beatsPerMinute, bigtime_t time)
{
	SprayTempoChange(beatsPerMinute, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayData(
	void* data, size_t length, bool atomic, bigtime_t time) const
{
	Output()->SprayData(data, length, atomic, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayNoteOff(
	uchar channel, uchar note, uchar velocity, bigtime_t time) const
{
	Output()->SprayNoteOff(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayNoteOn(
	uchar channel, uchar note, uchar velocity, bigtime_t time) const
{
	Output()->SprayNoteOn(channel, note, velocity, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayKeyPressure(
	uchar channel, uchar note, uchar pressure, bigtime_t time) const
{
	Output()->SprayKeyPressure(channel, note, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayControlChange(
	uchar channel, uchar controlNumber, uchar controlValue, 
	bigtime_t time) const
{
	Output()->SprayControlChange(channel, controlNumber, controlValue, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayProgramChange(
	uchar channel, uchar programNumber, bigtime_t time) const
{
	Output()->SprayProgramChange(channel, programNumber, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayChannelPressure(
	uchar channel, uchar pressure, bigtime_t time) const
{
	Output()->SprayChannelPressure(channel, pressure, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayPitchBend(
	uchar channel, uchar lsb, uchar msb, bigtime_t time) const
{
	Output()->SprayPitchBend(channel, lsb, msb, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SpraySystemExclusive(
	void* data, size_t dataLength, bigtime_t time) const
{
	Output()->SpraySystemExclusive(data, dataLength, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SpraySystemCommon(
	uchar status, uchar data1, uchar data2, bigtime_t time) const
{
	Output()->SpraySystemCommon(status, data1, data2, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SpraySystemRealTime(
	uchar status, bigtime_t time) const
{
	Output()->SpraySystemRealTime(status, time);
}

//------------------------------------------------------------------------------

void SimpleMidiFilter::SprayTempoChange(
	int32 beatsPerMinute, bigtime_t time) const
{
	Output()->SprayTempoChange(beatsPerMinute, time);
}

//------------------------------------------------------------------------------
