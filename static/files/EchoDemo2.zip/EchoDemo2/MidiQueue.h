
#ifndef MIDI_QUEUE_H
#define MIDI_QUEUE_H

#include <List.h>
#include <Locker.h>

class BMidiLocalConsumer;
class BMidiLocalProducer;

struct midi_event_t;

class MidiQueue
{
public:

	MidiQueue();
	~MidiQueue();

	BMidiLocalConsumer* Input() const;
	BMidiLocalProducer* Output() const;

private:

	friend class MidiQueueConsumer;
	friend class MidiQueueProducer;

	void AddEvent(midi_event_t* event);
	midi_event_t* GetEvent(bigtime_t latency);

	BMidiLocalConsumer* input;
	BMidiLocalProducer* output;

	BLocker locker;
	BList list;
};

#endif // MIDI_QUEUE_H
