
#include <MidiConsumer.h>
#include <MidiProducer.h>
#include <stdio.h>
#include <stdlib.h>

#include "MidiQueue.h"

#define SLEEP_TIME  1000LL

//------------------------------------------------------------------------------

// For every incoming MIDI event we allocate a new midi_event_t object
// and copy the MIDI data into that. This object is added to MidiQueue's
// BList. After the producer has performed the event, we delete it.

struct midi_event_t
{
	midi_event_t(uchar* data_, size_t length_, bool atomic_, bigtime_t time_)
	{
		length = length_;
		atomic = atomic_;
		time   = time_;

		data = (uchar*) malloc(length);
		memcpy(data, data_, length);
	}

	~midi_event_t()
	{
		free(data);
	}

	uchar* data;
	size_t length;
	bool atomic;
	bigtime_t time;
};

//------------------------------------------------------------------------------

class MidiQueueConsumer : public BMidiLocalConsumer
{
public:

	MidiQueueConsumer(MidiQueue* queue);

	virtual void Data(uchar* data, size_t length, bool atomic, bigtime_t time);

private:

	MidiQueue* queue;
};

//------------------------------------------------------------------------------

MidiQueueConsumer::MidiQueueConsumer(MidiQueue* queue_)
	: BMidiLocalConsumer("MidiQueue")
{
	queue = queue_;
}

//------------------------------------------------------------------------------

void MidiQueueConsumer::Data(
	uchar* data, size_t length, bool atomic, bigtime_t time)
{
	// All MIDI events first arrive in the Data() hook. If you don't
	// override it, Data() figures out what type of MIDI event this is,
	// and calls the corresponding NoteOn(), NoteOff(), etc. function.
	// But we don't care about that; we just want to have the raw data.

	printf("[MidiQueue] consumer is adding event at %lld\n", time);

	queue->AddEvent(new midi_event_t(data, length, atomic, time));
}

//------------------------------------------------------------------------------

class MidiQueueProducer : public BMidiLocalProducer
{
public:

	MidiQueueProducer(MidiQueue* queue);

	virtual void Connected(BMidiConsumer* cons);
	virtual void Disconnected(BMidiConsumer* cons);

private:

	~MidiQueueProducer();

	static int32 SpawnThread(void* data);
	int32 Run();

	void CalculateDownstreamLatency();

	MidiQueue* queue;
	bigtime_t latency;
	thread_id thread;
	bool running;
};

//------------------------------------------------------------------------------

MidiQueueProducer::MidiQueueProducer(MidiQueue* queue_)
	: BMidiLocalProducer("MidiQueue")
{
	queue   = queue_;
	latency = 0;
	running = true;

	thread = spawn_thread(
		SpawnThread, "MidiQueue Reader", B_NORMAL_PRIORITY, this);

	resume_thread(thread);
}

//------------------------------------------------------------------------------

MidiQueueProducer::~MidiQueueProducer()
{
	running = false;  // tell thread to stop

	status_t result;
	wait_for_thread(thread, &result);
}

//------------------------------------------------------------------------------

void MidiQueueProducer::Connected(BMidiConsumer* cons)
{
	CalculateDownstreamLatency();
}

//------------------------------------------------------------------------------

void MidiQueueProducer::Disconnected(BMidiConsumer* cons)
{
	CalculateDownstreamLatency();
}

//------------------------------------------------------------------------------

void MidiQueueProducer::CalculateDownstreamLatency()
{
	// For our purposes, the "downstream latency" is the latency of the
	// slowest consumer. Every time a consumer connects or disconnects,
	// we re-calculate it. Note that this does not handle on-the-fly
	// latency changes from consumers.

	latency = 0;

	BList* list = Connections();
	for (int32 t = 0; t < list->CountItems(); ++t)
	{
		BMidiConsumer* cons = (BMidiConsumer*) list->ItemAt(t);

		if (cons->Latency() > latency)
		{
			latency = cons->Latency();
		}

		cons->Release();
	}
	delete list;

	printf("[MidiQueue] latency is now %lld\n", latency);
}

//------------------------------------------------------------------------------

int32 MidiQueueProducer::SpawnThread(void* data)
{
	return ((MidiQueueProducer*) data)->Run();
}

//------------------------------------------------------------------------------

int32 MidiQueueProducer::Run()
{
	while (running)
	{
		snooze(SLEEP_TIME);

		midi_event_t* event = queue->GetEvent(latency);
		if (event != NULL)
		{
			printf(
				"[MidiQueue] producer is spraying event from %lld "
				"(now = %lld, difference = %lld)\n", event->time, 
				system_time(), system_time() - event->time);

			SprayData(event->data, event->length, event->atomic, event->time);

			delete event;
		}
	}

	return 0;
}

//------------------------------------------------------------------------------

MidiQueue::MidiQueue()
{
	input  = new MidiQueueConsumer(this);
	output = new MidiQueueProducer(this);
}

//------------------------------------------------------------------------------

MidiQueue::~MidiQueue()
{
	input->Release();
	output->Release();

	for (int32 t = 0; t < list.CountItems(); ++t)
	{
		delete list.ItemAt(t);  // throw away any remaining events
	}
}

//------------------------------------------------------------------------------

BMidiLocalConsumer* MidiQueue::Input() const
{
	return input;
}

//------------------------------------------------------------------------------

BMidiLocalProducer* MidiQueue::Output() const
{
	return output;
}

//------------------------------------------------------------------------------

void MidiQueue::AddEvent(midi_event_t* event)
{
	// We add the events to the list, sorted in time. The earlier that an
	// event needs to be performed, the closer it is to the front of the list.

	locker.Lock();

	int32 t;
	for (t = 0; t < list.CountItems(); ++t)
	{
		midi_event_t* other = (midi_event_t*) list.ItemAt(t);
		if (event->time < other->time)
		{
			break;  // found a spot
		}
	}

	printf("[MidiQueue] queued at index %ld of %ld\n", t, list.CountItems());

	list.AddItem(event, t);
	locker.Unlock();
}

//------------------------------------------------------------------------------

midi_event_t* MidiQueue::GetEvent(bigtime_t latency)
{
	// We will look at the first event in the list (if any). If that event
	// should be performed now, we return it. Otherwise, we return NULL to
	// let the producer know that it should sleep some more.

	midi_event_t* event = NULL;
	locker.Lock();

	if (list.CountItems() > 0)
	{
		event = (midi_event_t*) list.ItemAt((int32) 0);
		if (event->time + latency + SLEEP_TIME <= system_time())
		{
			list.RemoveItem((int32) 0);
		}
		else  // it is not time to perform this event yet
		{
			event = NULL;
		}
	}

	locker.Unlock();
	return event;
}

//------------------------------------------------------------------------------
