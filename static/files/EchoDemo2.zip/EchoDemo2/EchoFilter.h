
#ifndef ECHO_FILTER_H
#define ECHO_FILTER_H

#include "SimpleMidiFilter.h"

class EchoFilter : public SimpleMidiFilter
{
public:

	EchoFilter(const char* name);

	// How many echo notes we will play.
	int32 notes;

	// The time between the echo notes (milliseconds).
	int32 delay;

protected:

	virtual void NoteOn(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

	virtual void NoteOff(
		uchar channel, uchar note, uchar velocity, bigtime_t time);

private:

	typedef SimpleMidiFilter super;
};

#endif // ECHO_FILTER_H
