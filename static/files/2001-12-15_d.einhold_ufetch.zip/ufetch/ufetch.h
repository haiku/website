
#define NO_SOCKET -1


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// IP_Address:
//
// Equivalent to the standard sockets struct 'sockaddr_in', but simpler.
// Note: this version matches the binary format of 'sockaddr_in' as declared
// in the Intel version of BeOS. If you want to compile on another platform,
// the size of the 'unused' member may need to be changed.
//
// Byte orders designations:
//   HBO: host byte order (whatever byte order the local platform uses)
//   NBO: network byte order (also referred to as Big-Endian)
//   000: none -- an unused datum whose contents should be zero

typedef struct
	{
	int16  family;    // HBO: address family -- always AF_INET (internet)
	int16  port;      // NBO: specific to each protocol or service (e.g. 80 for http)
	int32  IP;        // NBO: IP address
	int32  unused;    // 000: filler bytes
	}
IP_Address;



int    connectTo       (char *, int);
char * connectErrMsg   (int);
char * dotted_address  (int32);
void   download        (int, char *, char *);
void   fetch           (char *);
void   fetchData       (char *, int, char *, char *);
void   first2words     (char *, char *, char *);
void   flushData       (char *, int, bool);
char * generateRequest (char *, char *);
int    IPConnect       (int32, int, char *);
char * kbytes          (int);
int32  localIP         (int);
int32  lookupHost      (const char *);
char * partition       (char *);
int    parseHeader     (char *, char *);
void   splitURL        (char *, char *, char *, int *, char *);

