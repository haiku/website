// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
//
//  ufetch.c
//  
//    command line utility that fetches data from web servers:
//      
//    status info is sent to stdout while processing the request...
//    the downloaded data is stored in a single file called 'f.data'.
//
//    Copyright (c) Daniel Reinhold
//    written Oct-Nov 2000
//    updated Jul-Aug 2001
//
// ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <socket.h>
#include <netdb.h>

#include "ufetch.h"

typedef unsigned char byte;

#define false 0
#define true  1


static const int HTTP_PORT = 80;



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//  top-level


int
main (int argc, char *argv[])
	{
	// the desired URL is passed on the command line
	
	if (argc == 2)
		fetch (argv[1]);
	else
		puts ("usage: ufetch URL\n");
	
	putchar ('\n');
	return 0;
	}


void
fetch (char *url)
	{
	// top-level function

	int  port = HTTP_PORT;	// assumes standard http port assignment by default
	
	char proto[64];		// protocol (fetch only accepts "http")
	char host[200];		// domain name for host (web server)
	char rsrc[512];		// resource part of the URL
	
	char header[2048];	// return header
	int  status;		// status code
	char redir[512];	// redirected URL
	
	bool finished = false;
	
	while (!finished)
		{
		splitURL (url, proto, host, &port, rsrc);
		if (*proto && strcmp (proto, "http") != 0)
			{
			printf ("invalid protocol '%s': fetch only grabs from web servers!\n", proto);
			exit (-1);
			}
		
		// grab the data and check returned HTTP status codes
		*header = 0;
		fetchData (host, port, rsrc, header);

		status = parseHeader (header, redir);
		switch (status)
			{
			case 301:
			case 302:
				{
				url = redir;
				printf ("\n\nredirect to URL\n'%s'\n\n", url);
				break;
				}
			
			default:
				finished = true;
			}
		}
	}



void
fetchData (char *host, int port, char *rsrc, char *header)
	{
	// connect to server 'host' and download resource 'rsrc'
	
	int sock = connectTo (host, port);
	if (sock != NO_SOCKET)
		{
		printf ("\ncreated socket %d\n", sock);
		printf ("local IP is %s\n", dotted_address (localIP (sock)));

		{
		char *req = generateRequest (rsrc, host);
		download (sock, req, header);
		}
		
		printf ("closing socket %d\n", sock);
		closesocket (sock);
		}
	}



int
connectTo (char *host, int port)
	{
	// establish a connection to an internet server
	// with the given host name and port assignment

	int   sock = NO_SOCKET;
	int32 IP;
	
	printf ("\nlooking up host '%s'\n", host);
	IP = lookupHost (host);
	
	if (IP == 0)  printf ("cannot find host '%s'\n", host);
	else
		{
		char errmsg[256] = {0};
		
		printf ("connecting to %s ...\n", dotted_address (IP));
		if (port != HTTP_PORT)
			{
			printf ("non-standard port assignment: %d\n", port);
			}
		
		sock = IPConnect (IP, port, errmsg);
		if (sock == NO_SOCKET)
			{
			printf ("cannot connect to '%s': %s\n", host, errmsg);
			}
		}
	
	return sock;
	}



char *
generateRequest (char *rsrc, char *host)
	{
	// generate and return an HTTP 'GET' request header
	
	static char req[1024];

	sprintf (req,	"GET %s HTTP/1.1\r\n"
					"Host: %s\r\n"
					"User-Agent: ufetch\r\n"
					"Accept: */*\r\n"
					"Connection: close\r\n\r\n", rsrc, host);
		
	return req;
	}



void
download (int sock, char *req, char *header)
	{
	// download the requested resource via an open socket
	//
	// the downloaded data is parsed into two sections:
	//   1) the reply header
	//   2) the resource contents
	//
	// the extracted header is copied into the last arg
	// the contents are written out to the file "f.data"
	
	static const int BlockSize = 32000;

	// try to allocate space for a download block
	byte *block = (byte *) malloc (BlockSize);
	
	if (block == NULL)
		{
		// Ok... didn't try very hard
		printf ("out of memory\n");
		exit (-1);
		}
	else
		{
		int    i, n, len, numblocks = 0;
		int32  bsize, total = 0;
		bool   receiving = true;
		
		// send request header
		printf ("\nsending request header\n{\n%s}\n", req);
		
		len = strlen (req);
		for (i = 0; i < len; i += n)
			{
			n = send (sock, req+i, len-i, 0);
			if (n <= 0)
				break;
			}
		
		// receive bytes from server
		while (receiving)
			{
			printf ("\nsocket %d receiving bytes:\n", sock);
			
			// fill a single block of data
			bsize = 0;
			for (i = 0; i < BlockSize; i += n)
				{
				n = recv (sock, block+i, BlockSize-i, 0);
				if (n <= 0)
					{
					receiving = false;
					break;
					}
				
				bsize += n;
				total += n;
				printf ("\t%d\t\t%d\n", n, total);
				}
			
			// flush block to disk
			if (++numblocks == 1)
				{
				// extract header from first block
				byte *pheader = block;
				byte *pdata   = partition (block);
				
				len = pdata-pheader;	// length of header
				
				strcpy (header, pheader);
				printf ("\nreceived reply header\n{\n%s\n}\n", header);
				
				flushData (pdata, bsize-len, true);
				}
			else			
				flushData (block, bsize, false);
			}
		
		printf ("\ntotal bytes downloaded: %d (%s)\n", total, kbytes (total));
		free (block);
		}
	}



void
flushData (char *data, int dsize, bool firstblock)
	{
	// write 'dsize' bytes of data to disk

	if (dsize > 0)
		{
		FILE *fp = fopen ("f.data", firstblock ? "wb" : "ab");
		if (fp)
			{
			printf ("\nflushing %d bytes to disk...\n", dsize);
			fwrite (data, 1, dsize, fp);
			fclose (fp);
			}
		}
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//  sockets interface


int
IPConnect (int32 IP, int port, char *errmsg)
	{
	// creates a socket and then connects it to the given IP and port
	//
	// success: returns the newly created/connected socket
	// failure: sets the error message arg and returns NO_SOCKET (-1)
	
	int err  = 0;
	int sock = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	
	if (sock < 0)  err = errno;
	else
		{
		IP_Address a = {AF_INET, htons (port), IP};
		
		int n = connect (sock, (struct sockaddr *) &a, sizeof a);
		if (n < 0)
			{
			err = errno;
			closesocket (sock);
			}
		}

	if (err == 0)  return sock;
	else
		{
		strcpy (errmsg, connectErrMsg (err));
		return NO_SOCKET;
		}		
	}



int32
localIP (int sock)
	{
	// input:  a valid, CONNECTED socket
	// output: the IP address of the local machine
	//
	// note: the socket arg must already be connected to a
	// network for this function to return anything useful

	IP_Address local = {0};
	int size = sizeof local;
	
	getsockname (sock, (struct sockaddr *) &local, &size);
	return local.IP;
	}



int32
lookupHost (const char *host)
	{
	// input:  a server name (e.g. "www.foo.com")
	// output: the IP address
	
	int32 IP = 0;
	
	struct hostent *h = gethostbyname (host);
	
	if (h && h->h_addr)
		IP = *(int32 *)(h->h_addr);
	
	return IP;
	}



char *
dotted_address (int32 IP)
	{
	// input:  an IP address -- already in NBO (network byte order)
	// output: a string representing the IP address in dotted notation
	//         (e.g. "216.10.8.227")
	//
	// yes, it does the same thing as the standard sockets function
	// 'inet_ntoa()', but... it has a friendlier name and uses an
	// integer arg (instead of the weird 'in_addr' structure)
	
	static char dotted_buffer[] = "xxx.xxx.xxx.xxx";
	char *p = dotted_buffer;
	
	byte *b = (byte *) &IP;   // view the IP address as an array of 4 bytes
	byte  c;                  // value of the current IP byte
	int   nb = 4;             // number of bytes (left) to extract
	byte  h, t, u;
	
	while (nb--)
		{
		c = *b++;
		h = c/100, t = (c/10)%10, u = c%10;
		
		if (h)  *p++ = h + '0';  // set hundreds digit (if nonzero)
		if (t)  *p++ = t + '0';  // set tens digit (if nonzero)
		        *p++ = u + '0';  // set units digit (always)
		
		if (nb)
			*p++ = '.';
		}
	*p = 0;
	
	return dotted_buffer;
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//  parsing routines


void
splitURL (char *url, char *proto, char *host, int *port, char *rsrc)
	{
	// split a url into its component parts
	//
	// e.g. "http://www.foo.com:80/little/boy/blue.zip" gives
	// 
	//      protocol: "http"
	//     host name: "www.foo.com"
	//          port: 80
	//      resource: "little/boy/blue.zip"
	
	char *p = url, *q;
	
	*proto = *host = *rsrc = 0;
	
	if (strstr (p, "://"))
		{
		// copy letters up to ':' as the protocol
		while (*p && *p != ':')
			*proto++ = *p++;
		*proto = 0;
		
		// skip over ':'
		++p;
		
		// skip over "//"
		while (*p == '/')
			++p;
		}
	
	// copy letters up the the first '/' as the host
	q = host;
	while (*p && *p != '/')
		*q++ = *p++;
	*q = 0;
	
	// check for port assignment in host
	q = strchr (host, ':');
	if (q)
		{
		*q++ = 0;
		*port = atoi (q);
		}
	
	// copy remaining url as the resource (or just "/" if remainder is empty)
	if (*p == 0) *rsrc++ = '/';
	else
		while (*p)
			*rsrc++ = *p++;
	*rsrc = 0;
	}



char *
partition (char *buf)
	{
	// partitions the given data buffer into (header, content)
	//
	// the buffer is searched for the first blank line -- which marks
	// the end of the header -- and is partitioned at that point.
	// a pointer to the rest of the buffer (the content) is returned

	char c;			// current char
	char nc;		// next char
	int  lb = 0;	// number of successive line breaks
	
	while ((c = *buf++) != 0)
		{
		nc = *buf;
		
		if (c == '\r' && nc == '\n')  ++lb, ++buf;
		else
			lb = 0;
		
		if (lb == 2)
			{
			// two line breaks in a row ==> end of the header
			buf[-1] = 0;
			return buf;
			}
		}
	
	// never found
	return "";
	}



void
first2words (char *buf, char *first, char *second)
	{
	// copies the first two words from the buffer into the args
	// (a "word" being contiguous chars separated by whitespace)

	while (*buf && !isspace (*buf))  *first++ = *buf++;	
	while (*buf &&  isspace (*buf))  ++buf;    
	while (*buf && !isspace (*buf))  *second++ = *buf++;
	
	*first = *second = 0;
	}



int
parseHeader (char *header, char *redir)
	{
	//
	//

	int  status = 0;			// HTTP return status code
	char key[64], val[512];		// (key, value) pair
	char *s, *p;
	
	// 
	for (s = header; s && *s; s = p)
		{
		first2words (s, key, val);
		
		if      (strncmp ("HTTP/",     key, 5) == 0)  status = atoi (val);
		else if (strncmp ("Location:", key, 9) == 0)  strcpy (redir, val);

		p = strchr (s, '\r');
		if (p)
			{
			++p;
			if (*p == '\n') ++p;
			}
		}
	
	return status;
	}



char *
connectErrMsg (int err)
	{
	// input:  the value of errno after a failed connection attempt
	// output: a readable text string describing the nature of the error
	//
	// reference: The BeBook for BeOS5 -- 'Network Kit' chapter
	
	switch (err)
		{
		case EWOULDBLOCK:  return "Connection attempt would block.";
		case EISCONN:      return "Socket is already connected.";
		case ECONNREFUSED: return "Listener rejected the connection.";
		case ETIMEDOUT:    return "Connection attempt timed out.";
		case ENETUNREACH:  return "Client can't get to the network.";
		case EBADF:        return "Socket argument is invalid.";
		default:
			return strerror (err);
		}
	}


char *
kbytes (int bytes)
	{
	// simple formatting routine

	static char fmt[] = "123456789.00";
	
	sprintf (fmt, "%.2fK", bytes/1024.0);
	return fmt;
	}



//
// end of ufetch.c
//