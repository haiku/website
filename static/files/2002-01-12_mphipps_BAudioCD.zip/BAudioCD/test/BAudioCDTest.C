#include "BAudioCD.h"
#include <String.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

void usage(void)
{
	printf ("usage - \n");
	printf ("BAudioCDTest device command [options]\n");
	printf ("open - open the CDRom drive\n");
	printf ("load - close the CDRom drive\n");
	printf ("close - close the CDRom drive device\n");
	printf ("play S E - play starting at track S and ending at track E\n");
	printf ("pause - pause the CD\n");
	printf ("resume - unpause the CD\n");
	printf ("stop - stops the CD\n");
	printf ("getPos - gets the CD position\n");
	printf ("getStat - gets the CD status\n");
	printf ("getTOC - gets the CD's Table of Contents \n");
	printf ("forward - start scanning forward \n");
	printf ("backward - start scanning backward \n");
	printf ("noScan - stop scanning \n");
	printf ("setVolume N - set the volume to N \n");
	printf ("getVolume - get the volume \n");
	printf ("getTracks - get the number of tracks \n");
	printf ("getLength - get the length of the CD in seconds \n");
	printf ("getCDDBID - get the CDDB ID for this CD \n");
}

int main (int argc, char **argv )
{
	if (argc<2)
		{
		usage();
		return(1);
		}
	BAudioCD test(argv[1]);
	if (!strcmp("open",argv[2]))
		printf ("open returned %d\n",test.Eject());
	else if (!strcmp("load",argv[2]))
		printf ("load returned %d\n",test.Load());
	else if (!strcmp("close",argv[2]))
		printf ("close returned %d\n",test.Close());
	else if (!strcmp("play",argv[2]))
		printf ("play returned %d\n",test.Play(atoi(argv[3]),atoi(argv[4])));
	else if (!strcmp("pause",argv[2]))
		printf ("pause returned %d\n",test.Pause());
	else if (!strcmp("resume",argv[2]))
		printf ("resume returned %d\n",test.Resume());
	else if (!strcmp("stop",argv[2]))
		printf ("stop returned %d\n",test.Stop());
	else if (!strcmp("getPos",argv[2]))
		{
		BAudioCDPosition pos=test.GetPosition();
		printf ("getPos returned track %03d, %02d:%02d:%02d\n",
				pos.track,pos.trackMinute,pos.trackSecond,pos.trackFrame);
		printf ("total %02d:%02d:%02d\n",
				pos.totalMinute,pos.totalSecond,pos.totalFrame);
		}
	else if (!strcmp("getStat",argv[2]))
		printf ("getStat returned %d\n",test.GetMediaStatus());
	else if (!strcmp("getTOC",argv[2]))
		{
		BList list;
		int listCount=list.CountItems();
		printf ("There are %d items\n",listCount);
		test.GetTOC(&list);
		listCount=list.CountItems();
		printf ("There are %d items\n",listCount);
		BString *anItem;

		for ( int32 i = 0; anItem = (BString *)(list.ItemAt(i)); i++ )
			printf ("  -- %s\n",anItem->String());
		}
	else if (!strcmp("forward",argv[2]))
		printf ("forward returned %d\n",test.ScanForward());
	else if (!strcmp("backward",argv[2]))
		printf ("backward returned %d\n",test.ScanBackward());
	else if (!strcmp("noScan",argv[2]))
		printf ("noScan returned %d\n",test.StopScanning());
	else if (!strcmp("setVolume",argv[2]))
		printf ("setVolume returned %d\n",test.SetVolume(atoi(argv[3])));
	else if (!strcmp("getVolume",argv[2]))
		printf ("getVolume returned %d\n",test.GetVolume());
	else if (!strcmp("getTracks",argv[2]))
		printf ("getTracks returned %d\n",test.getTracks());
	else if (!strcmp("getLength",argv[2]))
		printf ("getLength returned %d\n",test.getLength());
	else if (!strcmp("getCDDBID",argv[2]))
		{
		int count,frameList[200];
		printf ("getCDDBID returned %lx\n",test.getCDDBID(frameList));
		count=test.getTracks();
		for (int i=0;i<count;i++)
			printf ("%d ",frameList[i]);
		printf ("\n");
		}
	else
		printf ("Command not understood!\n");
	printf ("Current error = %s\n", strerror(errno));
	return 0;
}
