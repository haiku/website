#!/bin/sh

CDPath=/dev/disk/ide/atapi/1/master/0/raw

echo
echo compiling library...
make

echo
echo copying library to system lib directory...
cp obj.x86/libBCDROM.so /boot/beos/system/lib

cd test
echo
echo compiling test app...
make

cd ..
cp test/obj.x86/BAudioCDTest BAudioCDTest

alert --warning \
"Insert a music CD into the CD-ROM. \
When you have done this, click OK" \
"OK"

echo
echo =====================================================================
echo \ \ \ you can now run the test program from the command line
echo \ \ \ just type in \"BAudioCDTest\" to see the list of commands
echo  
echo \ \ \ to get started, try entering the following command:
echo BAudioCDTest $CDPath getTracks 
echo =====================================================================
echo