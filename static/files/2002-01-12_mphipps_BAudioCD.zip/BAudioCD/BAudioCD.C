#include <stdio.h>
#include <scsi.h>
#include <unistd.h>
#include <memory.h>
#include "BAudioCD.h"
#include <String.h>
#include <NetEndpoint.h>

BAudioCD::BAudioCD (char *device)
	{
	myDevice=open(device,O_RDONLY);
	if (myDevice<0)
		throw ("Device name not valid!");
	}

BAudioCD::~BAudioCD()
	{
	close(myDevice);
	}

bool BAudioCD::Eject(void)
	{
	status_t result=ioctl(myDevice,B_EJECT_DEVICE);
	return (result==B_NO_ERROR);
	}

bool BAudioCD::Load(void)
	{
	status_t result=ioctl(myDevice,B_LOAD_MEDIA);
	return (result==B_NO_ERROR);
	}

bool BAudioCD::Close(void)
	{
	close(myDevice);
	}

bool BAudioCD::Play(uint32 trackNo,uint32 endTrack)
	{
	scsi_play_track scsiTrack;
	scsiTrack.start_track=trackNo;
	scsiTrack.end_track=endTrack;
	scsiTrack.start_index=1;
	scsiTrack.end_index=1;

	status_t result=ioctl(myDevice,B_SCSI_PLAY_TRACK,&scsiTrack);
	return (result==B_NO_ERROR);
	}

bool BAudioCD::Pause(void)
	{
	status_t result=ioctl(myDevice,B_SCSI_PAUSE_AUDIO);
	return (result==B_NO_ERROR);
	}

bool BAudioCD::Resume(void)
	{
	status_t result=ioctl(myDevice,B_SCSI_RESUME_AUDIO);
	return (result==B_NO_ERROR);
	}

bool BAudioCD::Stop(void)
	{
	status_t result=ioctl(myDevice,B_SCSI_STOP_AUDIO);
	return (result==B_NO_ERROR);
	}

BAudioCDPosition  BAudioCD::GetPosition(void)
	{
	BAudioCDPosition retVal;
	scsi_position position;
	status_t result=ioctl(myDevice,B_SCSI_GET_POSITION,&position);
	uchar status=position.position[1];

	if ((!status) || (status >= 19) || ((status==18) && (!position.position[6])))
		memset(&retVal,'0',sizeof(retVal));
	else
		{
		retVal.track=position.position[6];
		retVal.totalMinute=position.position[9];
		retVal.totalSecond=position.position[10];
		retVal.totalFrame=position.position[11]; 
		retVal.trackMinute=position.position[13];
		retVal.trackSecond=position.position[14];
		retVal.trackFrame=position.position[15]; 
		}
	return retVal;
	}

status_t  BAudioCD::GetMediaStatus(void)
	{
	status_t status;
	status_t result=ioctl(myDevice,B_GET_MEDIA_STATUS,&status,sizeof(status));
	if (result==B_NO_ERROR)
		return status;
	else
		return (result);
	}

uint32 BAudioCD::getTracks(void)
{
	scsi_toc toc;
	
	status_t result = ioctl(myDevice, B_SCSI_GET_TOC, &toc);
	return ((result==B_NO_ERROR)?toc.toc_data[3]-toc.toc_data[2]+1:0);
}

struct trackHeader
{
	uchar reserved;
	uchar adr_control;
	uchar trackNumber;
	uchar reserved2;
	uchar unknown;
	uchar min;
	uchar sec;
	uchar frame;
};

int cddb_sum(int n)
{
	printf ("summing %d, ",n);
	int	ret=0;
	while (n > 0) 
		{
		ret = ret + (n % 10);
		n = n / 10;
		}
	printf ("returning %d\n",ret);
	return (ret);
}

uint32 BAudioCD::getCDDBID(int frameOffsets[])
{
	scsi_toc toc;
	trackHeader *tracks,*thisTrack;
	int numTracks=0,sum1=0,sum2;
	
	status_t result = ioctl(myDevice, B_SCSI_GET_TOC, &toc);
	numTracks=toc.toc_data[3]-toc.toc_data[2]+1;
	tracks=(trackHeader *)(&(toc.toc_data[4]));
	for (int i=0;i<numTracks;i++)
		{
		thisTrack=&(tracks[i]);
		printf ("Reserved = %d, adrCon = %d, trackNum = %d, skip = %d, Minutes = %d, seconds = %d, frame = %d\n",
			thisTrack->reserved,thisTrack->adr_control,thisTrack->trackNumber,thisTrack->reserved2,thisTrack->min,thisTrack->sec,thisTrack->frame);
		sum1+=cddb_sum(thisTrack->min*60+thisTrack->sec);
		frameOffsets[i]=thisTrack->min*4500+thisTrack->sec*75+thisTrack->frame;
		}
	
	sum2 = ((tracks[numTracks].min * 60) + tracks[numTracks].sec) -
					    ((tracks[0].min * 60) + tracks[0].sec);
	return ((sum1 % 0xff) << 24 | sum2 << 8 | numTracks);
}

void appendDecimal (BString &str,uint32 value)
{ 
	char temp[50];
	sprintf (temp,"%d ",value);
	str.Append(temp);
}

void appendHex (BString &str,uint32 value)
{ 
	char temp[50];
	sprintf (temp,"%x ",value);
	str.Append(temp);
}

uint32 BAudioCD::getLength(void)
{
	scsi_toc toc;
	trackHeader *tracks;
	int numTracks;
	
	status_t result = ioctl(myDevice, B_SCSI_GET_TOC, &toc);
	if (result!=B_NO_ERROR)
		return 0;
	tracks=(trackHeader *)(&(toc.toc_data[4]));
	numTracks=toc.toc_data[3]-toc.toc_data[2]+1;
	return tracks[numTracks].min*60+tracks[numTracks].sec;
}

void ReadLine (BNetEndpoint &connection, BString &string)
{
	string="";
	int count=1;
	char oneChar=' ';
	do
		{
		count=connection.Receive(&oneChar,1);
		if (count ==1 && oneChar>=' ')
			string+=oneChar;
		}
	while (oneChar!='\n' && count==1);
}

BList *BAudioCD::GetTOC(BList *storage)
{
	BString query("cddb query ");
	BString response;
	BString discID;
	int numTracks;
	int frameSizes[200]; // NO cd should ever have 200 tracks...
	appendHex(discID,getCDDBID(frameSizes));
	query << discID;
	appendDecimal(query, numTracks=getTracks());
	for (int i=0;i<numTracks;i++)
		appendDecimal(query, frameSizes[i]);
	appendDecimal(query, getLength());
	query << "\n";

	BNetEndpoint connection;
	if (connection.InitCheck()!=B_OK)
		return storage;
	connection.Connect("freedb.freedb.org",8880);

	printf ("Connected!\n");
	ReadLine(connection,response);
	printf ("%s\n",response.String());

	BString helloMsg("cddb hello BeOSUser BeOSMachine OpenBeOS R1\n");
	connection.Send(helloMsg.String(),helloMsg.Length());
	printf ("Hello Answered!\n");
	ReadLine(connection,response);
	printf ("%s\n",response.String());

	connection.Send(query.String(),query.Length());
	ReadLine(connection,response);
	printf ("%s\n",response.String());
	printf ("Query Answered!\n");
	char *ptr,temp[500];
	strcpy(temp,response.String());
	ptr=strtok(temp," ");
	if (strcmp("200",ptr)) // If code != 200, query failed
		return storage;
	ptr=strtok(NULL," ");
	BString catagory(ptr);	
	BString readCommand("cddb read ");
	readCommand << catagory << " " << discID << "\n";
	connection.Send(readCommand.String(),readCommand.Length());
	do
		{
		ReadLine(connection,response);
		printf ("%s\n",response.String());
		}
	while (response.FindFirst(".")!=1);
	return storage; // Need to fill this in with a call to CDDB...
}

static bool scan(int myDevice,char direction)
{
	scsi_scan scan;
	scan.direction=direction;
	scan.speed=1;
	status_t result=ioctl(myDevice,B_SCSI_SCAN,&scan);
	return (result==B_NO_ERROR);
}

bool BAudioCD::ScanForward(void)
{
	return (scan(myDevice,1));
}

bool BAudioCD::ScanBackward(void)
{
	return (scan(myDevice,-1));
}

bool BAudioCD::StopScanning(void)
{
	return (scan(myDevice,0));
}

bool BAudioCD::SetVolume(uint32 volume)
{
	scsi_volume vol;
	vol.port0_volume=volume;
	vol.port1_volume=volume;
	vol.port2_volume=volume;
	vol.port3_volume=volume;
	vol.flags=170; // 2+8+32+128 - the flag bits of the changed fields...
	status_t result=ioctl(myDevice,B_SCSI_SET_VOLUME,&vol);
	return (result==B_NO_ERROR);
}

uint32 BAudioCD::GetVolume(void)
{
	scsi_volume vol;
	status_t result=ioctl(myDevice,B_SCSI_GET_VOLUME,&vol);
	printf ("Get Volumes : %d, %d, %d, %d\n", vol.port0_volume, vol.port1_volume,
		vol.port2_volume, vol.port3_volume);
	return (vol.port0_volume+vol.port1_volume+vol.port2_volume+vol.port3_volume)/4;
}

