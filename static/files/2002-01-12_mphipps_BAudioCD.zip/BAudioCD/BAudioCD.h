#include <List.h>
struct BAudioCDPosition
{
	uchar track;
	uchar totalMinute;
	uchar totalSecond;
	uchar totalFrame;
	uchar trackMinute;
	uchar trackSecond;
	uchar trackFrame;
};

class BAudioCD
{
	public:
		BAudioCD (char *device);
		~BAudioCD();
		bool Eject(void);
		bool Load(void);
		bool Close(void);
		bool Play(uint32 trackNo,uint32 endTrack=99);
		bool Pause(void);
		bool Resume(void);
		bool Stop(void);
		BAudioCDPosition  GetPosition(void);
		status_t  GetMediaStatus(void);
		BList *GetTOC(BList *storage);
		bool ScanForward(void);
		bool ScanBackward(void);
		bool StopScanning(void);
		bool SetVolume(uint32 volume);
		uint32 GetVolume(void);
		uint32 getCDDBID(int []);
		uint32 getTracks(void);
		uint32 getLength(void);
	private:
		int myDevice;
};
